from fractions import Fraction as F
# Exact residual theta width: (285-256)*2*pi/262144.
# theta_dot > 13/80, hence residence < width/(13/80) = 145*pi/106496.
coef = F(145,106496)
pi_upper = F(355,113)
upper = coef*pi_upper
assert upper < F(1,230), (upper, F(1,230))
# Historical N5 first-cluster strong interval 3/20 is implied by new [1/2,71/100] strong certificate.
# N2: tR >= (7/5)T + (73/5)t40 - 80*pi.
# At T>400*pi/7 and t40>=3/20, tR > 219/100.
tR_floor = F(73,5)*F(3,20)
assert tR_floor == F(219,100)
# Each visit duration <1/230, so N visits must satisfy N/230 > 219/100; minimum integer N is 504.
N=1
while F(N,230) <= tR_floor:
    N += 1
assert N == 504
# N4 max 7 visits per global cluster => at least 72 clusters.
C=(N+7-1)//7
assert C == 72
print('N5_VISIT_BOUND_EXACT_CHECK=PASS')
print('residence_upper_using_pi355_113=', upper)
print('one_over_230=', F(1,230))
print('strict_residence_margin=', F(1,230)-upper)
print('tR_floor=',tR_floor)
print('min_visits=',N)
print('min_clusters=',C)
