#pragma STDC FENV_ACCESS ON
#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/transc.hpp>
#include <boost/numeric/interval/rounded_transc.hpp>
#include <boost/numeric/interval/checking.hpp>
#include <array>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
using namespace std; namespace bn=boost::numeric;
using Rounding=bn::interval_lib::save_state<bn::interval_lib::rounded_transc_std<long double>>;
using Checking=bn::interval_lib::checking_base<long double>;
using Policies=bn::interval_lib::policies<Rounding,Checking>;
using I=bn::interval<long double,Policies>;
static long double lo(const I&x){return x.lower();} static long double hi(const I&x){return x.upper();}
static long double mid(const I&x){return (lo(x)+hi(x))/2;} static long double rad(const I&x){return (hi(x)-lo(x))/2;} static long double wd(const I&x){return hi(x)-lo(x);} 
static long double dn(long double x){return nextafterl(x,-numeric_limits<long double>::infinity());} static long double up(long double x){return nextafterl(x,numeric_limits<long double>::infinity());}
static I widen(long double a,long double b){return I(dn(a),up(b));} static I hullI(const I&a,const I&b){return I(min(lo(a),lo(b)),max(hi(a),hi(b)));}
static bool inside(const I&a,const I&b){return lo(b)<lo(a)&&hi(a)<hi(b);} 
static I inflate(const I&x,long double fac){long double m=mid(x),r=rad(x); long double rr=up(fac*r+1e-30L); return I(dn(m-rr),up(m+rr));}
static I sq(const I&x){if(lo(x)>=0)return x*x; if(hi(x)<=0){I y=-x;return y*y;} long double u=max(-lo(x),hi(x)); return I(0,up(u*u));}
static I PI(){long double p=acosl(-1.L); return I(dn(p),up(p));}
template<class T> static T mu_small(const T&g){return g*g*g*(g*g-T(3)*g+T(3))/(T(1)-T(2)*g+g*g+T(2)*g*g*g-g*g*g*g);}
using V4=array<I,4>;
static V4 rhs(const V4&y,const I&mu,const I&c){I z1=y[0],z2=y[1],p1=y[2],p2=y[3]; I x0=mu*z2,x1=z1*z1,x2=z2*z2,x3=x1+x2,x4=I(2)*x3,x5=mu*z1,x6=I(8)*c; I x7=p1*z2,x8=I(4)*z1,x9=-I(4)*x1+I(4)*x2+I(4)*(x3*x3)+I(1); if(lo(x9)<=0) throw runtime_error("SQRT_DOMAIN"); I x10=I(1)/sqrt(x9),x11=I(8)*x10,x12=x10*x10*x10,x15=I(2)*x1+I(2)*x2,x17=x12*(x15-I(1)),x18=I(16)*x3,x19=p2*z2,x21=x0*(x15+I(1)),x22=x12*x18; return {p1/I(4)-x0-x4*z2,p2/I(4)+x4*z1-x5,mu*p2-I(2)*p2*(I(3)*x1+x2)+x11*x5-x17*x18*x5+x6*z1+x7*x8,mu*p1+I(2)*p1*(x1+I(3)*x2)+x0*x11-x19*x8-x21*x22+x6*z2};}
struct G4 { I u1,u2,R,th; };
static G4 derivT(const V4&y,const I&D,const I&ms,const I&M,const I&cl1){
 I u1=y[0],u2=y[1],R=y[2],th=y[3]; if(!(lo(R)>0)) throw runtime_error("NONPOS_R");
 I r=sqrt(R),ct=cos(th),st=sin(th); I z1=r*ct,z2=r*st;
 I p1=I(4)*(u1+(I(2)*R+M)*z2),p2=I(4)*(u2-(I(2)*R-M)*z1);
 V4 x={z1,z2,p1,p2}; auto f=rhs(x,ms,-(cl1+D));
 I Rdot=I(2)*(z1*f[0]+z2*f[1]);
 I du1=f[2]/I(4)-I(2)*Rdot*z2-(I(2)*R+M)*f[1];
 I du2=f[3]/I(4)+I(2)*Rdot*z1+(I(2)*R-M)*f[0];
 I thdot=(u2*ct-u1*st)/r+(I(1)-I(2)*ms)*cos(I(2)*th);
 return {du1,du2,Rdot,thdot};
}
static bool stepT(const I&h,V4&X,const I&D,const I&ms,const I&M,const I&cl1,V4&tube,string&reason){
 I tau(0,hi(h)); G4 g0;
 try{g0=derivT(X,D,ms,M,cl1);}catch(exception&e){reason=e.what();return false;}
 V4 B;
 B[0]=inflate(hullI(X[0],X[0]+tau*g0.u1),1.20L);
 B[1]=inflate(hullI(X[1],X[1]+tau*g0.u2),1.20L);
 B[2]=inflate(hullI(X[2],X[2]+tau*g0.R),1.20L);
 B[3]=inflate(hullI(X[3],X[3]+tau*g0.th),1.20L);
 bool ok=false; G4 g=g0;
 for(int it=0;it<32;it++){
   try{g=derivT(B,D,ms,M,cl1);}catch(exception&e){reason=e.what();return false;}
   V4 N={X[0]+tau*g.u1,X[1]+tau*g.u2,X[2]+tau*g.R,X[3]+tau*g.th};
   if(inside(N[0],B[0])&&inside(N[1],B[1])&&inside(N[2],B[2])&&inside(N[3],B[3])){ok=true;break;}
   for(int k=0;k<4;k++) B[k]=inflate(hullI(B[k],N[k]),1.12L);
   if(lo(B[2])<=0 || wd(B[0])>0.5L || wd(B[1])>0.5L || wd(B[2])>0.5L || wd(B[3])>0.5L){reason="WIDTH_SAT";return false;}
 }
 if(!ok){reason="PICARD_FAIL";return false;}
 try{g=derivT(B,D,ms,M,cl1);}catch(exception&e){reason=e.what();return false;}
 X={X[0]+h*g.u1,X[1]+h*g.u2,X[2]+h*g.R,X[3]+h*g.th}; tube=B; reason="PASS"; return true;
}
struct Rec{long long root;string path;int sector;long long thi_num,tn;long double Alo,Ahi,plo,phi,Rlo,Rhi;long long dlo,dhi,dden;};
static vector<string> split(const string&s){vector<string>v;stringstream ss(s);string x;while(getline(ss,x,'\t'))v.push_back(x);return v;}
int main(int argc,char**argv){
 if(argc<2||argc>5){cerr<<"usage input.tsv [phi_parts=4] [h=0.00025] [maxrows=0]\n";return 2;}
 int parts=argc>=3?stoi(argv[2]):4; long double hs=argc>=4?stold(argv[3]):0.00025L; int maxrows=argc>=5?stoi(argv[4]):0;
 vector<Rec> rec; ifstream f(argv[1]); string l; getline(f,l); while(getline(f,l)){if(l.empty())continue;auto v=split(l); if(v.size()<14)continue; rec.push_back({stoll(v[0]),v[1],stoi(v[2]),stoll(v[3]),stoll(v[4]),stold(v[5]),stold(v[6]),stold(v[7]),stold(v[8]),stold(v[9]),stold(v[10]),stoll(v[11]),stoll(v[12]),stoll(v[13])}); if(maxrows&&int(rec.size())>=maxrows)break;}
 I gamma=I(459)/I(1000),ms=mu_small(gamma),M=I(1)-ms,x=I(1)-ms-gamma,cl1=x*x/I(2)+(I(1)-ms)/(I(1)-gamma)+ms/gamma,P=PI();
 I h=I(hs); const long double TEND=0.71L,T0=0.5L,threshold=(3.L/200.L)*(3.L/200.L);
 cout<<setprecision(22);
 int pass=0,total=0; long double globalMin=1e99L; string worst;
 for(auto&r:rec){bool nodeok=true; long double nodeMin=1e99L,nodeMaxW=0; string nreason="PASS";
   for(int part=0;part<parts;part++){total++; long double pa=r.plo+(r.phi-r.plo)*part/parts, pb=r.plo+(r.phi-r.plo)*(part+1)/parts;
     I A=widen(r.Alo,r.Ahi), ph=widen(pa,pb), R=widen(r.Rlo,r.Rhi), th=I(2)*P*I((long double)r.thi_num)/I((long double)r.tn);
     V4 X={A*cos(ph),A*sin(ph),R,th}; I D=I((long double)r.dlo,(long double)r.dhi)/I((long double)r.dden);
     long double t=0; bool ok=true; string reason="PASS"; long double localMin=1e99L,maxw=0; int steps=0;
     while(t<TEND-1e-18L){long double dh=min(hs,TEND-t); I hh=I(dh); V4 tube; if(!stepT(hh,X,D,ms,M,cl1,tube,reason)){ok=false;break;} long double t2=t+dh; if(t2>T0-1e-18L){I a2=sq(tube[0])+sq(tube[1]); localMin=min(localMin,lo(a2)); if(!(lo(a2)>threshold)){ok=false;reason="STRONG_FAIL";break;}} for(int k=0;k<4;k++)maxw=max(maxw,wd(tube[k])); t=t2; steps++;}
     if(ok){pass++; nodeMin=min(nodeMin,localMin);nodeMaxW=max(nodeMaxW,maxw);} else {nodeok=false;nreason=reason;nodeMin=min(nodeMin,localMin);nodeMaxW=max(nodeMaxW,maxw);}
     cout<<"PART root="<<r.root<<" sector="<<r.sector<<" p="<<part<<" status="<<(ok?"PASS":"FAIL")<<" steps="<<steps<<" minA2="<<localMin<<" maxw="<<maxw<<" reason="<<reason<<"\n";
   }
   if(nodeMin<globalMin){globalMin=nodeMin; worst=to_string(r.root)+":"+r.path;}
   cout<<"NODE root="<<r.root<<" sector="<<r.sector<<" status="<<(nodeok?"PASS":"FAIL")<<" minA2="<<nodeMin<<" maxw="<<nodeMaxW<<" reason="<<nreason<<"\n";
 }
 cerr<<"SUMMARY pass_parts="<<pass<<"/"<<total<<" minA2="<<globalMin<<" threshold="<<threshold<<" worst="<<worst<<"\n";
 return pass==total?0:1;
}
