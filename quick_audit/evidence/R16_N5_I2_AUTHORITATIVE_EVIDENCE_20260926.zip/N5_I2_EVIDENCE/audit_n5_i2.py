from pathlib import Path
from fractions import Fraction as F
import re, hashlib, sys
R=Path(__file__).resolve().parent

def rows(p): return max(0,sum(1 for _ in open(p))-1)
def lines(p,prefix=None):
    with open(p) as f:
        for s in f:
            if prefix is None or s.startswith(prefix): yield s.rstrip('\n')
def parse_float(s,key):
    m=re.search(r'(?:^| )'+re.escape(key)+r'=([0-9.eE+-]+)',s)
    if not m: raise AssertionError((key,s))
    return float(m.group(1))
# Input universes
strong_inputs=sorted(R.joinpath('inputs').glob('shard_*.tsv'))
outer_inputs=sorted(R.joinpath('inputs').glob('outer_shard_*.tsv'))
assert len(strong_inputs)==8 and sum(rows(p) for p in strong_inputs)==1196
assert len(outer_inputs)==8 and sum(rows(p) for p in outer_inputs)==1181
assert rows(R/'inputs/hard_sink5_input.tsv')==5
assert rows(R/'inputs/frontier254_exact_bounds.tsv')==254
# Strong: 1196 nodes x fixed 2 phi halves, physical time [0.5,0.71]
strong_parts=[]; strong_nodes=[]
for p in sorted((R/'strong').glob('shard_*.out')):
    strong_parts += list(lines(p,'PART ')); strong_nodes += list(lines(p,'NODE '))
assert len(strong_nodes)==1196 and len(strong_parts)==2392
assert all('status=PASS' in s for s in strong_nodes+strong_parts)
min_a2=min(parse_float(s,'minA2') for s in strong_parts)
threshold=(3/200)**2
assert min_a2 > threshold
# Outer exact-frontier exclusion on [0.005,0.5]
outer_parts=[]; outer_nodes=[]
for p in sorted((R/'outer').glob('shard_*.out')):
    outer_parts += list(lines(p,'PART ')); outer_nodes += list(lines(p,'NODE '))
assert len(outer_nodes)==1181 and len(outer_parts)==2362
assert all('status=PASS' in s for s in outer_nodes+outer_parts)
sink_outer_parts=list(lines(R/'outer/outer_hardsink5.out','PART ')); sink_outer_nodes=list(lines(R/'outer/outer_hardsink5.out','NODE '))
assert len(sink_outer_nodes)==5 and len(sink_outer_parts)==10 and all('status=PASS' in s for s in sink_outer_nodes+sink_outer_parts)
# Detachment [0,0.005]: positive theta_dot and endpoint above global face
safe_dparts=list(lines(R/'detach/detach_safe1181.out','PART ')); safe_dnodes=list(lines(R/'detach/detach_safe1181.out','NODE '))
sink_dparts=list(lines(R/'detach/detach_hardsink5.out','PART ')); sink_dnodes=list(lines(R/'detach/detach_hardsink5.out','NODE '))
assert len(safe_dnodes)==1181 and len(safe_dparts)==2362 and all('status=PASS' in s for s in safe_dnodes+safe_dparts)
assert len(sink_dnodes)==5 and len(sink_dparts)==10 and all('status=PASS' in s for s in sink_dnodes+sink_dparts)
min_thdot=min(parse_float(s,'min_thdot') for s in safe_dparts+sink_dparts)
min_margin=min(parse_float(s,'end_margin') for s in safe_dparts+sink_dparts)
assert min_thdot>0 and min_margin>0
# Cross-compiler hard-set parity: exact text equality.
pairs=[('failed31_h0.002.out','clang_failed31.out'),('outer_hardsink5.out','clang_outer_sink.out'),('detach_hardsink5.out','clang_detach_sink.out')]
for a,b in pairs:
    assert (R/'cross_compiler'/a).read_bytes()==(R/'cross_compiler'/b).read_bytes(),(a,b)
# Exact residence/visit consequence
coef=F(145,106496); piu=F(355,113)
assert coef*piu < F(1,230)
assert F(73,5)*F(3,20)==F(219,100)
N=1
while F(N,230)<=F(219,100): N+=1
assert N==504 and (N+6)//7==72
print('R16_N5_I2_AUDIT=PASS')
print('strong_nodes=1196 strong_parts=2392 min_A2=',format(min_a2,'.18g'),'threshold=',format(threshold,'.18g'))
print('outer_safe_nodes=1181 outer_safe_parts=2362 hard_sink_nodes=5 hard_sink_parts=10 frontier_leaves=254')
print('detach_safe_parts=2362 detach_sink_parts=10 min_theta_dot=',format(min_thdot,'.18g'),'min_face_margin=',format(min_margin,'.18g'))
print('cross_compiler_hard_subset=BYTE_IDENTICAL')
print('residence_lt_1_over_230=PASS min_visits=504 min_clusters=72')
