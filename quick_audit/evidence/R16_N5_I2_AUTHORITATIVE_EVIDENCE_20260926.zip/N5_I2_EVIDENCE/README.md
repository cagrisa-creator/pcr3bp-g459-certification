# R16 N5 I2 independent validated-propagation evidence

Status: PASS candidate for R16 N5 closure.

This package independently replays the theorem-critical N5 numerical facts without using the missing historical FM production propagator sources. It reuses only the frozen input proof-object universes and the exact 254-leaf residual frontier.

## Independent representation

The new backend propagates the regularized PCR3BP in physical time using interval state `(u1,u2,R,theta)`, where `u1=A cos(phi)`, `u2=A sin(phi)`, `R=r^2`. This representation was already independently accepted for N4 and is distinct from the historical N5 canonical/affine/energy-fallback production architecture. The physical-time equations are obtained from the same audited canonical vector field identities used in N4; no historical N5 propagation source is imported.

Boost.Interval directed arithmetic with rigorous transcendental rounding is compiled with `-frounding-math`. Every step uses a fail-closed Picard enclosure.

## Closed obligations

1. Strong window: all 1,196 terminal nodes, two fixed phi halves each, 2,392/2,392 PASS on terminal-relative `[0.5,0.71]`. The directly certified predicate is `A^2=u1^2+u2^2 > (3/200)^2`, which is the frozen R5-BL/R5-FH sufficient condition for `beta>=2/5`. Minimum certified lower bound in this replay is about `0.14658740506598757`, versus threshold `0.000225`.

2. Residual-free outer interval: all 1,181 safe terminals, 2,362/2,362 halves PASS on `[0.005,0.5]`, plus all five hard sinks, 10/10 halves PASS. Instead of historical complement separators, the new backend directly tests every validated tube against all 254 exact residual leaves in `(theta,A,Delta)`.

3. Face detachment: all 1,181 safe terminals plus five hard sinks, 2,372/2,372 halves PASS on `[0,0.005]`. The stronger independent predicate is `theta_dot>0` throughout the tube and `theta(0.005)` strictly above the global residual upper face `285/262144`. Minimum certified `theta_dot` lower bound is about `0.18966207894490947`; minimum endpoint angular margin is about `2.8471910603304996e-4` radians.

This stronger detachment proof subsumes the historical primary, localized-primary, reduced exact-energy fallback and hard-sink detachment classes rather than replaying their representation-specific fallbacks.

4. Exact residual residence/visit bridge: independently checked with rational arithmetic: connected exact-residual residence `<145*pi/106496<1/230`, `t_R>=219/100`, minimum connected visits `504`, and with N4's independently closed max seven visits per cluster, minimum global clusters `72`.

5. Bounded compiler parity: GCC and Clang outputs are byte-identical on all 31 historically difficult strong-window nodes and on all five hard-sink outer/detachment obligations.

## Composition with already closed R16 nodes

- N2 publication audit supplies the exact occupation budget and index/frame convention.
- N4 I2 closure supplies the independent hard-transition graph and maximum hard-edge path 5, hence at most seven connected visits per cluster.
- N5 exact cluster arithmetic and finite proof-object accounting were already independently closed before this replay.

Therefore this package targets only the previously open N5 validated-propagation independence gate.
