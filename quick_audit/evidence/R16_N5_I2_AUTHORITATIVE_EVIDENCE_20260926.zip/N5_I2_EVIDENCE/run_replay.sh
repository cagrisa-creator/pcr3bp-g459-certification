#!/usr/bin/env bash
set -euo pipefail
CXX=${CXX:-g++}
CXXFLAGS='-O2 -std=c++17 -frounding-math'
mkdir -p replay/{strong,outer,detach}
$CXX $CXXFLAGS src/n5_uvt_pilot.cpp -o replay/n5_uvt_pilot
$CXX $CXXFLAGS src/n5_uvt_outer.cpp -o replay/n5_uvt_outer
$CXX $CXXFLAGS src/n5_uvt_detach.cpp -o replay/n5_uvt_detach
for i in $(seq 0 7); do
  replay/n5_uvt_pilot inputs/shard_${i}.tsv 2 0.002 0 > replay/strong/shard_${i}.out 2> replay/strong/shard_${i}.err &
done
wait
for i in $(seq 0 7); do
  replay/n5_uvt_outer inputs/outer_shard_${i}.tsv inputs/frontier254_exact_bounds.tsv 2 0.001 0 > replay/outer/shard_${i}.out 2> replay/outer/shard_${i}.err &
done
wait
replay/n5_uvt_outer inputs/hard_sink5_input.tsv inputs/frontier254_exact_bounds.tsv 2 0.001 0 > replay/outer/outer_hardsink5.out 2> replay/outer/outer_hardsink5.err
# Build a concatenated 1181 input for detachment.
{ head -1 inputs/outer_shard_0.tsv; for i in $(seq 0 7); do tail -n +2 inputs/outer_shard_${i}.tsv; done; } > replay/safe1181.tsv
replay/n5_uvt_detach replay/safe1181.tsv 2 0.001 0 > replay/detach/detach_safe1181.out 2> replay/detach/detach_safe1181.err
replay/n5_uvt_detach inputs/hard_sink5_input.tsv 2 0.001 0 > replay/detach/detach_hardsink5.out 2> replay/detach/detach_hardsink5.err
python3 exact/verify_n5_visit_bound.py
python3 audit_n5_i2.py
