R16 COMPLEMENTARY TRUST-BASE I2 EVIDENCE — 2026-09-26

Status: R16_COMPLEMENTARY_TRUST_BASE_I2_PASS

This package closes the R16 publication-independence burden for C0-C4 without reopening the mathematical search campaigns.

I2 here means an independent fail-closed checker/replay of the same finite certificate. It does not claim I3 arithmetic independence.

C0: exact 16-cell source cover retained; 14 pointwise beta>=1/100 cells independently terminal-checked; s04_d0 and s06_d0 remain explicitly integrated-only.
C1: independent finite control replay verifies 9,984/9,984 corridor boxes and both 1,024-box outward phi faces. GCC/Clang output byte-identical.
C2: new 39-seed full-shell re-cover yields beta>=1/20 with 1,636 terminal leaves; independent terminal checker accepts every leaf. Independent flow replay verifies 4,992/4,992 boxes.
C3: 50 exact jobs cover the theta-entry decomposition. 128,550 processed boxes -> 64,300 PASS leaves, zero failures; exact A-union and Kraft audits PASS; every terminal leaf independently checked.
C4: beta>=0 independently terminal-checked on s04/s06 (8,056 + 20,801 leaves); full A_dot replay closes 14,971/14,976 parents plus 320/320 refined children; N has A_dot <= -0.159940762827796..., hence beta-(3/20)A_dot >= 0.0089911144241694... > 0.

Shared terminal checker source SHA-256: 5619d9ccfbecb0d5f3f140abf0afce6bfe6915d8d4fa888819f072f5b3f95015
Terminal checker audit SHA-256: 485ff8913e994fc28b9a8881c1ee57ff26006ffbb2ad62776b753ceb3c21b965
Combined audit SHA-256: TO_BE_FILLED_BY_MANIFEST

Original authoritative historical packages remain provenance and are referenced by Drive IDs in the combined audit.
