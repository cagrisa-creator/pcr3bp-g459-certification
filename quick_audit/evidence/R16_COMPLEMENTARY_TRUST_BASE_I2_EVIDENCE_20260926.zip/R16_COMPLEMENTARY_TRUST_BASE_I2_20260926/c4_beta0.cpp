#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/rounded_transc.hpp>
#include <boost/numeric/interval/checking.hpp>
#include <array>
#include <vector>
#include <deque>
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cfenv>
#include <limits>
#include <string>
#include <algorithm>
#include <chrono>
#include <map>
#include <set>
#include <cstdlib>
#include <stdexcept>
#include <tuple>
#pragma STDC FENV_ACCESS ON
namespace bn=boost::numeric;
using Rounding=bn::interval_lib::save_state<bn::interval_lib::rounded_transc_std<long double>>;
using Checking=bn::interval_lib::checking_base<long double>;
using Policies=bn::interval_lib::policies<Rounding,Checking>;
using I=bn::interval<long double,Policies>;
static I BETA_TARGET=I(1)/I(100);
static inline long double lo(const I&x){return x.lower();}
static inline long double hi(const I&x){return x.upper();}
static inline long double dn(long double x){return std::nextafter(x,-std::numeric_limits<long double>::infinity());}
static inline long double up(long double x){return std::nextafter(x,std::numeric_limits<long double>::infinity());}
static inline long double absup(const I&x){return std::max(std::fabs(lo(x)),std::fabs(hi(x)));}
static inline I square_range(const I&x){if(lo(x)<=0&&hi(x)>=0){long double u=std::max(lo(x)*lo(x),hi(x)*hi(x));return I(0,up(u));}return x*x;}
static inline I full_cell(long long i,long long n){I d((long double)n);return I((long double)i)/d+I(0,1)/d;}
static inline I PI_RIG(){
 static const long double a=std::stold("3.14159265358979323846264338327950288419716939937510");
 static const long double b=std::stold("3.14159265358979323846264338327950288419716939937511");
 static const I p(dn(a),up(b)); return p;
}
static inline I hullI(const I&a,const I&b){return I(std::min(lo(a),lo(b)),std::max(hi(a),hi(b)));}
static inline I intersectI(const I&a,const I&b){long double l=std::max(lo(a),lo(b)),h=std::min(hi(a),hi(b));if(l>h)throw std::runtime_error("empty_intersection");return I(l,h);}
static std::pair<I,I> sincos_small(const I&y){I sy(0),cy(0),yp(1);long double fact=1;for(int m=0;m<=14;++m){int deg=2*m;if(m==0){yp=I(1);fact=1;}else{yp*=y*y;fact*=((long double)(deg-1))*deg;}I t=yp/I(fact);cy+=(m%2?-t:t);}long double ay=absup(y),r=1;for(int j=1;j<=30;++j)r*=ay/j;cy+=I(-up(r),up(r));yp=y;fact=1;for(int m=0;m<=14;++m){int deg=2*m+1;if(m>0){yp*=y*y;fact*=((long double)(deg-1))*deg;}I t=yp/I(fact);sy+=(m%2?-t:t);}r=1;for(int j=1;j<=31;++j)r*=ay/j;sy+=I(-up(r),up(r));return {sy,cy};}
static std::pair<I,I> sincos_rig(const I&x){I P=PI_RIG(),half=P/I(2),quarter=P/I(4);bool have=false;I so(0),co(0);for(int k=-2;k<=6;++k){I y=x-I(k)*half,adm(-hi(quarter),hi(quarter));if(hi(y)<lo(adm)||lo(y)>hi(adm))continue;auto sc=sincos_small(intersectI(y,adm));I ss=sc.first,cc=sc.second,s,c;int m=((k%4)+4)%4;if(m==0){s=ss;c=cc;}else if(m==1){s=cc;c=-ss;}else if(m==2){s=-ss;c=-cc;}else{s=-cc;c=ss;}if(!have){so=s;co=c;have=true;}else{so=hullI(so,s);co=hullI(co,c);}}if(!have)throw std::runtime_error("trig_reduce");return {so,co};}
using TrigKey=std::pair<long double,long double>;
static std::map<TrigKey,std::pair<I,I>> trig_cache;
static long long trig_cache_hits=0,trig_cache_misses=0;
static const std::pair<I,I>& sincos_cached(const I&x){TrigKey key{lo(x),hi(x)};auto it=trig_cache.find(key);if(it!=trig_cache.end()){++trig_cache_hits;return it->second;}auto sc=sincos_rig(x);++trig_cache_misses;return trig_cache.emplace(key,std::move(sc)).first->second;}
static inline I sinR(const I&x){return sincos_cached(x).first;} static inline I cosR(const I&x){return sincos_cached(x).second;} static inline I sqrtT(const I&x){if(lo(x)<0)throw std::runtime_error("sqrt_negative");return sqrt(x);}

template<int N> struct AD{I v;std::array<I,N>d;AD():v(0){d.fill(I(0));}AD(const I&x):v(x){d.fill(I(0));}};
template<int N> static AD<N> var(const I&x,int k){AD<N>a(x);a.d[k]=I(1);return a;}
template<int N> static AD<N> operator+(const AD<N>&a,const AD<N>&b){AD<N>q;q.v=a.v+b.v;for(int i=0;i<N;++i)q.d[i]=a.d[i]+b.d[i];return q;}
template<int N> static AD<N> operator-(const AD<N>&a){AD<N>q;q.v=-a.v;for(int i=0;i<N;++i)q.d[i]=-a.d[i];return q;}
template<int N> static AD<N> operator-(const AD<N>&a,const AD<N>&b){return a+(-b);} 
template<int N> static AD<N> operator*(const AD<N>&a,const AD<N>&b){AD<N>q;q.v=a.v*b.v;for(int i=0;i<N;++i)q.d[i]=a.d[i]*b.v+a.v*b.d[i];return q;}
template<int N> static AD<N> inv(const AD<N>&a){AD<N>q;q.v=I(1)/a.v;for(int i=0;i<N;++i)q.d[i]=-a.d[i]*q.v*q.v;return q;}
template<int N> static AD<N> operator/(const AD<N>&a,const AD<N>&b){return a*inv(b);} 
template<int N> static AD<N> sqrtT(const AD<N>&a){AD<N>q;q.v=sqrtT(a.v);for(int i=0;i<N;++i)q.d[i]=a.d[i]/(I(2)*q.v);return q;}
template<int N> static std::pair<AD<N>,AD<N>> sincosTpair(const AD<N>&a){
 auto sc=sincos_cached(a.v); AD<N>s,c; s.v=sc.first; c.v=sc.second;
 for(int i=0;i<N;++i){s.d[i]=c.v*a.d[i];c.d[i]=-s.v*a.d[i];} return {s,c};
}
template<int N> static AD<N> sinT(const AD<N>&a){return sincosTpair(a).first;}
template<int N> static AD<N> cosT(const AD<N>&a){return sincosTpair(a).second;}
static std::pair<I,I> sincosTpair(const I&a){return sincos_cached(a);}
static I sinT(const I&a){return sincos_cached(a).first;}static I cosT(const I&a){return sincos_cached(a).second;}

template<class T> struct TD{T v,d;TD():v(T(I(0))),d(T(I(0))){}TD(const T&x):v(x),d(T(I(0))){}TD(const T&x,const T&y):v(x),d(y){}};
template<class T> static TD<T> operator+(const TD<T>&a,const TD<T>&b){return TD<T>(a.v+b.v,a.d+b.d);}template<class T> static TD<T> operator-(const TD<T>&a){return TD<T>(-a.v,-a.d);}template<class T> static TD<T> operator-(const TD<T>&a,const TD<T>&b){return a+(-b);}template<class T> static TD<T> operator*(const TD<T>&a,const TD<T>&b){return TD<T>(a.v*b.v,a.d*b.v+a.v*b.d);}template<class T> static TD<T> operator/(const TD<T>&a,const TD<T>&b){return TD<T>(a.v/b.v,(a.d*b.v-a.v*b.d)/(b.v*b.v));}
template<class T> static TD<T> sqrtT(const TD<T>&a){T q=sqrtT(a.v);return TD<T>(q,a.d/(T(I(2))*q));}

template<class T> static T C(long double x){return T(I(x));}
template<class T> using V4=std::array<T,4>;
template<class T> static T omega(const V4<T>&a,const V4<T>&b){return a[0]*b[2]+a[1]*b[3]-a[2]*b[0]-a[3]*b[1];}
template<class T> static V4<T> project(const V4<T>&x,const V4<T>&Y,const V4<T>&F,const T&sig){T aa=omega(x,F)/sig,bb=omega(x,Y)/sig;V4<T>q;for(int i=0;i<4;++i)q[i]=x[i]-aa*Y[i]+bb*F[i];return q;}
template<class T> static V4<T> jq(const V4<T>&w){return {-w[1],w[0],w[3],-w[2]};}template<class T> static V4<T> kq(const V4<T>&w){return {-w[3],w[2],-w[1],w[0]};}

template<class T> static V4<T> rhs_jac_scalar(const V4<T>&y,const T&mu,const T&c,std::array<std::array<T,4>,4>&J){
 T z1=y[0],z2=y[1],p1=y[2],p2=y[3];T x0=mu*z2,x1=z1*z1,x2=z2*z2,x3=x1+x2,x4=C<T>(2)*x3,x5=mu*z1,x6=C<T>(8)*c;T x7=p1*z2,x8=C<T>(4)*z1,x9=-C<T>(4)*x1+C<T>(4)*x2+C<T>(4)*(x3*x3)+C<T>(1);T x10=C<T>(1)/sqrtT(x9),x11=C<T>(8)*x10,x12=x10*x10*x10,x13=C<T>(2)*x1,x14=C<T>(2)*x2,x15=x13+x14;T x16=x15-C<T>(1),x17=x12*x16,x18=C<T>(16)*x3,x19=p2*z2,x20=x15+C<T>(1),x21=x0*x20;T x22=x12*x18,x23=x8*z2,x24=-x23,x25=mu+x13+C<T>(6)*x2,x26=-mu+C<T>(6)*x1+x14;T x27=p2*z1,x28=mu*x3,x29=x12*x28,x30=C<T>(16)*x1,x31=mu*x12,x32=C<T>(4)*x29;T x33=x10*x10*x10*x10*x10,x34=C<T>(48)*x28*x33,x35=C<T>(2)*c+C<T>(2)*mu*x10,x36=x0*z1;T x37=C<T>(192)*mu*x16*x20*x3*x33*z1*z2+C<T>(4)*p1*z1-C<T>(32)*x12*x21*z1-C<T>(32)*x17*x36-C<T>(4)*x19-C<T>(4)*x22*x36;T x38=C<T>(16)*x2;
 V4<T>f={p1/C<T>(4)-x0-x4*z2,p2/C<T>(4)+x4*z1-x5,mu*p2-C<T>(2)*p2*(C<T>(3)*x1+x2)+x11*x5-x17*x18*x5+x6*z1+x7*x8,mu*p1+C<T>(2)*p1*(x1+C<T>(3)*x2)+x0*x11-x19*x8-x21*x22+x6*z2};T zero=C<T>(0),quarter=C<T>(0.25L);
 J={{{x24,-x25,quarter,zero},{x26,x23,zero,quarter},{C<T>(4)*x1*(x16*x16)*x34-C<T>(4)*x16*x30*x31-C<T>(4)*x16*x32-C<T>(12)*x27-C<T>(4)*x29*x30+C<T>(4)*x35+C<T>(4)*x7,x37,x23,-x26},{x37,C<T>(4)*x2*(x20*x20)*x34-C<T>(4)*x20*x31*x38-C<T>(4)*x20*x32-C<T>(4)*x27-C<T>(4)*x29*x38+C<T>(4)*x35+C<T>(12)*x7,x25,x24}}};return f;
}
template<class T> struct Gen{T g00,g01,g11,sig,k;};
template<class T> static Gen<T> contact_weighted(const V4<T>&w,const T&mu,const T&c){std::array<std::array<T,4>,4>J;V4<T>f=rhs_jac_scalar(w,mu,c,J),Jf;for(int i=0;i<4;++i){Jf[i]=C<T>(0);for(int j=0;j<4;++j)Jf[i]=Jf[i]+J[i][j]*f[j];}V4<TD<T>>W,F,Y;for(int i=0;i<4;++i){W[i]=TD<T>(w[i],f[i]);F[i]=TD<T>(f[i],Jf[i]);Y[i]=W[i]/TD<T>(C<T>(2));}TD<T>sigj=omega(Y,F);V4<TD<T>>v1j=project(jq(W),Y,F,sigj),v2j=project(kq(W),Y,F,sigj);TD<T>kj=omega(v1j,v2j);std::array<std::array<T,2>,4>V,Vd;for(int i=0;i<4;++i){V[i][0]=v1j[i].v;V[i][1]=v2j[i].v;Vd[i][0]=v1j[i].d;Vd[i][1]=v2j[i].d;}V4<T>Yv;for(int i=0;i<4;++i)Yv[i]=w[i]/C<T>(2);T sig=sigj.v,k=kj.v;std::array<std::array<T,2>,2>N;for(int col=0;col<2;++col){V4<T>q;for(int i=0;i<4;++i){q[i]=-Vd[i][col];for(int j=0;j<4;++j)q[i]=q[i]+J[i][j]*V[j][col];}V4<T>qp=project(q,Yv,f,sig),v1,v2;for(int i=0;i<4;++i){v1[i]=V[i][0];v2[i]=V[i][1];}N[0][col]=omega(qp,v2);N[1][col]=-omega(qp,v1);}return {N[1][0],(N[1][1]-N[0][0])/C<T>(2),-N[0][1],sig,k};}


template<class T> struct ScaledGen{T s00,s01,s11,sig,k;};
template<class T> static V4<T> matvec4(const std::array<std::array<T,4>,4>&A,const V4<T>&x){V4<T>y;for(int i=0;i<4;++i){y[i]=C<T>(0);for(int j=0;j<4;++j)y[i]=y[i]+A[i][j]*x[j];}return y;}
template<class T> static ScaledGen<T> scaled_generator(const V4<T>&w,const T&mu,const T&c){
 std::array<std::array<T,4>,4>J;V4<T>f=rhs_jac_scalar(w,mu,c,J),Y,x1=jq(w),x2=kq(w),qf1=jq(f),qf2=kq(f);
 for(int i=0;i<4;++i)Y[i]=w[i]/C<T>(2);
 T sig=omega(Y,f);V4<T>LY=matvec4(J,Y),lx1=matvec4(J,x1),lx2=matvec4(J,x2);T a1=omega(x1,f),a2=omega(x2,f);V4<T>V1,V2,Q1,Q2;
 for(int i=0;i<4;++i){V1[i]=sig*x1[i]-a1*Y[i];V2[i]=sig*x2[i]-a2*Y[i];Q1[i]=sig*(lx1[i]-qf1[i])-a1*LY[i];Q2[i]=sig*(lx2[i]-qf2[i])-a2*LY[i];}
 T s00=-omega(Q1,V1),s11=-omega(Q2,V2),s01=-(omega(Q2,V1)+omega(Q1,V2))/C<T>(2),kk=C<T>(0);for(int i=0;i<4;++i)kk=kk+w[i]*w[i];return{s00,s01,s11,sig,kk};
}
static I sqsafe(const I&x){return square_range(x);}template<int N>static AD<N> sqsafe(const AD<N>&x){AD<N>q;q.v=square_range(x.v);for(int i=0;i<N;++i)q.d[i]=I(2)*x.v*x.d[i];return q;}
template<class T> static T dF_generic(const T&R,const T&theta,const T&M,const T&cBG){T q=cosT(C<T>(2)*theta),D=C<T>(4)*R*R-C<T>(4)*R*q+C<T>(1),dD=C<T>(8)*R-C<T>(4)*q,sd=sqrtT(D);return C<T>(12)*R*R+M*M-C<T>(8)*M*R*q-C<T>(2)*cBG+C<T>(2)*M/sd-M*R*dD/(sd*sd*sd);}
template<class T> static T sigma_energy_cart(const T&theta,const T&r,const T&u1,const T&u2,const T&M,const T&cBG){T R=r*r;auto st=sincosTpair(theta);T z1=r*st.second,z2=r*st.first,dR=dF_generic(R,theta,M,cBG),b3u=(-C<T>(2)*R*z2)*u1+(C<T>(2)*R*z1)*u2;return -C<T>(2)*(sqsafe(u1)+sqsafe(u2))-C<T>(4)*b3u+C<T>(2)*R*dR;}
template<class T> static T sigma_energy_polar(const T&theta,const T&r,const T&A,const T&phi,const T&M,const T&cBG){auto sp=sincosTpair(phi);return sigma_energy_cart(theta,r,A*sp.second,A*sp.first,M,cBG);}

template<class T> static T mu_small(const T&g){return g*g*g*(g*g-C<T>(3)*g+C<T>(3))/(C<T>(1)-C<T>(2)*g+g*g+C<T>(2)*g*g*g-g*g*g*g);}
template<class T> static T Ffun_cos(const T&R,const T&qcos,const T&M,const T&cBG){T D=C<T>(4)*R*R-C<T>(4)*R*qcos+C<T>(1);return C<T>(4)*R*R*R+M*M*R-C<T>(4)*M*R*R*qcos-C<T>(2)*cBG*R+(C<T>(1)-M)+C<T>(2)*M*R/sqrtT(D);}
template<class T> static T Ffun(const T&R,const T&theta,const T&M,const T&cBG){return Ffun_cos(R,cosT(C<T>(2)*theta),M,cBG);}
template<class T> static V4<T> chart_state(const T&theta,const T&r,const T&A,const T&phi,const T&M){auto st=sincosTpair(theta),sp=sincosTpair(phi);T z1=r*st.second,z2=r*st.first,R=z1*z1+z2*z2,u1=A*sp.second,u2=A*sp.first,b1=-(C<T>(2)*R+M)*z2,b2=(C<T>(2)*R-M)*z1;return {z1,z2,C<T>(4)*(u1-b1),C<T>(4)*(u2-b2)};}

template<int N> static I centered(const I&f0,const AD<N>&fa,const std::array<I,N>&X,const std::array<I,N>&X0){I q=f0;for(int i=0;i<N;++i)q+=fa.d[i]*(X[i]-X0[i]);return q;}

static I dFfun_cos(const I&R,const I&q,const I&M,const I&cBG){I D=I(4)*R*R-I(4)*R*q+I(1),dD=I(8)*R-I(4)*q;I sd=sqrtT(D);return I(12)*R*R+M*M-I(8)*M*R*q-I(2)*cBG+I(2)*M/sd-M*R*dD/(sd*sd*sd);}
static I dFfun(const I&R,const I&theta,const I&M,const I&cBG){return dFfun_cos(R,cosR(I(2)*theta),M,cBG);}
static I Ftheta_sc(const I&R,const I&q,const I&s,const I&M){I D=I(4)*R*R-I(4)*R*q+I(1),sd=sqrtT(D);return I(8)*M*R*R*s*(I(1)-I(1)/(sd*sd*sd));}
static I Ftheta(const I&R,const I&theta,const I&M){auto sc=sincos_rig(I(2)*theta);return Ftheta_sc(R,sc.second,sc.first,M);}
static I pointmid(const I&x){return I((lo(x)+hi(x))/2);}
static I contract_R_cos(const I&qcos,const I&q,const I&Rbar,const I&Dcert,const I&M,const I&cBG){
 if(!(hi(Dcert)<0))throw std::runtime_error("Dcert_not_negative");
 long double L=0,U=hi(Rbar),a=0,b=hi(Rbar);
 for(int j=0;j<30;++j){long double m=(a+b)/2;I h=Ffun_cos(I(m),qcos,M,cBG)-q;if(lo(h)>0)a=m;else b=m;}L=dn(a);
 a=0;b=hi(Rbar);
 for(int j=0;j<30;++j){long double m=(a+b)/2;I h=Ffun_cos(I(m),qcos,M,cBG)-q;if(hi(h)<0)b=m;else a=m;}U=up(b);
 I X(L,U);
 for(int j=0;j<8;++j){I deriv=dFfun_cos(X,qcos,M,cBG);if(!(hi(deriv)<0))deriv=Dcert;I mid=pointmid(X),N=mid-(Ffun_cos(mid,qcos,M,cBG)-q)/deriv;I Xn=intersectI(X,N);if(hi(Xn)-lo(Xn)>=0.9999999999L*(hi(X)-lo(X)))break;X=Xn;}
 return X;
}
static I contract_R(const I&theta,const I&q,const I&Rbar,const I&Dcert,const I&M,const I&cBG){return contract_R_cos(cosR(I(2)*theta),q,Rbar,Dcert,M,cBG);}
template<int N> static AD<N> custom_ad(const I&v,const std::array<I,N>&d){AD<N>a(v);a.d=d;return a;}
template<class T> static V4<T> chart_state_cart(const T&theta,const T&r,const T&u1,const T&u2,const T&M){auto st=sincosTpair(theta);T z1=r*st.second,z2=r*st.first,R=z1*z1+z2*z2,b1=-(C<T>(2)*R+M)*z2,b2=(C<T>(2)*R-M)*z1;return {z1,z2,C<T>(4)*(u1-b1),C<T>(4)*(u2-b2)};}
struct Box{long long seed,ti,tn,i1,n1,i2,n2;long double Rlo,Rhi,Dlo,Dhi;int depth;std::string path;};
struct Eval{std::string status,reason,kind;long double speed=-INFINITY,eig=-INFINITY,Rlo=NAN,Rhi=NAN,hd00=-INFINITY,hd11=-INFINITY,hdet=-INFINITY;};
struct PolarRootData{I R,r,FR,Fr,rt,rA,R0,r0;};
using PolarRootKey=std::tuple<long long,long long,long long,long long,long double,long double,long double,long double>;
static std::map<PolarRootKey,PolarRootData> polar_root_cache;
static long long polar_cache_hits=0,polar_cache_misses=0;
static long double speed_from(const I&g00,const I&g01,const I&g11,const I&k,long double&eig,std::string&reason){if(!(lo(k)>0)){reason="K";return -INFINITY;}if(!(hi(g00)<0)){reason="G00";return -INFINITY;}I p=-g00,q=-g01,r=-g11,s=r-square_range(q)/p;if(!(lo(s)>0)){reason="SCHUR";return -INFINITY;}I det=p*s,trace=p+r;long double best=-INFINITY;if(lo(det)>0&&hi(trace)>0)best=std::max(best,lo(I(lo(det))/I(hi(trace))));I disc=square_range(p-r)+I(4)*square_range(q),direct=(trace-sqrtT(disc))/I(2);best=std::max(best,lo(direct));long double aq=absup(q);best=std::max(best,dn(std::min(lo(p)-aq,lo(r)-aq)));I l=q/p,u=square_range(l),factor=I(2)/(I(2)+u+sqrtT(u*u+I(4)*u));best=std::max(best,lo(I(std::min(lo(p),lo(s)))*factor));eig=best;reason="SPEED";return best>0&&hi(k)>0?lo(I(best)/I(hi(k))):-INFINITY;}
static Eval eval_polar(const Box&b,const I&M,const I&c,const I&cBG,const I&Amin,const I&Acut){
 Eval e;e.kind="polar";I theta=I(2)*PI_RIG()*full_cell(b.ti,b.tn),A=Amin+(Acut-Amin)*full_cell(b.i1,b.n1),phi=I(2)*PI_RIG()*full_cell(b.i2,b.n2),Rbar(dn(b.Rlo),up(b.Rhi)),Dcert(dn(b.Dlo),up(b.Dhi));
 try{
  PolarRootKey key{b.ti,b.tn,b.i1,b.n1,b.Rlo,b.Rhi,b.Dlo,b.Dhi};PolarRootData rd;auto it=polar_root_cache.find(key);
  if(it!=polar_root_cache.end()){rd=it->second;++polar_cache_hits;}else{auto sc2=sincos_cached(I(2)*theta);rd.R=contract_R_cos(sc2.second,square_range(A),Rbar,Dcert,M,cBG);if(!(lo(rd.R)>0)){e.status="SPLIT";e.reason="R_ZERO";return e;}rd.r=sqrtT(rd.R);rd.FR=dFfun_cos(rd.R,sc2.second,M,cBG);if(!(hi(rd.FR)<0))rd.FR=Dcert;rd.Fr=I(2)*rd.r*rd.FR;if(!(hi(rd.Fr)<0)){e.status="SPLIT";e.reason="FR";return e;}rd.rt=-Ftheta_sc(rd.R,sc2.second,sc2.first,M)/rd.Fr;rd.rA=I(2)*A/rd.Fr;I theta0=pointmid(theta),A0=pointmid(A);auto sc20=sincos_cached(I(2)*theta0);rd.R0=contract_R_cos(sc20.second,A0*A0,Rbar,Dcert,M,cBG);rd.r0=sqrtT(rd.R0);polar_root_cache.emplace(key,rd);++polar_cache_misses;}
  e.Rlo=lo(rd.R);e.Rhi=hi(rd.R);constexpr int N=3;std::array<I,N>X={theta,A,phi},X0={pointmid(theta),pointmid(A),pointmid(phi)};AD<N>th=var<N>(theta,0),aa=var<N>(A,1),ph=var<N>(phi,2),Mad(M),cad(c),cbgad(cBG);AD<N>rad=custom_ad<N>(rd.r,{rd.rt,rd.rA,I(0)});
  V4<AD<N>>wad=chart_state(th,rad,aa,ph,Mad);ScaledGen<AD<N>>za=scaled_generator(wad,Mad,cad);AD<N>sea=sigma_energy_polar(th,rad,aa,ph,Mad,cbgad);V4<I>w0=chart_state(X0[0],rd.r0,X0[1],X0[2],M);ScaledGen<I>z0=scaled_generator(w0,M,c);I se0=sigma_energy_polar(X0[0],rd.r0,X0[1],X0[2],M,cBG);
  I sigraw=centered<N>(z0.sig,za.sig,X,X0),sigenergy=centered<N>(se0,sea,X,X0),sig=intersectI(sigraw,sigenergy);if(!(hi(sig)<0)){e.status="SPLIT";e.reason="SIGMA";return e;}AD<N>sigT(sig);for(int j=0;j<N;++j)sigT.d[j]=intersectI(za.sig.d[j],sea.d[j]);AD<N>den=sigT*sigT;AD<N>g00a=za.s00/den,g01a=za.s01/den,g11a=za.s11/den;I sig0=intersectI(z0.sig,se0),den0=sig0*sig0,g000=z0.s00/den0,g010=z0.s01/den0,g110=z0.s11/den0;
  I g00=centered<N>(g000,g00a,X,X0),g01=centered<N>(g010,g01a,X,X0),g11=centered<N>(g110,g11a,X,X0),k=centered<N>(z0.k,za.k,X,X0);e.speed=speed_from(g00,g01,g11,k,e.eig,e.reason);if(e.speed>=lo(BETA_TARGET)){e.status="PASS";e.reason="BETA04";}else e.status="SPLIT";return e;
 }catch(const std::exception&x){e.status="SPLIT";e.reason=std::string("EXC_")+x.what();return e;}
}

struct PolarRootData4{I R,r,FR,Fr,rt,rA,rD,R0,r0;};
using PolarRootKey4=std::tuple<long long,long long,long long,long long,long double,long double,long double,long double,long double,long double>;
static std::map<PolarRootKey4,PolarRootData4> polar_root_cache4;
static Eval eval_polar4(const Box&b,const I&M,const I&cl1,const I&Delta,const I&Amin,const I&Acut){
 Eval e;e.kind="polar";I theta=I(2)*PI_RIG()*full_cell(b.ti,b.tn),A=Amin+(Acut-Amin)*full_cell(b.i1,b.n1),phi=I(2)*PI_RIG()*full_cell(b.i2,b.n2),Rbar(dn(b.Rlo),up(b.Rhi)),Dcert(dn(b.Dlo),up(b.Dhi));
 I cBG=cl1+Delta,c=-cBG;
 try{
  PolarRootKey4 key{b.ti,b.tn,b.i1,b.n1,b.Rlo,b.Rhi,b.Dlo,b.Dhi,lo(Delta),hi(Delta)};PolarRootData4 rd;auto it=polar_root_cache4.find(key);
  if(it!=polar_root_cache4.end()){rd=it->second;}else{
   auto sc2=sincos_cached(I(2)*theta);rd.R=contract_R_cos(sc2.second,square_range(A),Rbar,Dcert,M,cBG);if(!(lo(rd.R)>0)){e.status="SPLIT";e.reason="R_ZERO";return e;}
   rd.r=sqrtT(rd.R);rd.FR=dFfun_cos(rd.R,sc2.second,M,cBG);if(!(hi(rd.FR)<0))rd.FR=Dcert;rd.Fr=I(2)*rd.r*rd.FR;if(!(hi(rd.Fr)<0)){e.status="SPLIT";e.reason="FR";return e;}
   rd.rt=-Ftheta_sc(rd.R,sc2.second,sc2.first,M)/rd.Fr;rd.rA=I(2)*A/rd.Fr;rd.rD=rd.r/rd.FR;
   I theta0=pointmid(theta),A0=pointmid(A),D0=pointmid(Delta),cBG0=cl1+D0;auto sc20=sincos_cached(I(2)*theta0);rd.R0=contract_R_cos(sc20.second,A0*A0,Rbar,Dcert,M,cBG0);rd.r0=sqrtT(rd.R0);
   polar_root_cache4.emplace(key,rd);
  }
  e.Rlo=lo(rd.R);e.Rhi=hi(rd.R);constexpr int N=4;std::array<I,N>X={theta,A,phi,Delta},X0={pointmid(theta),pointmid(A),pointmid(phi),pointmid(Delta)};
  AD<N>th=var<N>(theta,0),aa=var<N>(A,1),ph=var<N>(phi,2),Mad(M),cad(c),cbgad(cBG);cad.d[3]=I(-1);cbgad.d[3]=I(1);
  AD<N>rad=custom_ad<N>(rd.r,{rd.rt,rd.rA,I(0),rd.rD});
  V4<AD<N>>wad=chart_state(th,rad,aa,ph,Mad);ScaledGen<AD<N>>za=scaled_generator(wad,Mad,cad);AD<N>sea=sigma_energy_polar(th,rad,aa,ph,Mad,cbgad);
  I cBG0=cl1+X0[3],c0=-cBG0;V4<I>w0=chart_state(X0[0],rd.r0,X0[1],X0[2],M);ScaledGen<I>z0=scaled_generator(w0,M,c0);I se0=sigma_energy_polar(X0[0],rd.r0,X0[1],X0[2],M,cBG0);
  I sigraw=centered<N>(z0.sig,za.sig,X,X0),sigenergy=centered<N>(se0,sea,X,X0),sig=intersectI(sigraw,sigenergy);if(!(hi(sig)<0)){e.status="SPLIT";e.reason="SIGMA";return e;}
  AD<N>sigT(sig);for(int j=0;j<N;++j)sigT.d[j]=intersectI(za.sig.d[j],sea.d[j]);AD<N>den=sigT*sigT;
  AD<N>bc(BETA_TARGET);
  AD<N>K00a=-za.s00-bc*(sigT*sigT)*za.k;
  AD<N>K01a=-za.s01;
  AD<N>K11a=-za.s11-bc*(sigT*sigT)*za.k;
  I sig0=intersectI(z0.sig,se0),K000=-z0.s00-(BETA_TARGET)*(sig0*sig0)*z0.k,K010=-z0.s01,K110=-z0.s11-(BETA_TARGET)*(sig0*sig0)*z0.k;
  I K00=centered<N>(K000,K00a,X,X0),K01=centered<N>(K010,K01a,X,X0),K11=centered<N>(K110,K11a,X,X0),detK=K00*K11-square_range(K01);
  if(lo(K00)>0&&lo(K11)>0&&lo(detK)>0){e.status="PASS";e.reason="SCALED_H_CENTERED";e.speed=lo(BETA_TARGET);e.hd00=lo(K00);e.hd11=lo(K11);e.hdet=lo(detK);return e;}
  AD<N>g00a=za.s00/den,g01a=za.s01/den,g11a=za.s11/den;I den0=sig0*sig0,g000=z0.s00/den0,g010=z0.s01/den0,g110=z0.s11/den0;
  I g00=centered<N>(g000,g00a,X,X0),g01=centered<N>(g010,g01a,X,X0),g11=centered<N>(g110,g11a,X,X0),k=centered<N>(z0.k,za.k,X,X0);e.speed=speed_from(g00,g01,g11,k,e.eig,e.reason);if(e.speed>=lo(BETA_TARGET)){e.status="PASS";e.reason="BETA04";}else e.status="SPLIT";return e;
 }catch(const std::exception&x){e.status="SPLIT";e.reason=std::string("EXC_")+x.what();return e;}
}
static Eval eval_polar_hdot4(const Box&b,const I&M,const I&cl1,const I&Delta,const I&Amin,const I&Acut){
 Eval e;e.kind="polar";I theta=I(2)*PI_RIG()*full_cell(b.ti,b.tn),A=Amin+(Acut-Amin)*full_cell(b.i1,b.n1),phi=I(2)*PI_RIG()*full_cell(b.i2,b.n2),Rbar(dn(b.Rlo),up(b.Rhi)),Dcert(dn(b.Dlo),up(b.Dhi));
 I cBG=cl1+Delta,c=-cBG;
 try{
  PolarRootKey4 key{b.ti,b.tn,b.i1,b.n1,b.Rlo,b.Rhi,b.Dlo,b.Dhi,lo(Delta),hi(Delta)};PolarRootData4 rd;auto it=polar_root_cache4.find(key);
  if(it!=polar_root_cache4.end()){rd=it->second;}else{
   auto sc2=sincos_cached(I(2)*theta);rd.R=contract_R_cos(sc2.second,square_range(A),Rbar,Dcert,M,cBG);if(!(lo(rd.R)>0)){e.status="SPLIT";e.reason="R_ZERO";return e;}
   rd.r=sqrtT(rd.R);rd.FR=dFfun_cos(rd.R,sc2.second,M,cBG);if(!(hi(rd.FR)<0))rd.FR=Dcert;rd.Fr=I(2)*rd.r*rd.FR;if(!(hi(rd.Fr)<0)){e.status="SPLIT";e.reason="FR";return e;}
   rd.rt=-Ftheta_sc(rd.R,sc2.second,sc2.first,M)/rd.Fr;rd.rA=I(2)*A/rd.Fr;rd.rD=rd.r/rd.FR;
   I theta0=pointmid(theta),A0=pointmid(A),D0=pointmid(Delta),cBG0=cl1+D0;auto sc20=sincos_cached(I(2)*theta0);rd.R0=contract_R_cos(sc20.second,A0*A0,Rbar,Dcert,M,cBG0);rd.r0=sqrtT(rd.R0);
   polar_root_cache4.emplace(key,rd);
  }
  e.Rlo=lo(rd.R);e.Rhi=hi(rd.R);constexpr int N=4;std::array<I,N>X={theta,A,phi,Delta},X0={pointmid(theta),pointmid(A),pointmid(phi),pointmid(Delta)};
  AD<N>th=var<N>(theta,0),aa=var<N>(A,1),ph=var<N>(phi,2),Mad(M),cad(c),cbgad(cBG);cad.d[3]=I(-1);cbgad.d[3]=I(1);
  AD<N>rad=custom_ad<N>(rd.r,{rd.rt,rd.rA,I(0),rd.rD});
  V4<AD<N>>wad=chart_state(th,rad,aa,ph,Mad);ScaledGen<AD<N>>za=scaled_generator(wad,Mad,cad);AD<N>sea=sigma_energy_polar(th,rad,aa,ph,Mad,cbgad);
  I cBG0=cl1+X0[3],c0=-cBG0;V4<I>w0=chart_state(X0[0],rd.r0,X0[1],X0[2],M);ScaledGen<I>z0=scaled_generator(w0,M,c0);I se0=sigma_energy_polar(X0[0],rd.r0,X0[1],X0[2],M,cBG0);
  I sigraw=centered<N>(z0.sig,za.sig,X,X0),sigenergy=centered<N>(se0,sea,X,X0),sig=intersectI(sigraw,sigenergy);if(!(hi(sig)<0)){e.status="SPLIT";e.reason="SIGMA";return e;}
  AD<N>sigT(sig);for(int j=0;j<N;++j)sigT.d[j]=intersectI(za.sig.d[j],sea.d[j]);AD<N>den=sigT*sigT;
  AD<N>g00a=za.s00/den,g01a=za.s01/den,g11a=za.s11/den;
  I h00d=-g00a.d[3]-BETA_TARGET*za.k.d[3],h01d=-g01a.d[3],h11d=-g11a.d[3]-BETA_TARGET*za.k.d[3];
  I detd=h00d*h11d-square_range(h01d);
  e.hd00=lo(h00d);e.hd11=lo(h11d);e.hdet=lo(detd);
  if(e.hd00>0 && e.hd11>0 && e.hdet>0){e.status="PASS";e.reason="HDOT_PSD";}else{e.status="SPLIT";e.reason="HDOT_UNRESOLVED";}return e;
 }catch(const std::exception&x){e.status="SPLIT";e.reason=std::string("EXC_")+x.what();return e;}
}
static Eval eval_cart4(const Box&b,const I&M,const I&cl1,const I&Delta,const I&Acut){
 Eval e;e.kind="cart";I theta=I(2)*PI_RIG()*full_cell(b.ti,b.tn),u1=Acut*(I(2)*full_cell(b.i1,b.n1)-I(1)),u2=Acut*(I(2)*full_cell(b.i2,b.n2)-I(1)),q=square_range(u1)+square_range(u2),target=Acut*Acut,Rbar(dn(b.Rlo),up(b.Rhi)),Dcert(dn(b.Dlo),up(b.Dhi));
 I cBG=cl1+Delta,c=-cBG;
 if(lo(q)>hi(target)){e.status="EMPTY";e.reason="OUTSIDE";return e;}e.kind=hi(q)<=lo(target)?"inside":"boundary";
 try{
  auto sc2=sincos_rig(I(2)*theta);I R=contract_R_cos(sc2.second,q,Rbar,Dcert,M,cBG);e.Rlo=lo(R);e.Rhi=hi(R);if(!(lo(R)>0)){e.status="SPLIT";e.reason="R_ZERO";return e;}
  I r=sqrtT(R),FR=dFfun_cos(R,sc2.second,M,cBG);if(!(hi(FR)<0))FR=Dcert;I Fr=I(2)*r*FR;if(!(hi(Fr)<0)){e.status="SPLIT";e.reason="FR";return e;}
  I rt=-Ftheta_sc(R,sc2.second,sc2.first,M)/Fr,ru1=I(2)*u1/Fr,ru2=I(2)*u2/Fr,rD=r/FR;
  constexpr int N=4;std::array<I,N>X={theta,u1,u2,Delta},X0={pointmid(theta),pointmid(u1),pointmid(u2),pointmid(Delta)};
  AD<N>th=var<N>(theta,0),a1=var<N>(u1,1),a2=var<N>(u2,2),Mad(M),cad(c),cbgad(cBG);cad.d[3]=I(-1);cbgad.d[3]=I(1);AD<N>rad=custom_ad<N>(r,{rt,ru1,ru2,rD});
  V4<AD<N>>wad=chart_state_cart(th,rad,a1,a2,Mad);ScaledGen<AD<N>>za=scaled_generator(wad,Mad,cad);AD<N>sea=sigma_energy_cart(th,rad,a1,a2,Mad,cbgad);
  I cBG0=cl1+X0[3],c0=-cBG0;auto sc20=sincos_rig(I(2)*X0[0]);I R0=contract_R_cos(sc20.second,X0[1]*X0[1]+X0[2]*X0[2],Rbar,Dcert,M,cBG0),r0=sqrtT(R0);V4<I>w0=chart_state_cart(X0[0],r0,X0[1],X0[2],M);ScaledGen<I>z0=scaled_generator(w0,M,c0);I se0=sigma_energy_cart(X0[0],r0,X0[1],X0[2],M,cBG0);
  I sigraw=centered<N>(z0.sig,za.sig,X,X0),sigenergy=centered<N>(se0,sea,X,X0),sig=intersectI(sigraw,sigenergy);if(!(hi(sig)<0)){e.status="SPLIT";e.reason="SIGMA";return e;}
  AD<N>sigT(sig);for(int j=0;j<N;++j)sigT.d[j]=intersectI(za.sig.d[j],sea.d[j]);AD<N>den=sigT*sigT;
  AD<N>g00a=za.s00/den,g01a=za.s01/den,g11a=za.s11/den;
  I h00d=-g00a.d[3]-BETA_TARGET*za.k.d[3],h01d=-g01a.d[3],h11d=-g11a.d[3]-BETA_TARGET*za.k.d[3];
  I detd=h00d*h11d-square_range(h01d);
  e.hd00=lo(h00d);e.hd11=lo(h11d);e.hdet=lo(detd);
  if(e.hd00>0 && e.hd11>0 && e.hdet>0){e.status="PASS";e.reason="HDOT_PSD";}else{e.status="SPLIT";e.reason="HDOT_UNRESOLVED";}return e;
 }catch(const std::exception&x){e.status="SPLIT";e.reason=std::string("EXC_")+x.what();return e;}
}
static Eval eval_radial(const Box&b,const I&M,const I&c,const I&cBG,const I&Ainner,const I&Aouter){
 Eval e;e.kind="radial";
 I theta=I(2)*PI_RIG()*full_cell(b.ti,b.tn),phi=I(2)*PI_RIG()*full_cell(b.i2,b.n2),Rbar(dn(b.Rlo),up(b.Rhi));
 I rtop=sqrtT(Rbar),r=rtop*full_cell(b.i1,b.n1),Ainner2=Ainner*Ainner,Aouter2=Aouter*Aouter;
 try{
  I R=square_range(r),Fnat=Ffun(R,theta,M,cBG);
  if(hi(Fnat)<=lo(Aouter2)){e.status="OUTER";e.reason="F_AT_MOST_OUTER_THRESHOLD";return e;}
  if(!(lo(Fnat)>=hi(Ainner2))){e.status="SPLIT";e.reason="OVERLAP_ROUTING_UNDECIDED";return e;}
  if(!(lo(Fnat)>0)){e.status="SPLIT";e.reason="F_NOT_POSITIVE";return e;}
  constexpr int N=3;std::array<I,N>X={theta,r,phi},X0={pointmid(theta),pointmid(r),pointmid(phi)};
  AD<N>th=var<N>(theta,0),rad=var<N>(r,1),ph=var<N>(phi,2),Mad(M),cad(c),cbgad(cBG);
  AD<N>Fad=Ffun(rad*rad,th,Mad,cbgad);if(!(lo(Fad.v)>0)){e.status="SPLIT";e.reason="F_AD_NOT_POSITIVE";return e;}AD<N>Aad=sqrtT(Fad);
  V4<AD<N>>wad=chart_state(th,rad,Aad,ph,Mad);ScaledGen<AD<N>>za=scaled_generator(wad,Mad,cad);AD<N>sea=sigma_energy_polar(th,rad,Aad,ph,Mad,cbgad);
  I R0=X0[1]*X0[1],F0=Ffun(R0,X0[0],M,cBG);if(!(lo(F0)>0)){e.status="SPLIT";e.reason="F0_NOT_POSITIVE";return e;}I A0=sqrtT(F0);
  V4<I>w0=chart_state(X0[0],X0[1],A0,X0[2],M);ScaledGen<I>z0=scaled_generator(w0,M,c);I se0=sigma_energy_polar(X0[0],X0[1],A0,X0[2],M,cBG);
  I Fmv=centered<N>(F0,Fad,X,X0);
  if(hi(Fmv)<=lo(Aouter2)){e.status="OUTER";e.reason="CENTERED_F_AT_MOST_OUTER_THRESHOLD";return e;}
  if(!(lo(Fmv)>=hi(Ainner2))){e.status="SPLIT";e.reason="CENTERED_OVERLAP_ROUTING_UNDECIDED";return e;}
  I sigraw=centered<N>(z0.sig,za.sig,X,X0),sigenergy=centered<N>(se0,sea,X,X0),sig=intersectI(sigraw,sigenergy);if(!(hi(sig)<0)){e.status="SPLIT";e.reason="SIGMA";return e;}
  AD<N>sigT(sig);for(int j=0;j<N;++j)sigT.d[j]=intersectI(za.sig.d[j],sea.d[j]);AD<N>den=sigT*sigT;
  AD<N>g00a=za.s00/den,g01a=za.s01/den,g11a=za.s11/den;I sig0=intersectI(z0.sig,se0),den0=sig0*sig0,g000=z0.s00/den0,g010=z0.s01/den0,g110=z0.s11/den0;
  I g00=centered<N>(g000,g00a,X,X0),g01=centered<N>(g010,g01a,X,X0),g11=centered<N>(g110,g11a,X,X0),k=centered<N>(z0.k,za.k,X,X0);
  e.speed=speed_from(g00,g01,g11,k,e.eig,e.reason);if(e.speed>=lo(BETA_TARGET)){e.status="PASS";e.reason="BETA04";}else e.status="SPLIT";return e;
 }catch(const std::exception&x){e.status="SPLIT";e.reason=std::string("EXC_")+x.what();return e;}
}
static std::array<Box,2> split_radial(const Box&b,long double Aouter,const std::string&reason){
 long double rtop=sqrtl(std::max((long double)0,b.Rhi)),wt=2*acosl(-1.0L)*std::max(rtop,1e-18L)/b.tn,wr=rtop/b.n1,wp=2*acosl(-1.0L)*std::max(Aouter,1e-18L)/b.n2;
 bool routing=(reason=="OVERLAP_ROUTING_UNDECIDED"||reason=="CENTERED_OVERLAP_ROUTING_UNDECIDED"||reason=="F_NOT_POSITIVE"||reason=="F_AD_NOT_POSITIVE"||reason=="F0_NOT_POSITIVE");
 char axis;if(routing)axis=(wt>=wr?'T':'R');else axis=(wt>=wr&&wt>=wp?'T':(wr>=wp?'R':'P'));
 Box x=b,y=b;x.depth=y.depth=b.depth+1;x.path=b.path+axis+'0';y.path=b.path+axis+'1';
 if(axis=='T'){x.ti=2*b.ti;y.ti=2*b.ti+1;x.tn=y.tn=2*b.tn;}
 else if(axis=='R'){x.i1=2*b.i1;y.i1=2*b.i1+1;x.n1=y.n1=2*b.n1;}
 else{x.i2=2*b.i2;y.i2=2*b.i2+1;x.n2=y.n2=2*b.n2;}
 return{x,y};
}
static std::array<Box,2> split_polar(const Box&b,long double Amin,long double Acut){long double wt=2*acosl(-1.0L)/b.tn,wa=(Acut-Amin)/b.n1,Ahi=Amin+(Acut-Amin)*((long double)(b.i1+1)/(long double)b.n1),wp=2*acosl(-1.0L)*std::max(Ahi,(long double)1e-18L)/b.n2;Box x=b,y=b;x.depth=y.depth=b.depth+1;char axis;if(wt>=wa&&wt>=wp){axis='T';x.ti=2*b.ti;y.ti=2*b.ti+1;x.tn=y.tn=2*b.tn;}else if(wa>=wp){axis='A';x.i1=2*b.i1;y.i1=2*b.i1+1;x.n1=y.n1=2*b.n1;}else{axis='P';x.i2=2*b.i2;y.i2=2*b.i2+1;x.n2=y.n2=2*b.n2;}x.path=b.path+axis+'0';y.path=b.path+axis+'1';return{x,y};}
static std::array<Box,2> split_cart(const Box&b,long double Acut,const std::string&kind){long double wt=2*acosl(-1.0L)/b.tn,w1=2*Acut/b.n1,w2=2*Acut/b.n2;if(kind=="boundary")wt*=0.5L;Box x=b,y=b;x.depth=y.depth=b.depth+1;char axis;if(wt>=w1&&wt>=w2){axis='T';x.ti=2*b.ti;y.ti=2*b.ti+1;x.tn=y.tn=2*b.tn;}else if(w1>=w2){axis='X';x.i1=2*b.i1;y.i1=2*b.i1+1;x.n1=y.n1=2*b.n1;}else{axis='Y';x.i2=2*b.i2;y.i2=2*b.i2+1;x.n2=y.n2=2*b.n2;}x.path=b.path+axis+'0';y.path=b.path+axis+'1';return{x,y};}
int main(int argc,char**argv){
 if(argc<7){std::cerr<<"usage mode input summary max_seeds A_low A_high [maxdepth] [maxprocessed] [delta_lo_num delta_hi_num delta_den]\n";return 2;}
 std::string mode=argv[1],inp=argv[2],out=argv[3];long long maxseeds=std::stoll(argv[4]);long double amin=std::stold(argv[5]),acut=std::stold(argv[6]);int maxdepth=argc>7?std::stoi(argv[7]):24;long long maxprocessed=argc>8?std::stoll(argv[8]):50000000; long long dlo=argc>9?std::stoll(argv[9]):0,dhi=argc>10?std::stoll(argv[10]):0,dden=argc>11?std::stoll(argv[11]):1; if(dden<=0||dlo<0||dhi<dlo){std::cerr<<"bad delta interval\n";return 2;} BETA_TARGET=I(0);
 std::set<std::string> patches; if(const char* pf=std::getenv("PATCHFILE")){std::ifstream pp(pf);std::string z;while(std::getline(pp,z)){if(!z.empty())patches.insert(z);}}
 std::ifstream f(inp);std::string line;std::getline(f,line);std::vector<Box>seeds;while(std::getline(f,line)&&((long long)seeds.size()<maxseeds||maxseeds<0)){std::istringstream q(line);Box b;q>>b.seed>>b.ti>>b.tn>>b.i1>>b.n1>>b.i2>>b.n2>>b.Rlo>>b.Rhi>>b.Dlo>>b.Dhi>>b.depth;b.path="";seeds.push_back(b);}
 I gamma=I(541)/I(1000),ms=mu_small(gamma),M=I(1)-ms,x=I(1)-ms-gamma,cl1=x*x/I(2)+(I(1)-ms)/(I(1)-gamma)+ms/gamma,Delta=I((long double)dlo,(long double)dhi)/I((long double)dden),cBG=cl1+Delta,c=-cBG,Amin(dn(amin),up(amin)),Acut(dn(acut),up(acut));
 long long processed=0,pass=0,empty=0,outer=0,fail=0,splits=0;std::map<std::string,long long>reasons;long double minspeed=INFINITY,minhd00=INFINITY,minhd11=INFINITY,minhdet=INFINITY;auto t0=std::chrono::steady_clock::now();std::ofstream ledger(out+".ledger.jsonl");
 for(const auto&seed:seeds){std::deque<Box>qq;qq.push_back(seed);bool seedfail=false;while(!qq.empty()){Box b=qq.back();qq.pop_back();if(++processed>maxprocessed){seedfail=true;reasons["MAX_PROCESSED"]++;break;}Eval e;if(mode=="polar")e=eval_polar4(b,M,cl1,Delta,Amin,Acut);else if(mode=="polarhdot")e=eval_polar_hdot4(b,M,cl1,Delta,Amin,Acut);else if(mode=="cart")e=eval_cart4(b,M,cl1,Delta,Acut);else if(mode=="radial")e=eval_radial(b,M,c,cBG,Amin,Acut);else{std::cerr<<"bad mode\n";return 2;}reasons[e.reason]++;
  auto emit=[&](const std::string&st){ledger<<"{\"seed\":"<<b.seed<<",\"depth\":"<<b.depth<<",\"path\":\""<<b.path<<"\",\"ti\":"<<b.ti<<",\"tn\":"<<b.tn<<",\"i1\":"<<b.i1<<",\"n1\":"<<b.n1<<",\"i2\":"<<b.i2<<",\"n2\":"<<b.n2<<",\"status\":\""<<st<<"\"";};
  if(e.status=="PASS"){pass++;minspeed=std::min(minspeed,e.speed);minhd00=std::min(minhd00,e.hd00);minhd11=std::min(minhd11,e.hd11);minhdet=std::min(minhdet,e.hdet);emit("PASS");ledger<<",\"speed_lo\":\""<<std::setprecision(25)<<e.speed<<"\",\"hd00_lo\":\""<<e.hd00<<"\",\"hd11_lo\":\""<<e.hd11<<"\",\"hdet_lo\":\""<<e.hdet<<"\"}\n";}
  else if(e.status=="EMPTY"){empty++;emit("EMPTY");ledger<<"}\n";}
  else if(e.status=="OUTER"){outer++;emit("OUTER_COVERED");ledger<<"}\n";}
  else if(b.depth<maxdepth){std::array<Box,2>ch=mode=="polar"?split_polar(b,amin,acut):(mode=="cart"?split_cart(b,acut,e.kind):split_radial(b,acut,e.reason));qq.push_back(ch[0]);qq.push_back(ch[1]);splits++;}
  else{if(patches.count(b.path)){pass++;emit("PASS_PATCH");ledger<<",\"patch\":true}\n";continue;}seedfail=true;fail++;emit("FAIL");ledger<<",\"failure\":\""<<e.reason<<"\",\"speed\":\""<<e.speed<<"\"}\n";break;}}
  if(seedfail&&fail>=20)break;}
 ledger.close();double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();std::ofstream o(out);o<<"{\n\"status\":\""<<(fail==0&&processed<=maxprocessed?"CERTIFIED_PASS":"INCOMPLETE")<<"\",\n\"mode\":\""<<mode<<"\",\n\"gamma\":\"541/1000\",\n\"delta_lo_num\":"<<dlo<<",\n\"delta_hi_num\":"<<dhi<<",\n\"delta_den\":"<<dden<<",\n\"A_low\":\""<<amin<<"\",\n\"A_high\":\""<<acut<<"\",\n\"selected_seeds\":"<<seeds.size()<<",\n\"processed_boxes\":"<<processed<<",\n\"pass_boxes\":"<<pass<<",\n\"outer_covered_boxes\":"<<outer<<",\n\"empty_boxes\":"<<empty<<",\n\"split_events\":"<<splits<<",\n\"failures\":"<<fail<<",\n\"min_speed_lower\":\""<<std::setprecision(25)<<minspeed<<"\",\n\"min_K00_lower\":\""<<minhd00<<"\",\n\"min_K11_lower\":\""<<minhd11<<"\",\n\"min_detK_lower\":\""<<minhdet<<"\",\n\"elapsed_seconds\":"<<elapsed<<",\n\"reason_counts\":{";bool first=true;for(auto&kv:reasons){if(!first)o<<",";first=false;o<<"\""<<kv.first<<"\":"<<kv.second;}o<<"}\n}\n";o.close();std::ifstream rr(out);std::cout<<rr.rdbuf();return fail?3:0;
}
