#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/rounded_transc.hpp>
#include <boost/numeric/interval/checking.hpp>
#include <array>
#include <vector>
#include <deque>
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cfenv>
#include <limits>
#include <string>
#include <algorithm>
#include <chrono>
#include <map>
#include <set>
#include <cstdlib>
#include <stdexcept>
#include <tuple>
#pragma STDC FENV_ACCESS ON
namespace bn=boost::numeric;
using Rounding=bn::interval_lib::save_state<bn::interval_lib::rounded_transc_std<long double>>;
using Checking=bn::interval_lib::checking_base<long double>;
using Policies=bn::interval_lib::policies<Rounding,Checking>;
using I=bn::interval<long double,Policies>;
static inline long double lo(const I&x){return x.lower();}
static inline long double hi(const I&x){return x.upper();}
static inline long double dn(long double x){return std::nextafter(x,-std::numeric_limits<long double>::infinity());}
static inline long double up(long double x){return std::nextafter(x,std::numeric_limits<long double>::infinity());}
static inline long double absup(const I&x){return std::max(std::fabs(lo(x)),std::fabs(hi(x)));}
static inline I square_range(const I&x){if(lo(x)<=0&&hi(x)>=0){long double u=std::max(lo(x)*lo(x),hi(x)*hi(x));return I(0,up(u));}return x*x;}
static inline I full_cell(long long i,long long n){I d((long double)n);return I((long double)i)/d+I(0,1)/d;}
static inline I PI_RIG(){
 static const long double a=std::stold("3.14159265358979323846264338327950288419716939937510");
 static const long double b=std::stold("3.14159265358979323846264338327950288419716939937511");
 static const I p(dn(a),up(b)); return p;
}
static inline I hullI(const I&a,const I&b){return I(std::min(lo(a),lo(b)),std::max(hi(a),hi(b)));}
static inline I intersectI(const I&a,const I&b){long double l=std::max(lo(a),lo(b)),h=std::min(hi(a),hi(b));if(l>h)throw std::runtime_error("empty_intersection");return I(l,h);}
static std::pair<I,I> sincos_small(const I&y){I sy(0),cy(0),yp(1);long double fact=1;for(int m=0;m<=14;++m){int deg=2*m;if(m==0){yp=I(1);fact=1;}else{yp*=y*y;fact*=((long double)(deg-1))*deg;}I t=yp/I(fact);cy+=(m%2?-t:t);}long double ay=absup(y),r=1;for(int j=1;j<=30;++j)r*=ay/j;cy+=I(-up(r),up(r));yp=y;fact=1;for(int m=0;m<=14;++m){int deg=2*m+1;if(m>0){yp*=y*y;fact*=((long double)(deg-1))*deg;}I t=yp/I(fact);sy+=(m%2?-t:t);}r=1;for(int j=1;j<=31;++j)r*=ay/j;sy+=I(-up(r),up(r));return {sy,cy};}
static std::pair<I,I> sincos_rig(const I&x){I P=PI_RIG(),half=P/I(2),quarter=P/I(4);bool have=false;I so(0),co(0);for(int k=-2;k<=6;++k){I y=x-I(k)*half,adm(-hi(quarter),hi(quarter));if(hi(y)<lo(adm)||lo(y)>hi(adm))continue;auto sc=sincos_small(intersectI(y,adm));I ss=sc.first,cc=sc.second,s,c;int m=((k%4)+4)%4;if(m==0){s=ss;c=cc;}else if(m==1){s=cc;c=-ss;}else if(m==2){s=-ss;c=-cc;}else{s=-cc;c=ss;}if(!have){so=s;co=c;have=true;}else{so=hullI(so,s);co=hullI(co,c);}}if(!have)throw std::runtime_error("trig_reduce");return {so,co};}
using TrigKey=std::pair<long double,long double>;
static std::map<TrigKey,std::pair<I,I>> trig_cache;
static long long trig_cache_hits=0,trig_cache_misses=0;
static const std::pair<I,I>& sincos_cached(const I&x){TrigKey key{lo(x),hi(x)};auto it=trig_cache.find(key);if(it!=trig_cache.end()){++trig_cache_hits;return it->second;}auto sc=sincos_rig(x);++trig_cache_misses;return trig_cache.emplace(key,std::move(sc)).first->second;}
static inline I sinR(const I&x){return sincos_cached(x).first;} static inline I cosR(const I&x){return sincos_cached(x).second;} static inline I sqrtT(const I&x){if(lo(x)<0)throw std::runtime_error("sqrt_negative");return sqrt(x);}

template<int N> struct AD{I v;std::array<I,N>d;AD():v(0){d.fill(I(0));}AD(const I&x):v(x){d.fill(I(0));}};
template<int N> static AD<N> var(const I&x,int k){AD<N>a(x);a.d[k]=I(1);return a;}
template<int N> static AD<N> operator+(const AD<N>&a,const AD<N>&b){AD<N>q;q.v=a.v+b.v;for(int i=0;i<N;++i)q.d[i]=a.d[i]+b.d[i];return q;}
template<int N> static AD<N> operator-(const AD<N>&a){AD<N>q;q.v=-a.v;for(int i=0;i<N;++i)q.d[i]=-a.d[i];return q;}
template<int N> static AD<N> operator-(const AD<N>&a,const AD<N>&b){return a+(-b);} 
template<int N> static AD<N> operator*(const AD<N>&a,const AD<N>&b){AD<N>q;q.v=a.v*b.v;for(int i=0;i<N;++i)q.d[i]=a.d[i]*b.v+a.v*b.d[i];return q;}
template<int N> static AD<N> inv(const AD<N>&a){AD<N>q;q.v=I(1)/a.v;for(int i=0;i<N;++i)q.d[i]=-a.d[i]*q.v*q.v;return q;}
template<int N> static AD<N> operator/(const AD<N>&a,const AD<N>&b){return a*inv(b);} 
template<int N> static AD<N> sqrtT(const AD<N>&a){AD<N>q;q.v=sqrtT(a.v);for(int i=0;i<N;++i)q.d[i]=a.d[i]/(I(2)*q.v);return q;}
template<int N> static std::pair<AD<N>,AD<N>> sincosTpair(const AD<N>&a){
 auto sc=sincos_cached(a.v); AD<N>s,c; s.v=sc.first; c.v=sc.second;
 for(int i=0;i<N;++i){s.d[i]=c.v*a.d[i];c.d[i]=-s.v*a.d[i];} return {s,c};
}
template<int N> static AD<N> sinT(const AD<N>&a){return sincosTpair(a).first;}
template<int N> static AD<N> cosT(const AD<N>&a){return sincosTpair(a).second;}
static std::pair<I,I> sincosTpair(const I&a){return sincos_cached(a);}
static I sinT(const I&a){return sincos_cached(a).first;}static I cosT(const I&a){return sincos_cached(a).second;}

template<class T> struct TD{T v,d;TD():v(T(I(0))),d(T(I(0))){}TD(const T&x):v(x),d(T(I(0))){}TD(const T&x,const T&y):v(x),d(y){}};
template<class T> static TD<T> operator+(const TD<T>&a,const TD<T>&b){return TD<T>(a.v+b.v,a.d+b.d);}template<class T> static TD<T> operator-(const TD<T>&a){return TD<T>(-a.v,-a.d);}template<class T> static TD<T> operator-(const TD<T>&a,const TD<T>&b){return a+(-b);}template<class T> static TD<T> operator*(const TD<T>&a,const TD<T>&b){return TD<T>(a.v*b.v,a.d*b.v+a.v*b.d);}template<class T> static TD<T> operator/(const TD<T>&a,const TD<T>&b){return TD<T>(a.v/b.v,(a.d*b.v-a.v*b.d)/(b.v*b.v));}
template<class T> static TD<T> sqrtT(const TD<T>&a){T q=sqrtT(a.v);return TD<T>(q,a.d/(T(I(2))*q));}

template<class T> static T C(long double x){return T(I(x));}
template<class T> using V4=std::array<T,4>;
template<class T> static T omega(const V4<T>&a,const V4<T>&b){return a[0]*b[2]+a[1]*b[3]-a[2]*b[0]-a[3]*b[1];}
template<class T> static V4<T> project(const V4<T>&x,const V4<T>&Y,const V4<T>&F,const T&sig){T aa=omega(x,F)/sig,bb=omega(x,Y)/sig;V4<T>q;for(int i=0;i<4;++i)q[i]=x[i]-aa*Y[i]+bb*F[i];return q;}
template<class T> static V4<T> jq(const V4<T>&w){return {-w[1],w[0],w[3],-w[2]};}template<class T> static V4<T> kq(const V4<T>&w){return {-w[3],w[2],-w[1],w[0]};}

template<class T> static V4<T> rhs_jac_scalar(const V4<T>&y,const T&mu,const T&c,std::array<std::array<T,4>,4>&J){
 T z1=y[0],z2=y[1],p1=y[2],p2=y[3];T x0=mu*z2,x1=z1*z1,x2=z2*z2,x3=x1+x2,x4=C<T>(2)*x3,x5=mu*z1,x6=C<T>(8)*c;T x7=p1*z2,x8=C<T>(4)*z1,x9=-C<T>(4)*x1+C<T>(4)*x2+C<T>(4)*(x3*x3)+C<T>(1);T x10=C<T>(1)/sqrtT(x9),x11=C<T>(8)*x10,x12=x10*x10*x10,x13=C<T>(2)*x1,x14=C<T>(2)*x2,x15=x13+x14;T x16=x15-C<T>(1),x17=x12*x16,x18=C<T>(16)*x3,x19=p2*z2,x20=x15+C<T>(1),x21=x0*x20;T x22=x12*x18,x23=x8*z2,x24=-x23,x25=mu+x13+C<T>(6)*x2,x26=-mu+C<T>(6)*x1+x14;T x27=p2*z1,x28=mu*x3,x29=x12*x28,x30=C<T>(16)*x1,x31=mu*x12,x32=C<T>(4)*x29;T x33=x10*x10*x10*x10*x10,x34=C<T>(48)*x28*x33,x35=C<T>(2)*c+C<T>(2)*mu*x10,x36=x0*z1;T x37=C<T>(192)*mu*x16*x20*x3*x33*z1*z2+C<T>(4)*p1*z1-C<T>(32)*x12*x21*z1-C<T>(32)*x17*x36-C<T>(4)*x19-C<T>(4)*x22*x36;T x38=C<T>(16)*x2;
 V4<T>f={p1/C<T>(4)-x0-x4*z2,p2/C<T>(4)+x4*z1-x5,mu*p2-C<T>(2)*p2*(C<T>(3)*x1+x2)+x11*x5-x17*x18*x5+x6*z1+x7*x8,mu*p1+C<T>(2)*p1*(x1+C<T>(3)*x2)+x0*x11-x19*x8-x21*x22+x6*z2};T zero=C<T>(0),quarter=C<T>(0.25L);
 J={{{x24,-x25,quarter,zero},{x26,x23,zero,quarter},{C<T>(4)*x1*(x16*x16)*x34-C<T>(4)*x16*x30*x31-C<T>(4)*x16*x32-C<T>(12)*x27-C<T>(4)*x29*x30+C<T>(4)*x35+C<T>(4)*x7,x37,x23,-x26},{x37,C<T>(4)*x2*(x20*x20)*x34-C<T>(4)*x20*x31*x38-C<T>(4)*x20*x32-C<T>(4)*x27-C<T>(4)*x29*x38+C<T>(4)*x35+C<T>(12)*x7,x25,x24}}};return f;
}
template<class T> struct Gen{T g00,g01,g11,sig,k;};
template<class T> static Gen<T> contact_weighted(const V4<T>&w,const T&mu,const T&c){std::array<std::array<T,4>,4>J;V4<T>f=rhs_jac_scalar(w,mu,c,J),Jf;for(int i=0;i<4;++i){Jf[i]=C<T>(0);for(int j=0;j<4;++j)Jf[i]=Jf[i]+J[i][j]*f[j];}V4<TD<T>>W,F,Y;for(int i=0;i<4;++i){W[i]=TD<T>(w[i],f[i]);F[i]=TD<T>(f[i],Jf[i]);Y[i]=W[i]/TD<T>(C<T>(2));}TD<T>sigj=omega(Y,F);V4<TD<T>>v1j=project(jq(W),Y,F,sigj),v2j=project(kq(W),Y,F,sigj);TD<T>kj=omega(v1j,v2j);std::array<std::array<T,2>,4>V,Vd;for(int i=0;i<4;++i){V[i][0]=v1j[i].v;V[i][1]=v2j[i].v;Vd[i][0]=v1j[i].d;Vd[i][1]=v2j[i].d;}V4<T>Yv;for(int i=0;i<4;++i)Yv[i]=w[i]/C<T>(2);T sig=sigj.v,k=kj.v;std::array<std::array<T,2>,2>N;for(int col=0;col<2;++col){V4<T>q;for(int i=0;i<4;++i){q[i]=-Vd[i][col];for(int j=0;j<4;++j)q[i]=q[i]+J[i][j]*V[j][col];}V4<T>qp=project(q,Yv,f,sig),v1,v2;for(int i=0;i<4;++i){v1[i]=V[i][0];v2[i]=V[i][1];}N[0][col]=omega(qp,v2);N[1][col]=-omega(qp,v1);}return {N[1][0],(N[1][1]-N[0][0])/C<T>(2),-N[0][1],sig,k};}


template<class T> struct ScaledGen{T s00,s01,s11,sig,k;};
template<class T> static V4<T> matvec4(const std::array<std::array<T,4>,4>&A,const V4<T>&x){V4<T>y;for(int i=0;i<4;++i){y[i]=C<T>(0);for(int j=0;j<4;++j)y[i]=y[i]+A[i][j]*x[j];}return y;}
template<class T> static ScaledGen<T> scaled_generator(const V4<T>&w,const T&mu,const T&c){
 std::array<std::array<T,4>,4>J;V4<T>f=rhs_jac_scalar(w,mu,c,J),Y,x1=jq(w),x2=kq(w),qf1=jq(f),qf2=kq(f);
 for(int i=0;i<4;++i)Y[i]=w[i]/C<T>(2);
 T sig=omega(Y,f);V4<T>LY=matvec4(J,Y),lx1=matvec4(J,x1),lx2=matvec4(J,x2);T a1=omega(x1,f),a2=omega(x2,f);V4<T>V1,V2,Q1,Q2;
 for(int i=0;i<4;++i){V1[i]=sig*x1[i]-a1*Y[i];V2[i]=sig*x2[i]-a2*Y[i];Q1[i]=sig*(lx1[i]-qf1[i])-a1*LY[i];Q2[i]=sig*(lx2[i]-qf2[i])-a2*LY[i];}
 T s00=-omega(Q1,V1),s11=-omega(Q2,V2),s01=-(omega(Q2,V1)+omega(Q1,V2))/C<T>(2),kk=C<T>(0);for(int i=0;i<4;++i)kk=kk+w[i]*w[i];return{s00,s01,s11,sig,kk};
}
static I sqsafe(const I&x){return square_range(x);}template<int N>static AD<N> sqsafe(const AD<N>&x){AD<N>q;q.v=square_range(x.v);for(int i=0;i<N;++i)q.d[i]=I(2)*x.v*x.d[i];return q;}
template<class T> static T dF_generic(const T&R,const T&theta,const T&M,const T&cBG){T q=cosT(C<T>(2)*theta),D=C<T>(4)*R*R-C<T>(4)*R*q+C<T>(1),dD=C<T>(8)*R-C<T>(4)*q,sd=sqrtT(D);return C<T>(12)*R*R+M*M-C<T>(8)*M*R*q-C<T>(2)*cBG+C<T>(2)*M/sd-M*R*dD/(sd*sd*sd);}
template<class T> static T sigma_energy_cart(const T&theta,const T&r,const T&u1,const T&u2,const T&M,const T&cBG){T R=r*r;auto st=sincosTpair(theta);T z1=r*st.second,z2=r*st.first,dR=dF_generic(R,theta,M,cBG),b3u=(-C<T>(2)*R*z2)*u1+(C<T>(2)*R*z1)*u2;return -C<T>(2)*(sqsafe(u1)+sqsafe(u2))-C<T>(4)*b3u+C<T>(2)*R*dR;}
template<class T> static T sigma_energy_polar(const T&theta,const T&r,const T&A,const T&phi,const T&M,const T&cBG){auto sp=sincosTpair(phi);return sigma_energy_cart(theta,r,A*sp.second,A*sp.first,M,cBG);}

template<class T> static T mu_small(const T&g){return g*g*g*(g*g-C<T>(3)*g+C<T>(3))/(C<T>(1)-C<T>(2)*g+g*g+C<T>(2)*g*g*g-g*g*g*g);}
template<class T> static T Ffun_cos(const T&R,const T&qcos,const T&M,const T&cBG){T D=C<T>(4)*R*R-C<T>(4)*R*qcos+C<T>(1);return C<T>(4)*R*R*R+M*M*R-C<T>(4)*M*R*R*qcos-C<T>(2)*cBG*R+(C<T>(1)-M)+C<T>(2)*M*R/sqrtT(D);}
template<class T> static T Ffun(const T&R,const T&theta,const T&M,const T&cBG){return Ffun_cos(R,cosT(C<T>(2)*theta),M,cBG);}
template<class T> static V4<T> chart_state(const T&theta,const T&r,const T&A,const T&phi,const T&M){auto st=sincosTpair(theta),sp=sincosTpair(phi);T z1=r*st.second,z2=r*st.first,R=z1*z1+z2*z2,u1=A*sp.second,u2=A*sp.first,b1=-(C<T>(2)*R+M)*z2,b2=(C<T>(2)*R-M)*z1;return {z1,z2,C<T>(4)*(u1-b1),C<T>(4)*(u2-b2)};}

template<int N> static I centered(const I&f0,const AD<N>&fa,const std::array<I,N>&X,const std::array<I,N>&X0){I q=f0;for(int i=0;i<N;++i)q+=fa.d[i]*(X[i]-X0[i]);return q;}

static I dFfun_cos(const I&R,const I&q,const I&M,const I&cBG){I D=I(4)*R*R-I(4)*R*q+I(1),dD=I(8)*R-I(4)*q;I sd=sqrtT(D);return I(12)*R*R+M*M-I(8)*M*R*q-I(2)*cBG+I(2)*M/sd-M*R*dD/(sd*sd*sd);}
static I dFfun(const I&R,const I&theta,const I&M,const I&cBG){return dFfun_cos(R,cosR(I(2)*theta),M,cBG);}
static I Ftheta_sc(const I&R,const I&q,const I&s,const I&M){I D=I(4)*R*R-I(4)*R*q+I(1),sd=sqrtT(D);return I(8)*M*R*R*s*(I(1)-I(1)/(sd*sd*sd));}
static I Ftheta(const I&R,const I&theta,const I&M){auto sc=sincos_rig(I(2)*theta);return Ftheta_sc(R,sc.second,sc.first,M);}
static I pointmid(const I&x){return I((lo(x)+hi(x))/2);}
static I contract_R_cos(const I&qcos,const I&q,const I&Rbar,const I&Dcert,const I&M,const I&cBG){
 if(!(hi(Dcert)<0))throw std::runtime_error("Dcert_not_negative");
 long double L=0,U=hi(Rbar),a=0,b=hi(Rbar);
 for(int j=0;j<30;++j){long double m=(a+b)/2;I h=Ffun_cos(I(m),qcos,M,cBG)-q;if(lo(h)>0)a=m;else b=m;}L=dn(a);
 a=0;b=hi(Rbar);
 for(int j=0;j<30;++j){long double m=(a+b)/2;I h=Ffun_cos(I(m),qcos,M,cBG)-q;if(hi(h)<0)b=m;else a=m;}U=up(b);
 I X(L,U);
 for(int j=0;j<8;++j){I deriv=dFfun_cos(X,qcos,M,cBG);if(!(hi(deriv)<0))deriv=Dcert;I mid=pointmid(X),N=mid-(Ffun_cos(mid,qcos,M,cBG)-q)/deriv;I Xn=intersectI(X,N);if(hi(Xn)-lo(Xn)>=0.9999999999L*(hi(X)-lo(X)))break;X=Xn;}
 return X;
}
static I contract_R(const I&theta,const I&q,const I&Rbar,const I&Dcert,const I&M,const I&cBG){return contract_R_cos(cosR(I(2)*theta),q,Rbar,Dcert,M,cBG);}
template<int N> static AD<N> custom_ad(const I&v,const std::array<I,N>&d){AD<N>a(v);a.d=d;return a;}
template<class T> static V4<T> chart_state_cart(const T&theta,const T&r,const T&u1,const T&u2,const T&M){auto st=sincosTpair(theta);T z1=r*st.second,z2=r*st.first,R=z1*z1+z2*z2,b1=-(C<T>(2)*R+M)*z2,b2=(C<T>(2)*R-M)*z1;return {z1,z2,C<T>(4)*(u1-b1),C<T>(4)*(u2-b2)};}
struct Box{long long seed,ti,tn,i1,n1,i2,n2;long double Rlo,Rhi,Dlo,Dhi;int depth;std::string path;};
struct Eval{std::string status,reason,kind;long double speed=-INFINITY,eig=-INFINITY,Rlo=NAN,Rhi=NAN,hd00=-INFINITY,hd11=-INFINITY,hdet=-INFINITY;};
struct PolarRootData{I R,r,FR,Fr,rt,rA,R0,r0;};
using PolarRootKey=std::tuple<long long,long long,long long,long long,long double,long double,long double,long double>;
static std::map<PolarRootKey,PolarRootData> polar_root_cache;
static long long polar_cache_hits=0,polar_cache_misses=0;
static long double speed_from(const I&g00,const I&g01,const I&g11,const I&k,long double&eig,std::string&reason){if(!(lo(k)>0)){reason="K";return -INFINITY;}if(!(hi(g00)<0)){reason="G00";return -INFINITY;}I p=-g00,q=-g01,r=-g11,s=r-square_range(q)/p;if(!(lo(s)>0)){reason="SCHUR";return -INFINITY;}I det=p*s,trace=p+r;long double best=-INFINITY;if(lo(det)>0&&hi(trace)>0)best=std::max(best,lo(I(lo(det))/I(hi(trace))));I disc=square_range(p-r)+I(4)*square_range(q),direct=(trace-sqrtT(disc))/I(2);best=std::max(best,lo(direct));long double aq=absup(q);best=std::max(best,dn(std::min(lo(p)-aq,lo(r)-aq)));I l=q/p,u=square_range(l),factor=I(2)/(I(2)+u+sqrtT(u*u+I(4)*u));best=std::max(best,lo(I(std::min(lo(p),lo(s)))*factor));eig=best;reason="SPEED";return best>0&&hi(k)>0?lo(I(best)/I(hi(k))):-INFINITY;}

struct FlowEval { bool ok=false; long double th_hi=1e300L, ad_hi=1e300L, ad_lo=-1e300L; };
static FlowEval eval_flow_box(const I&theta,const I&A,const I&phi,const I&M,const I&c,const I&cBG,const I&Rbar,const I&Dcert){
 FlowEval e;
 try{
  I R=contract_R(theta,square_range(A),Rbar,Dcert,M,cBG),r=sqrtT(R);
  V4<I>w=chart_state(theta,r,A,phi,M);
  std::array<std::array<I,4>,4>J; V4<I>f=rhs_jac_scalar(w,M,c,J),Jf;
  for(int i=0;i<4;++i){Jf[i]=I(0);for(int j=0;j<4;++j)Jf[i]+=J[i][j]*f[j];}
  I u1=f[0],u2=f[1],th=(w[0]*u2-w[1]*u1)/R,ad=(u1*Jf[0]+u2*Jf[1])/A;
  e.th_hi=hi(th); e.ad_hi=hi(ad); e.ad_lo=lo(ad); e.ok=(hi(th)<0&&hi(ad)<0); return e;
 }catch(...){ return e; }
}
int main(){
 I gamma=I(541)/I(1000),ms=mu_small(gamma),M=I(1)-ms;
 I x=I(1)-ms-gamma,cl1=x*x/I(2)+(I(1)-ms)/(I(1)-gamma)+ms/gamma;
 I Delta=I(0,15)/I(2000000),cBG=cl1+Delta,c=-cBG;
 I Rbar(dn(std::stold("0.265632191288465974773")),up(std::stold("0.265632191288465974855")));
 I Dcert(dn(std::stold("-3.02072652301946231105")),up(std::stold("-0.148221407606938799506")));
 long long parents=0,parentpass=0,refparents=0,children=0,childpass=0;
 long double gth=-1e300L,gad=-1e300L,gadlo=1e300L;
 for(int pk=88;pk<=126;++pk){ I phi=I(2)*PI_RIG()*full_cell(pk,128);
  for(int ts=0;ts<8;++ts){ I theta=I(2)*PI_RIG()*I((long double)(8*(-16)+ts),(long double)(8*(-16)+ts+1))/I((long double)(8*4096));
   for(int ai=0;ai<48;++ai){
    I A=I(1)/I(100)+(I(49)/I(1600)-I(1)/I(100))*I((long double)ai,(long double)(ai+1))/I(48);
    parents++; auto e=eval_flow_box(theta,A,phi,M,c,cBG,Rbar,Dcert);
    if(e.ok){ gth=std::max(gth,e.th_hi); gad=std::max(gad,e.ad_hi); gadlo=std::min(gadlo,e.ad_lo); parentpass++; continue;}
    refparents++;
    for(int jt=0;jt<8;++jt){
     I th2=I(lo(theta))+(I(hi(theta))-I(lo(theta)))*I((long double)jt,(long double)(jt+1))/I(8);
     for(int ja=0;ja<8;++ja){
      I A2=I(lo(A))+(I(hi(A))-I(lo(A)))*I((long double)ja,(long double)(ja+1))/I(8);
      children++; auto f=eval_flow_box(th2,A2,phi,M,c,cBG,Rbar,Dcert);
      if(f.ok){ gth=std::max(gth,f.th_hi); gad=std::max(gad,f.ad_hi); gadlo=std::min(gadlo,f.ad_lo); childpass++; }
     }
    }
   }
  }
 }
 long long Nboxes=0,Npass=0; long double Nadhi=-1e300L,Nthhi=-1e300L;
 for(int pk=113;pk<=116;++pk){ I phi=I(2)*PI_RIG()*full_cell(pk,128);
  for(int ts=0;ts<8;++ts){ I theta=I(2)*PI_RIG()*I((long double)(8*(-16)+ts),(long double)(8*(-16)+ts+1))/I((long double)(8*4096));
   for(int ai=0;ai<32;++ai){ I A=I(147)/I(10000)+(I(18)/I(1000)-I(147)/I(10000))*I((long double)ai,(long double)(ai+1))/I(32);
    Nboxes++; auto e=eval_flow_box(theta,A,phi,M,c,cBG,Rbar,Dcert); Nadhi=std::max(Nadhi,e.ad_hi); Nthhi=std::max(Nthhi,e.th_hi); if(e.ok)Npass++;
   }
  }
 }
 std::cout<<std::setprecision(25)
  <<"FULL parents "<<parents<<" parentpass "<<parentpass<<" refined_parents "<<refparents<<" children "<<children<<" childpass "<<childpass
  <<" theta_hi "<<gth<<" Adot_hi "<<gad<<" Adot_lo "<<gadlo<<"\n"
  <<"N boxes "<<Nboxes<<" pass "<<Npass<<" theta_hi "<<Nthhi<<" Adot_hi "<<Nadhi<<"\n";
 bool ok=(parentpass+refparents==parents)&&(childpass==children)&&(Npass==Nboxes)&&(Nadhi < -0.1L);
 std::cout<<"R16_C4_FLOW="<<(ok?"PASS":"FAIL")<<"\n"; return ok?0:3;
}
