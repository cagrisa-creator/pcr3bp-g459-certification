import json, glob, os, hashlib
from fractions import Fraction
from decimal import Decimal, getcontext
getcontext().prec=60

def loadj(p):
    with open(p) as f:return json.load(f)
def sha(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def audit_ledger(p):
    paths=[]; statuses=[]; depths=[]
    with open(p) as f:
        for line in f:
            d=json.loads(line); paths.append(d['path']); statuses.append(d['status']); depths.append(int(d['depth']))
    assert len(paths)==len(set(paths))
    tokens=lambda x:[x[i:i+2] for i in range(0,len(x),2)]
    T=[tokens(x) for x in paths]
    assert all(len(t)==d for t,d in zip(T,depths))
    S={tuple(t) for t in T}
    for t in sorted(T,key=len):
        for k in range(len(t)):
            assert tuple(t[:k]) not in S
    kraft=sum((Fraction(1,2**d) for d in depths),Fraction(0))
    assert kraft==1,(p,kraft)
    assert all(s=='PASS' for s in statuses),(p,set(statuses))
    return {'leaves':len(paths),'kraft_num':kraft.numerator,'kraft_den':kraft.denominator,'sha256':sha(p)}

expected=[]
for p in list(range(88,113))+list(range(117,127)):
    expected.append((f'easy_{p}', 'beta0', Decimal('0.01'),Decimal('0.030625')))
for p in [113,114,115,116]:
    expected.append((f'low_{p}','beta0',Decimal('0.01'),Decimal('0.01470')))
    expected.append((f'high_{p}','beta0',Decimal('0.01800'),Decimal('0.030625')))
for p in [113,115,116]:
    expected.append((f'N_{p}','beta_m015',Decimal('0.01470'),Decimal('0.01800')))
for tag,a,b in [('N_114_a','0.01470','0.015525'),('N_114_b','0.015525','0.01635'),('N_114_c','0.01635','0.017175'),('N_114_d','0.017175','0.01800')]:
    expected.append((tag,'beta_m015',Decimal(a),Decimal(b)))
# Exact interval-union check for each phi sector
for p in range(88,127):
    ints=[]
    if p in list(range(88,113))+list(range(117,127)):
        ints=[(Decimal('0.01'),Decimal('0.030625'))]
    elif p!=114:
        ints=[(Decimal('0.01'),Decimal('0.01470')),(Decimal('0.01470'),Decimal('0.01800')),(Decimal('0.01800'),Decimal('0.030625'))]
    else:
        ints=[(Decimal('0.01'),Decimal('0.01470')),(Decimal('0.01470'),Decimal('0.015525')),(Decimal('0.015525'),Decimal('0.01635')),(Decimal('0.01635'),Decimal('0.017175')),(Decimal('0.017175'),Decimal('0.01800')),(Decimal('0.01800'),Decimal('0.030625'))]
    assert ints[0][0]==Decimal('0.01') and ints[-1][1]==Decimal('0.030625')
    assert all(ints[i][1]==ints[i+1][0] for i in range(len(ints)-1))

jobs=[]; total_processed=total_pass=0
for tag,kind,a,b in expected:
    jp=f'c3_jobs/{tag}.json'; lp=jp+'.ledger.jsonl'
    d=loadj(jp); assert d['status']=='CERTIFIED_PASS' and int(d['failures'])==0,(tag,d)
    la=audit_ledger(lp)
    jobs.append({'tag':tag,'kind':kind,'A_lo':str(a),'A_hi':str(b),'processed':int(d['processed_boxes']),'pass_boxes':int(d['pass_boxes']),'min_detK_lower':d['min_detK_lower'],'ledger':la})
    total_processed+=int(d['processed_boxes']); total_pass+=int(d['pass_boxes'])

# C4 beta0 B roots
bjobs=[]
for s in ['04','06']:
    jp=f'c4_s{s}_gcc.json'; d=loadj(jp); assert d['status']=='CERTIFIED_PASS' and int(d['failures'])==0
    la=audit_ledger(jp+'.ledger.jsonl')
    bjobs.append({'root':s,'processed':int(d['processed_boxes']),'pass_boxes':int(d['pass_boxes']),'min_detK_lower':d['min_detK_lower'],'ledger':la})
# s04 fresh gcc/clang byte equality
assert open('c4_s04_gcc.json.ledger.jsonl','rb').read()==open('c4_s04_clang.json.ledger.jsonl','rb').read()

# Flow replay parse
flow=open('c4_flow_gcc.out').read().strip().splitlines(); assert flow[-1]=='R16_C4_FLOW=PASS'
assert open('c4_flow_gcc.out','rb').read()==open('c4_flow_clang.out','rb').read()
# margin based on certified N A_dot upper from output
import re
m=re.search(r'N boxes (\d+) pass (\d+) theta_hi ([^ ]+) Adot_hi ([^\n]+)', '\n'.join(flow)); assert m
nboxes,npass=int(m.group(1)),int(m.group(2)); adotN=Decimal(m.group(4)); assert nboxes==npass==1024 and adotN<Decimal('-0.1')
modified=Decimal('-0.015')-Decimal('0.15')*adotN
assert modified>0
report={
 'status':'R16_C3_C4_TRUST_BASE_AUDIT_PASS',
 'c3':{'phi_sectors':39,'A_domain':['0.01','0.030625'],'Delta_domain':['0','7.5e-6'],'outside_N_beta_floor':'0','N_beta_floor':'-3/200','jobs':len(jobs),'processed_boxes':total_processed,'pass_boxes':total_pass,'failures':0,'exact_A_union_each_phi':True,'all_terminal_ledgers_kraft_exact':True,'job_details':jobs},
 'c4':{'B_beta0_roots':bjobs,'flow_output_sha256':sha('c4_flow_gcc.out'),'flow_source_sha256':sha('c4_flow_replay.cpp'),'gcc_clang_flow_byte_identical':True,'N_Adot_upper':str(adotN),'modified_rotation_lower':str(modified),'modified_rotation_positive':True},
 'source_derivations':{'base_beta_sha256':sha('base_beta.cpp'),'c3_target_source_sha256':sha('c3_beta_m015.cpp'),'c4_beta0_source_sha256':sha('c4_beta0.cpp'),'c3_change':'one-line target change BETA_TARGET=1/20 -> -3/200','c4_change':'one-line target change BETA_TARGET=1/20 -> 0'},
}
open('R16_C3_C4_TRUST_BASE_AUDIT_20260926.json','w').write(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='c3'},indent=2))
print('C3 jobs',len(jobs),'processed',total_processed,'pass_boxes',total_pass)
print('AUDIT_SHA',sha('R16_C3_C4_TRUST_BASE_AUDIT_20260926.json'))
