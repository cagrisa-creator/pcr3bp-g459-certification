#define main frozen_generator_main
#include "base_beta.cpp"
#undef main
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <string>
int main(int argc,char**argv){
 if(argc!=9){std::cerr<<"usage: tsv A_lo A_hi d_lo d_hi d_den beta_num beta_den\n";return 2;}
 std::string inp=argv[1]; long double amin=std::stold(argv[2]),acut=std::stold(argv[3]);
 long long dlo=std::stoll(argv[4]),dhi=std::stoll(argv[5]),dden=std::stoll(argv[6]);
 long long bn=std::stoll(argv[7]),bd=std::stoll(argv[8]);
 BETA_TARGET=I((long double)bn)/I((long double)bd);
 I gamma=I(541)/I(1000),ms=mu_small(gamma),M=I(1)-ms,x=I(1)-ms-gamma,cl1=x*x/I(2)+(I(1)-ms)/(I(1)-gamma)+ms/gamma;
 I Delta=I((long double)dlo,(long double)dhi)/I((long double)dden),Amin(dn(amin),up(amin)),Acut(dn(acut),up(acut));
 const long double Rlo=std::stold("0.265632191288465974773"),Rhi=std::stold("0.265632191288465974855"),Dlo=std::stold("-3.02072652301946231105"),Dhi=std::stold("-0.148221407606938799506");
 std::ifstream f(inp); std::string line; std::getline(f,line); long long n=0,fail=0; long double mins=INFINITY,mk00=INFINITY,mk11=INFINITY,mdet=INFINITY;
 while(std::getline(f,line)){ if(line.empty())continue; std::istringstream q(line); Box b; q>>b.ti>>b.tn>>b.i1>>b.n1>>b.i2>>b.n2; b.seed=0;b.Rlo=Rlo;b.Rhi=Rhi;b.Dlo=Dlo;b.Dhi=Dhi;b.depth=0;b.path=""; if(!q){std::cerr<<"parse\n";return 3;} Eval e=eval_polar4(b,M,cl1,Delta,Amin,Acut); n++; if(e.status!="PASS"){fail++; if(fail<20)std::cerr<<"FAIL row "<<n<<" reason "<<e.reason<<" speed "<<e.speed<<"\n";} else {mins=std::min(mins,e.speed);mk00=std::min(mk00,e.hd00);mk11=std::min(mk11,e.hd11);mdet=std::min(mdet,e.hdet);} }
 std::cout<<std::setprecision(25)<<"R16_BETA_TERMINAL_CHECK="<<(fail?"FAIL":"PASS")<<" boxes="<<n<<" failures="<<fail<<" beta_target="<<bn<<"/"<<bd<<" min_speed="<<mins<<" min_K00="<<mk00<<" min_K11="<<mk11<<" min_detK="<<mdet<<"\n"; return fail?4:0;
}
