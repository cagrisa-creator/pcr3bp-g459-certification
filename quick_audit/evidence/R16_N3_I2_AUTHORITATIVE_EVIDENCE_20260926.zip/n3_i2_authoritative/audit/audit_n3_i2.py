import csv,json,hashlib,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'results'

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def rows(p):
 with open(p,newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
keys=rows(ROOT/'input/canonical1222_keys_from_R5FR.tsv')
geom=rows(R/'n3_1222_geometry.tsv')
unw=rows(R/'n3_full_unweighted.tsv')
wgt=rows(R/'n3_weighted10.tsv')
K=lambda r:tuple(int(r[k]) for k in ('idx','i','j','child','a','b'))
assert len(keys)==len(geom)==len(unw)==1222
assert [K(r) for r in keys]==[K(r) for r in geom]
assert [int(r['idx']) for r in geom]==[int(r['idx']) for r in unw]
uclose={int(r['idx']) for r in unw if r['status']=='YORKE_CLOSE'}
unres={int(r['idx']) for r in unw if r['status']=='UNRESOLVED'}
exp={568,573,576,578,580,581,582,583,584,585}
assert len(uclose)==1212 and unres==exp
assert not [r for r in unw if r['status'] not in ('YORKE_CLOSE','UNRESOLVED')]
assert {int(r['idx']) for r in wgt}==exp
wclose={int(r['idx']) for r in wgt if r['status']=='YORKE_CLOSE'}
wres={int(r['idx']) for r in wgt if r['status']=='UNRESOLVED'}
assert wclose==exp-{582} and wres=={582}
t=(R/'n3_idx582_displacement.out').read_text()
assert 'R16_N3_IDX582_DISPLACEMENT=PASS' in t and 'segments_checked=64' in t
lo=float(re.search(r'D3_union_lo=([^\n]+)',t).group(1)); hi=float(re.search(r'D3_union_hi=([^\n]+)',t).group(1))
assert hi<0
final=uclose|wclose|{582};assert final==set(range(1222))
out={'status':'PASS_N3_I2_AUTHORITATIVE','canonical_key_order_match':True,'geometry_count':1222,'unweighted_close':1212,'unweighted_unresolved':sorted(unres),'weighted_close':9,'weighted_unresolved':[582],'idx582_displacement':{'time_interval':['5/2','3'],'coordinate':3,'D3_union_lo':lo,'D3_union_hi':hi,'pass':True},'final_closed_count':1222,'missing':[],'extra':[],'result_hashes':{p.name:sha(p) for p in [R/'n3_1222_geometry.tsv',R/'n3_full_unweighted.tsv',R/'n3_weighted10.tsv',R/'n3_idx582_displacement.out']}}
print(json.dumps(out,indent=2,sort_keys=True))
