# R16 N3 I2 authoritative evidence — 2026-09-26

This package independently closes N3, the canonical current-neck nonconstant period floor through T=3.

## Canonical cover

The historical R5-FR ledger supplies only the exact ordered key universe `(idx,i,j,child,a,b)`. The R16 reconstruction regenerates the broader energy-intersecting grid from the frozen R5-FP `refine78.tsv`, with the momentum-radius square rounded **upward by one long-double ULP** after `sqrtl`. `filter_canonical1222.py` then selects exactly the 1,222 historical keys and restores the historical `idx` values. The final audit requires exact ordered key equality.

## Independent acceptance layers

1. Unweighted induced Yorke at T=3: 1,212/1,222 PASS, exactly 10 residual indices `568,573,576,578,580,581,582,583,584,585`, zero failures.
2. Fixed diagonal weighted induced norm evaluated on the independently validated trajectory hulls: 9/10 PASS; only idx 582 remains.
3. Stepwise displacement on idx 582: canonical coordinate 3 remains strictly separated from its initial value for every time in `[5/2,3]`; final union upper endpoint is negative.

Therefore the finite cover accounting is exactly 1,222/1,222 with no missing or extra key.

`run_replay.sh` performs a cold replay. `audit/audit_n3_i2.py` is fail-closed and can audit either the frozen `results/` directory or a fresh `work/` replay.

Historical GCC/Clang identity is not the independence claim. The R16 claim is an independently written checker/reconstruction route whose outputs reproduce the historical finite residual structure and close it.
