#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
CXX=${CXX:-g++}
FLAGS='-std=c++17 -O2 -frounding-math -fno-fast-math'
mkdir -p "$ROOT/work"
$CXX $FLAGS "$ROOT/src/reconstruct_broad_energy_grid.cpp" -o "$ROOT/work/reconstruct"
$CXX $FLAGS "$ROOT/src/n3_independent_yorke.cpp" -o "$ROOT/work/yorke"
$CXX $FLAGS "$ROOT/src/n3_independent_weighted.cpp" -o "$ROOT/work/weighted"
$CXX $FLAGS "$ROOT/src/n3_idx582_displacement.cpp" -o "$ROOT/work/disp"
"$ROOT/work/reconstruct" "$ROOT/input/refine78.tsv" > "$ROOT/work/broad_geometry.tsv"
python3 "$ROOT/src/filter_canonical1222.py" "$ROOT/work/broad_geometry.tsv" "$ROOT/input/canonical1222_keys_from_R5FR.tsv" "$ROOT/work/n3_1222_geometry.tsv"
for s in $(seq 0 7); do
 ids=$(python3 - "$s" <<'PY'
import sys
s=int(sys.argv[1]); print(' '.join(str(i) for i in range(s,1222,8)))
PY
)
 "$ROOT/work/yorke" "$ROOT/work/n3_1222_geometry.tsv" $ids > "$ROOT/work/shard_$s.tsv" &
done
wait
python3 - "$ROOT/work" <<'PY'
import csv,glob,sys,os
W=sys.argv[1];rows=[]
for fn in glob.glob(os.path.join(W,'shard_*.tsv')):
 with open(fn) as f:rows+=list(csv.DictReader(f,delimiter='\t'))
rows.sort(key=lambda r:int(r['idx']))
with open(os.path.join(W,'n3_full_unweighted.tsv'),'w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['idx','status','L','steps','failstep'],delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
PY
"$ROOT/work/weighted" "$ROOT/work/n3_1222_geometry.tsv" 568 573 576 578 580 581 582 583 584 585 > "$ROOT/work/n3_weighted10.tsv"
"$ROOT/work/disp" "$ROOT/work/n3_1222_geometry.tsv" > "$ROOT/work/n3_idx582_displacement.out"
python3 "$ROOT/audit/audit_n3_i2.py" "$ROOT/work"
