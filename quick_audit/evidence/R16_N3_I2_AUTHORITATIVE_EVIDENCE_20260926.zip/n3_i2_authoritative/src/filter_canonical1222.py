import csv,sys
broad,keys,out=sys.argv[1:4]
with open(broad,newline='') as f:b=list(csv.DictReader(f,delimiter='\t'))
with open(keys,newline='') as f:k=list(csv.DictReader(f,delimiter='\t'))
K=lambda r:tuple(int(r[x]) for x in ('i','j','child','a','b'))
bm={K(r):r for r in b}
assert len(bm)==len(b)
rows=[]
for h in k:
    key=K(h)
    assert key in bm, ('missing',h['idx'],key)
    r=dict(bm[key]);r['idx']=h['idx'];rows.append(r)
assert len(rows)==1222
fields=['idx','i','j','child','a','b','x1lo','x1hi','x2lo','x2hi','w1lo','w1hi','w2lo','w2hi']
with open(out,'w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
