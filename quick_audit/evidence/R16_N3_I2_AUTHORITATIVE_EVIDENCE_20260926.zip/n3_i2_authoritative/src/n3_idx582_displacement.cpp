#pragma STDC FENV_ACCESS ON
#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/transc.hpp>
#include <boost/numeric/interval/rounded_transc.hpp>
#include <boost/numeric/interval/checking.hpp>
#include <array>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
namespace bn=boost::numeric;
using Rounding=bn::interval_lib::save_state<bn::interval_lib::rounded_transc_std<long double>>;
using Checking=bn::interval_lib::checking_base<long double>;
using Policies=bn::interval_lib::policies<Rounding,Checking>;
using I=bn::interval<long double,Policies>;
static long double LO(const I&x){return x.lower();} static long double HI(const I&x){return x.upper();}
static I HULL(const I&a,const I&b){return I(min(LO(a),LO(b)),max(HI(a),HI(b)));}
static I INFL(const I&x,long double e=0.15L){ long double m=(LO(x)+HI(x))/2, r=(HI(x)-LO(x))/2; long double rr=nextafterl((r+1e-30L)*(1+e)+1e-28L,numeric_limits<long double>::infinity()); return I(nextafterl(m-rr,-numeric_limits<long double>::infinity()),nextafterl(m+rr,numeric_limits<long double>::infinity())); }
static bool interior(const I&a,const I&b){return LO(b)<LO(a)&&HI(a)<HI(b);} 
static I udec(const char*s){I x(0); bool neg=false; if(*s=='-'){neg=true;++s;} for(;*s;s++) if(*s>='0'&&*s<='9') x=x*I(10)+I(*s-'0'); return neg?-x:x;}
static I rat(const char*n,const char*d){return udec(n)/udec(d);} 
static const I& MU(){static I v=rat("264377992475701","441699674239000");return v;}
static const I& HHF(){static I v=rat("-3884088328779821204137809121","1950986022228387202291210000");return v;}
static const I& HINT(){static I dm=I(3)/I(50000); static I D(0,HI(dm)); static I v=HHF()+I(1)/I(10000)-D; return v;}
template<class T> struct AD{T v; array<T,4>d; AD(){} AD(const T&x):v(x){for(auto &z:d)z=T(0);} };
template<class T> AD<T> var(const T&x,int k){AD<T>a(x);a.d[k]=T(1);return a;}
template<class T> AD<T> operator+(const AD<T>&a,const AD<T>&b){AD<T>r;r.v=a.v+b.v;for(int i=0;i<4;i++)r.d[i]=a.d[i]+b.d[i];return r;}
template<class T> AD<T> operator-(const AD<T>&a,const AD<T>&b){AD<T>r;r.v=a.v-b.v;for(int i=0;i<4;i++)r.d[i]=a.d[i]-b.d[i];return r;}
template<class T> AD<T> operator-(const AD<T>&a){AD<T>r;r.v=-a.v;for(int i=0;i<4;i++)r.d[i]=-a.d[i];return r;}
template<class T> AD<T> operator*(const AD<T>&a,const AD<T>&b){AD<T>r;r.v=a.v*b.v;for(int i=0;i<4;i++)r.d[i]=a.d[i]*b.v+a.v*b.d[i];return r;}
template<class T> AD<T> operator/(const AD<T>&a,const AD<T>&b){AD<T>r;r.v=a.v/b.v;for(int i=0;i<4;i++)r.d[i]=(a.d[i]*b.v-a.v*b.d[i])/(b.v*b.v);return r;}
template<class T> AD<T> operator+(const AD<T>&a,long double b){return a+AD<T>(T(b));}
template<class T> AD<T> operator-(const AD<T>&a,long double b){return a-AD<T>(T(b));}
template<class T> AD<T> operator*(const AD<T>&a,long double b){return a*AD<T>(T(b));}
template<class T> AD<T> operator/(const AD<T>&a,long double b){return a/AD<T>(T(b));}
template<class T> AD<T> operator+(long double a,const AD<T>&b){return AD<T>(T(a))+b;}
template<class T> AD<T> operator-(long double a,const AD<T>&b){return AD<T>(T(a))-b;}
template<class T> AD<T> operator*(long double a,const AD<T>&b){return AD<T>(T(a))*b;}
template<class T> T SINF(const T&x){using std::sin; return sin(x);} template<class T> T COSF(const T&x){using std::cos; return cos(x);} template<class T> T SINHF(const T&x){using std::sinh; return sinh(x);} template<class T> T COSHF(const T&x){using std::cosh; return cosh(x);} 
template<> AD<I> SINF(const AD<I>&a){AD<I>r;r.v=sin(a.v);I c=cos(a.v);for(int i=0;i<4;i++)r.d[i]=c*a.d[i];return r;}
template<> AD<I> COSF(const AD<I>&a){AD<I>r;r.v=cos(a.v);I s=-sin(a.v);for(int i=0;i<4;i++)r.d[i]=s*a.d[i];return r;}
template<> AD<I> SINHF(const AD<I>&a){AD<I>r;r.v=sinh(a.v);I c=cosh(a.v);for(int i=0;i<4;i++)r.d[i]=c*a.d[i];return r;}
template<> AD<I> COSHF(const AD<I>&a){AD<I>r;r.v=cosh(a.v);I s=sinh(a.v);for(int i=0;i<4;i++)r.d[i]=s*a.d[i];return r;}
template<class T> T CI(const I&x){return T(x);} template<> I CI<I>(const I&x){return x;}
template<class T> struct VE{T V,Vx1,Vx2,F1,F2;};
template<class T> VE<T> veval(const T&x1,const T&x2){ T s=COSHF(x1),sh=SINHF(x1),t=COSF(x2),sx=SINF(x2),s2=s*s,t2=t*t; T h=CI<T>(HINT()),mu=CI<T>(MU()); T Vb=-(h*s2)/4.0L-s/2.0L-(s2-1.0L)*s2/32.0L+(h*t2)/4.0L-(1.0L-t2)*t2/32.0L; T B=0.5L-mu+s*t,lm=1.0L-2.0L*mu; T V=Vb+lm*(t/2.0L-B*(s2-t2)/16.0L); T Vs=-(h*s)/2.0L-0.5L-(2.0L*s*s*s-s)/16.0L+lm*(-(t*(s2-t2)+2.0L*s*B)/16.0L); T Vt=(h*t)/2.0L+(-t+2.0L*t*t*t)/16.0L+lm*(0.5L-(s*(s2-t2)-2.0L*t*B)/16.0L); return {V,Vs*sh,-Vt*sx,SINF(2.0L*x2)/8.0L,SINHF(2.0L*x1)/8.0L}; }
template<class T> using V4=array<T,4>;
template<class T> V4<T> vf(const V4<T>&q){auto e=veval(q[0],q[1]);T w1=q[2]+e.F1,w2=q[3]+e.F2;return {w1,w2,-COSHF(2.0L*q[0])*w2/4.0L-e.Vx1,-COSF(2.0L*q[1])*w1/4.0L-e.Vx2};}
static V4<I> F(const V4<I>&x){return vf(x);} static void JAC(const V4<I>&x,array<array<I,4>,4>&J){V4<AD<I>>q;for(int i=0;i<4;i++)q[i]=var(x[i],i);auto y=vf(q);for(int i=0;i<4;i++)for(int j=0;j<4;j++)J[i][j]=y[i].d[j];}
static bool apriori(const V4<I>&X,long double h,V4<I>&Y){auto f0=F(X);for(int i=0;i<4;i++){I z=HULL(X[i],X[i]+I(0,h)*f0[i]);Y[i]=INFL(z,.20L);}for(int it=0;it<30;it++){auto fy=F(Y);V4<I>Z;bool ok=true;for(int i=0;i<4;i++){Z[i]=X[i]+I(0,h)*fy[i];if(!interior(Z[i],Y[i]))ok=false;}if(ok)return true;for(int i=0;i<4;i++)Y[i]=INFL(HULL(Y[i],Z[i]),.20L);}return false;}
static bool step(V4<I>&X,long double h,V4<I>&tube){if(!apriori(X,h,tube))return false;auto f0=F(X),fy=F(tube);array<array<I,4>,4>J;JAC(tube,J);V4<I>NX;for(int i=0;i<4;i++){I a(0);for(int j=0;j<4;j++)a+=J[i][j]*fy[j];NX[i]=X[i]+I(h)*f0[i]+I(h*h/2)*a;}X=NX;return true;}
struct Row{int idx,i,j,child,a,b; long double x1l,x1h,x2l,x2h,w1l,w1h,w2l,w2h;};
static vector<string> split(const string&s){vector<string>v;stringstream ss(s);string x;while(getline(ss,x,'\t'))v.push_back(x);return v;}
int main(int argc,char**argv){if(argc!=2){cerr<<"usage geometry.tsv\n";return 9;}ifstream in(argv[1]);string line;getline(in,line);Row r{};bool found=false;while(getline(in,line)){if(line.empty())continue;auto v=split(line);if(stoi(v[0])!=582)continue;r={stoi(v[0]),stoi(v[1]),stoi(v[2]),stoi(v[3]),stoi(v[4]),stoi(v[5]),stold(v[6]),stold(v[7]),stold(v[8]),stold(v[9]),stold(v[10]),stold(v[11]),stold(v[12]),stold(v[13])};found=true;break;}if(!found){cerr<<"idx582 missing\n";return 3;}
 auto down=[](long double x){return nextafterl(x,-numeric_limits<long double>::infinity());};auto up=[](long double x){return nextafterl(x,numeric_limits<long double>::infinity());}; I x1(down(r.x1l),up(r.x1h)),x2(down(r.x2l),up(r.x2h)),w1(down(r.w1l),up(r.w1h)),w2(down(r.w2l),up(r.w2h));auto e=veval(x1,x2);V4<I>X={x1,x2,w1-e.F1,w2-e.F2},X0=X; long double h=1.0L/128.0L; I Dall; bool have=false; int checked=0; for(int n=0;n<384;n++){V4<I>Y;if(!step(X,h,Y)){cerr<<"APRIORI_FAIL step="<<n<<"\n";return 4;} if(n>=320){I D=Y[3]-X0[3]; if(!have){Dall=D;have=true;}else Dall=HULL(Dall,D); checked++; if(HI(D)>=0){cerr<<setprecision(22)<<"ZERO_NOT_EXCLUDED step="<<n<<" D=["<<LO(D)<<","<<HI(D)<<"]\n";return 5;}}}
 cout<<setprecision(22);cout<<"R16_N3_IDX582_DISPLACEMENT=PASS\n";cout<<"idx=582\nsegments_checked="<<checked<<"\ntime_lo=2.5\ntime_hi=3\ncoordinate=3\nD3_union_lo="<<LO(Dall)<<"\nD3_union_hi="<<HI(Dall)<<"\n"; if(!(HI(Dall)<0))return 6; return 0;}
