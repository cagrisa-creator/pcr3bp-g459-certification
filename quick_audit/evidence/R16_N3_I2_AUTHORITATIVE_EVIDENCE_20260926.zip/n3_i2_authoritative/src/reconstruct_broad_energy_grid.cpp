#pragma STDC FENV_ACCESS ON
#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/transc.hpp>
#include <boost/numeric/interval/rounded_transc.hpp>
#include <boost/numeric/interval/checking.hpp>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
namespace bn=boost::numeric;
using Rounding=bn::interval_lib::save_state<bn::interval_lib::rounded_transc_std<long double>>;
using Checking=bn::interval_lib::checking_base<long double>;
using Policies=bn::interval_lib::policies<Rounding,Checking>;
using I=bn::interval<long double,Policies>;
static long double lo(const I&x){return x.lower();} static long double hi(const I&x){return x.upper();}
static I sq(const I&x){if(lo(x)<=0&&hi(x)>=0){long double u=std::max(lo(x)*lo(x),hi(x)*hi(x));return I(0,std::nextafter(u,std::numeric_limits<long double>::infinity()));}return x*x;}
static I uint_dec(const char*s){I x(0);for(;*s;++s)if(*s>='0'&&*s<='9')x=x*I(10)+I((int)(*s-'0'));return x;}
static I rat(const char*n,const char*d){bool neg=*n=='-';if(neg)++n;I q=uint_dec(n)/uint_dec(d);return neg?-q:q;}
static const I&MU(){static I x=rat("264377992475701","441699674239000");return x;}
static const I&HHF(){static I x=rat("-3884088328779821204137809121","1950986022228387202291210000");return x;}
static I HH(const I&D){return HHF()+I(1)/I(10000)-D;}
struct J{I v,s,t;}; static J cj(const I&x){return{x,I(0),I(0)};}
static J operator+(const J&a,const J&b){return{a.v+b.v,a.s+b.s,a.t+b.t};}
static J operator-(const J&a,const J&b){return{a.v-b.v,a.s-b.s,a.t-b.t};}
static J operator-(const J&a){return{-a.v,-a.s,-a.t};}
static J operator*(const J&a,const J&b){return{a.v*b.v,a.s*b.v+a.v*b.s,a.t*b.v+a.v*b.t};}
static J operator*(const I&a,const J&b){return cj(a)*b;}
static J operator/(const J&a,const I&b){return{a.v/b,a.s/b,a.t/b};}
static J Vjet(const I&s0,const I&t0,const I&D){const I&mu=MU();I h=HH(D);J s={s0,I(1),I(0)},t={t0,I(0),I(1)};J s2=s*s,t2=t*t,p2=s2-cj(I(1)),q2=cj(I(1))-t2;J Vb=-cj(h)*s2/I(4)-s/I(2)-p2*s2/I(32)+cj(h)*t2/I(4)-q2*t2/I(32);J Vhat=t/I(2)-(cj(I(0.5L)-mu)+s*t)*(s2-t2)/I(16);return Vb+(I(1)-I(2)*mu)*Vhat;}
int main(int argc,char**argv){
 const char* refine=argc>1?argv[1]:"/tmp/r5fp/refine78.tsv";
 int Ns=16,Nt=32,Nw=8; I D=I(0)+I(3)/I(50000);
 std::ifstream f(refine); std::string header; std::getline(f,header);
 int i,j,closed; char axis; long long idx=0;
 std::cout<<"idx\ti\tj\tchild\ta\tb\tx1lo\tx1hi\tx2lo\tx2hi\tw1lo\tw1hi\tw2lo\tw2hi\n";
 while(f>>i>>j>>axis>>closed){ if(closed) continue;
  I S0=I(1)+I(3)/I(256)*I((long double)i,(long double)(i+1))/I((long double)Ns);
  I T0=I(-1)/I(8)+I(1)/I(4)*I((long double)j,(long double)(j+1))/I((long double)Nt);
  for(int child=0;child<2;++child){
    I S=S0,T=T0;
    if(axis=='S'){ long double m=(lo(S0)+hi(S0))/2; S=child==0?I(lo(S0),m):I(m,hi(S0)); }
    else { long double m=(lo(T0)+hi(T0))/2; T=child==0?I(lo(T0),m):I(m,hi(T0)); }
    J z=Vjet(S,T,D); if(lo(z.v)>0) continue;
    long double rmax=nextafterl(sqrtl(std::max((long double)0,-2*lo(z.v))),std::numeric_limits<long double>::infinity()); if(!(rmax>0)) continue;
    I X1=acosh(S), X2=acos(T);
    for(int a=0;a<Nw;++a)for(int b=0;b<Nw;++b){
      I W1=I(-rmax)+I(2*rmax)*I((long double)a,(long double)(a+1))/I((long double)Nw);
      I W2=I(-rmax)+I(2*rmax)*I((long double)b,(long double)(b+1))/I((long double)Nw);
      I E=(sq(W1)+sq(W2))/I(2)+z.v;
      if(hi(E)<0||lo(E)>0) continue;
      std::cout<<idx++<<'\t'<<i<<'\t'<<j<<'\t'<<child<<'\t'<<a<<'\t'<<b<<std::setprecision(24)
        <<'\t'<<lo(X1)<<'\t'<<hi(X1)<<'\t'<<lo(X2)<<'\t'<<hi(X2)
        <<'\t'<<lo(W1)<<'\t'<<hi(W1)<<'\t'<<lo(W2)<<'\t'<<hi(W2)<<'\n';
    }
  }
 }
 std::cerr<<"count="<<idx<<"\n";
}
