import json,re,hashlib
from fractions import Fraction
from pathlib import Path
B=Path('/mnt/data/r16_assembly')
R=B/'replay'

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def txt(p): return Path(p).read_text()
def eq(a,b): return Path(a).read_bytes()==Path(b).read_bytes()
checks={}
# A0
checks['A0_gcc_clang_byte_identical']=eq(R/'a0_gpp.out',R/'a0_clangpp.out')
a0=txt(R/'a0_gpp.out')
ms=re.findall(r'good=(\d+)/(\d+).*dwell<=([0-9.eE+-]+)',a0)
checks['A0_32_bands_32of32']=len(ms)==32 and all(a==b=='32' for a,b,_ in ms)
m=re.search(r'ALL_NEG=(\d+) SUM_BAND_DWELL_UPPER=([0-9.eE+-]+)',a0)
a0sum=Fraction(m.group(2)); checks['A0_all_negative']=m.group(1)=='1'; checks['A0_dwell_lt_17_over_200']=a0sum<Fraction(17,200)
# A1 exact beta
bg=json.loads(txt(R/'a1_beta_gpp.json')); bc=json.loads(txt(R/'a1_beta_clangpp.json'))
checks['A1_beta_certified_gcc_clang']=bg['status']=='CERTIFIED_PASS' and bc['status']=='CERTIFIED_PASS' and bg['failures']==bc['failures']==0
checks['A1_beta_ledgers_byte_identical']=eq(R/'a1_beta_gpp.json.ledger.jsonl',R/'a1_beta_clangpp.json.ledger.jsonl')
# A1 phi
checks['A1_phi_gcc_clang_byte_identical']=eq(R/'a1_phi_gpp.out',R/'a1_phi_clangpp.out')
a1phi=txt(R/'a1_phi_gpp.out'); mm=re.search(r'SUMMARY total=(\d+) exceptions=(\d+) lower_good=(\d+) upper_good=(\d+)',a1phi)
checks['A1_phi_outward_256of256']=mm and mm.groups()==('256','0','256','256')
# A1 theta/speed bound replay + inherited GM shell
checks['A1_flow_gcc_clang_byte_identical']=eq(R/'a1_flow_gpp.out',R/'a1_flow_clangpp.out')
a1flow=txt(R/'a1_flow_gpp.out'); mm=re.search(r'global_th_lo ([^ ]+) global_th_hi ([^ ]+) global_A_lo ([^ ]+) global_A_hi ([^\n]+)',a1flow)
thlo,thhi,alo,ahi=map(Fraction,mm.groups())
checks['A1_theta_negative_and_abs_lt_61_over_1000']=thhi<0 and thlo>-Fraction(61,1000)
gmg=B/'gm/evidence/r5gm_A_shell_flow_gcc.out'; gmc=B/'gm/evidence/r5gm_A_shell_flow_clang.out'
checks['GM_shell_gcc_clang_byte_identical']=eq(gmg,gmc)
gmt=txt(gmg); mm2=re.search(r'SUMMARY phi_cells_good (\d+)/(\d+) .*global_th_hi ([^ ]+) global_A_hi ([^ ]+) global_A_lo ([^\n]+)',gmt)
good,total,gm_thhi,gm_ahi,gm_alo=mm2.groups(); gm_thhi,gm_ahi,gm_alo=map(Fraction,[gm_thhi,gm_ahi,gm_alo])
checks['GM_shell_39of39_theta_A_negative']=good==total=='39' and gm_thhi<0 and gm_ahi<0
checks['GM_shell_abs_A_dot_lt_6_over_25']=gm_alo>-Fraction(6,25)
# E0 B phi
checks['E0_B_phi_gcc_clang_byte_identical']=eq(R/'e0_phi_gpp.out',R/'e0_phi_clangpp.out')
e0=txt(R/'e0_phi_gpp.out'); mm3=re.search(r'SUMMARY total=(\d+) exceptions=(\d+) lower_good=(\d+) upper_good=(\d+)',e0)
checks['E0_B_phi_outward_1024of1024']=mm3 and mm3.groups()==('1024','0','1024','1024')
# exact assembly arithmetic
A_time=Fraction(11,1600)/Fraction(6,25)
checks['U2_A_entry_time_gt_1_over_40']=A_time>Fraction(1,40)
# pi > 333/106 is elementary Archimedean-style rational bound; sufficient for this audit.
theta_time=(Fraction(333,106)/Fraction(2048,1))/Fraction(61,1000)
checks['U2_theta_entry_time_gt_1_over_40_using_pi_gt_333_over_106']=theta_time>Fraction(1,40)
Jentry=(Fraction(1,20)-Fraction(1,100))*Fraction(1,40)
Bdef=Fraction(17,200)*Fraction(1,100)
pair=Jentry-Bdef
checks['A2_Jentry_eq_1_over_1000']=Jentry==Fraction(1,1000)
checks['A2_Bdef_lt_17_over_20000']=Bdef==Fraction(17,20000)
checks['A2_upperA_pair_margin_eq_3_over_20000']=pair==Fraction(3,20000) and pair>0
# upper theta family from independent U1 audit + frozen GAF deficit
u1=json.loads(txt('/mnt/data/r16_u1/R16_U1_I2_AUTHORITATIVE_AUDIT_20260926.json'))
gaf=json.loads(txt(B/'gaf/R5_GAF_FINAL_ASSEMBLY_AUDIT_20260925.json'))
checks['U1_closed']=u1['status']=='R16_U1_I2_PASS'
upper_theta_margin=Fraction(str(u1['global_min_Klo']))-Fraction(gaf['generic_B_deficit_lt'])
checks['upperTheta_pair_margin_positive']=upper_theta_margin>0
# S2 exact seed count / closure decision
D=json.loads(txt(B/'gaf/R5_GAF_FINAL_DEPENDENCY_AUDIT_20260925.json'))
pt=D['logic']['seed7_pointwise_cells']; integ=D['logic']['seed7_integrated_cells']
checks['S2_exact_16_cells_disjoint']=len(pt)==14 and len(integ)==2 and len(set(pt+integ))==16 and set(pt).isdisjoint(integ)
checks['S2_integrated_cells_are_s04_s06']=set(integ)=={'s04_d0','s06_d0'}
# Structural E1: two entry faces + one-way/outward boundary premises
checks['E1_two_entry_faces_exact']=D['logic']['B_forward_entry_faces']==['upper-theta','upper-A']
checks['E1_no_phi_entry_certified']=checks['E0_B_phi_outward_1024of1024']
checks['E1_no_double_counting_premises']=checks['E1_no_phi_entry_certified'] and checks['GM_shell_39of39_theta_A_negative'] and checks['A1_theta_negative_and_abs_lt_61_over_1000']
checks['GAF_final_assembly']=all(checks.values())
report={
 'status':'R16_FINAL_ENTRY_ASSEMBLY_PASS' if all(checks.values()) else 'FAIL',
 'checks':checks,
 'exact_arithmetic':{
  'A_entry_time_lower':str(A_time),'theta_entry_time_lower_using_333_over_106':str(theta_time),
  'J001_entry':str(Jentry),'B_deficit_safe':str(Bdef),'upperA_pair_margin':str(pair),
  'upperTheta_pair_margin_decimal':float(upper_theta_margin)
 },
 'proof_nodes':{'U1':'I2 PASS','A0':'PASS','A1':'PASS','U2':'PASS','A2':'PASS','E0':'PASS','E1':'PASS_BY_STRUCTURAL_ASSEMBLY','S2':'PASS_16_OF_16','GAF':'PASS'},
 'hashes':{
  'A0_gcc':sha(R/'a0_gpp.out'),'A1_beta_ledger':sha(R/'a1_beta_gpp.json.ledger.jsonl'),'A1_phi':sha(R/'a1_phi_gpp.out'),
  'A1_flow':sha(R/'a1_flow_gpp.out'),'GM_shell':sha(gmg),'E0_B_phi':sha(R/'e0_phi_gpp.out'),
  'U1_audit':sha('/mnt/data/r16_u1/R16_U1_I2_AUTHORITATIVE_AUDIT_20260926.json')
 },
 'note':'This audit closes the finite final-entry/final-assembly DAG. It does not replace the separate external theorem/convention/trivialization/orientation publication audit.'
}
out=B/'R16_FINAL_ENTRY_ASSEMBLY_AUDIT_20260926.json'; Path(out).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2,sort_keys=True))
