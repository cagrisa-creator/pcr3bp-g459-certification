import csv,json,hashlib,collections,math
from pathlib import Path
B=Path('/mnt/data/r16_u1')
coarse=B/'pkg/seeds/R5_GU_all_base_coarse.tsv'
t1=B/'tier1_merged.tsv'; t2=B/'tier2_merged.tsv'
bin_=B/'beta_schur_41020_input.tsv'; bout=B/'beta_full_41020_gcc.tsv'; eout=B/'event_reconstructed_gcc.tsv'

def rows(p):
    with open(p,newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def sha(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
C,T1,T2,BI,BO,EO=map(rows,[coarse,t1,t2,bin_,bout,eout])
root=lambda r:(int(r['ba'] if 'ba' in r else r['root_ba']),int(r['bp'] if 'bp' in r else r['root_bp']),int(r['bd'] if 'bd' in r else r['root_bd']))
child=lambda r:(int(r['root_ba']),int(r['root_bp']),int(r['root_bd']),int(r['ia']),int(r['an']),int(r['pi']),int(r['pn']),int(r['di']),int(r['dn']))
t2parent=lambda r:(int(r['root_ba']),int(r['root_bp']),int(r['root_bd']),int(r['parent_ai']),int(r['parent_an']),int(r['parent_pi']),int(r['parent_pn']),int(r['parent_di']),int(r['parent_dn']))
outkey=lambda r:(int(r['root_ba']),int(r['root_bp']),int(r['root_bd']),int(r['ia']),int(r['an']),int(r['pi']),int(r['pn']),int(r['di']),int(r['dn']))
checks={}
expected={(ba,bp,bd) for ba in range(32) for bp in range(32) for bd in range(3)}
Ckeys=[root(r) for r in C]
checks['coarse_exact_3072_unique']=len(C)==3072 and len(set(Ckeys))==3072 and set(Ckeys)==expected
Cpass=[r for r in C if r['status']!='FAIL']; Cfail=[r for r in C if r['status']=='FAIL']
checks['coarse_split_58_3014']=len(Cpass)==58 and len(Cfail)==3014
cnt1=collections.Counter(root(r) for r in T1)
checks['tier1_exact_parent_set_and_16_children']=len(T1)==48224 and set(cnt1)==set(root(r) for r in Cfail) and set(cnt1.values())=={16}
T1fail=[r for r in T1 if r['status']=='FAIL']; T1pass=[r for r in T1 if r['status']!='FAIL']
checks['tier1_status_counts']=len(T1pass)==28913 and len(T1fail)==19311
p2=collections.Counter(t2parent(r) for r in T2)
checks['tier2_parent_equals_tier1_fail_and_4_children']=len(T2)==77244 and set(p2)==set(child(r) for r in T1fail) and set(p2.values())=={4}
T2fail=[r for r in T2 if r['status']=='FAIL']; T2pass=[r for r in T2 if r['status']!='FAIL']
checks['tier2_status_counts']=len(T2pass)==27600 and len(T2fail)==49644
beta_t2={child(r) for r in T2fail if r['reason']=='BETA_SCHUR'}
event_t2={child(r) for r in T2fail if r['reason']=='EVENT_MIXED_END'}
checks['tier2_residual_partition']=len(beta_t2)==41020 and len(event_t2)==8624 and beta_t2.isdisjoint(event_t2) and beta_t2|event_t2==set(child(r) for r in T2fail)
BIkeys={child(r) for r in BI}; BOkeys=[outkey(r) for r in BO]; EOkeys=[outkey(r) for r in EO]
checks['beta_input_exact_keyset']=len(BI)==41020 and len(BIkeys)==41020 and BIkeys==beta_t2
checks['beta_output_exact_keyset']=len(BO)==41020 and len(set(BOkeys))==41020 and set(BOkeys)==beta_t2
checks['beta_all_pass']=all(r['gaa_status'] in ('PASS_MIX','PASS_TOP') for r in BO)
checks['event_output_exact_keyset']=len(EO)==8624 and len(set(EOkeys))==8624 and set(EOkeys)==event_t2
checks['event_all_pass']=all(r['gaa_status'] in ('PASS_MIX','PASS_TOP') for r in EO)
mins={
 'coarse_direct':min(float(r['Klo']) for r in Cpass),
 'tier1_direct':min(float(r['Klo']) for r in T1pass),
 'tier2_direct':min(float(r['Klo']) for r in T2pass),
 'beta_final':min(float(r['Klo']) for r in BO),
 'event_reconstructed':min(float(r['Klo']) for r in EO),
}
checks['global_margin_gt_target']=min(mins.values())>0.004922
checks['all_3072_roots_promote']=all(checks.values())
report={
 'status':'R16_U1_I2_PASS' if all(checks.values()) else 'FAIL',
 'checks':checks,
 'counts':{'coarse':len(C),'coarse_pass':len(Cpass),'coarse_refined':len(Cfail),'tier1':len(T1),'tier1_pass':len(T1pass),'tier1_fail':len(T1fail),'tier2':len(T2),'tier2_pass':len(T2pass),'tier2_fail':len(T2fail),'beta':len(BO),'event':len(EO)},
 'minimum_Klo_by_layer':mins,
 'global_min_Klo':min(mins.values()),'target':0.004922,
 'hashes':{p.name:sha(p) for p in [coarse,t1,t2,bin_,bout,eout]},
 'event_note':'EVENT final raw historical ledger was not preserved in active Drive; exact Tier2 EVENT key set was independently reconstructed with the frozen historical source hash and all 8624 obligations replayed PASS. Reconstructed serialization is new and is not claimed byte-identical to the missing historical ledger.'
}
out=B/'R16_U1_I2_AUTHORITATIVE_AUDIT_20260926.json'; out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2,sort_keys=True))
