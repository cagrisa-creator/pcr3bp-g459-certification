from fractions import Fraction as F
g=F(459,1000)
mu_small=g**3*(g**2-3*g+3)/(1-2*g+g**2+2*g**3-g**4)
mu_article=1-mu_small
x=mu_article-g
cL1=x*x/F(2)+(1-mu_small)/(1-g)+mu_small/g
cstar=cL1+F(1,10000)
expected={
 'mu_article':F(264377992475701,441699674239000),
 'mu_complement':F(177321681763299,441699674239000),
 'c_L1':F(388389323017759836541758,195098602222838720229121),
 'c_star':F(3884088328779821204137809121,1950986022228387202291210000),
}
actual={'mu_article':mu_article,'mu_complement':mu_small,'c_L1':cL1,'c_star':cstar}
assert actual==expected,(actual,expected)
assert cstar-cL1==F(1,10000)
assert -cstar < -cL1
print('R16_F0_EXACT_PARAMETER_CHECK=PASS')
for k,v in actual.items(): print(k,'=',v)
print('c_star_minus_c_L1 =',cstar-cL1)
print('Hamiltonian_subcritical_side = PASS (-c_star < -c_L1)')
