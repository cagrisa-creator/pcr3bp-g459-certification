import sympy as sp
s,t,D=sp.symbols('s t D', real=True)
g=sp.Rational(459,1000)
ms = g**3*(g**2-3*g+3)/(1-2*g+g**2+2*g**3-g**4)
# project current MU = 1-ms
mu=1-ms
x=1-ms-g
cl1=x**2/sp.Integer(2)+(1-ms)/(1-g)+ms/g
hh=-(cl1+D)
s2=s*s;t2=t*t
Vb=-hh*s2/sp.Integer(4)-s/sp.Integer(2)-(s2-1)*s2/sp.Integer(32)+hh*t2/sp.Integer(4)-(1-t2)*t2/sp.Integer(32)
B=sp.Rational(1,2)-mu+s*t
lam=1-2*mu
V=sp.factor(Vb+lam*(t/sp.Integer(2)-B*(s2-t2)/sp.Integer(16)))
print('mu=',sp.factor(mu))
print('cl1=',sp.factor(cl1))
# left component separating barrier: distance to right focus = 541/1000 -> s-t=541/500
for name,subs,upper in [
 ('LEFT_COMPONENT_OTHER_DISTANCE', {t:s-sp.Rational(541,500), D:0}, sp.Rational(1041,500)),
 ('RIGHT_COMPONENT_OTHER_DISTANCE', {t:sp.Rational(459,500)-s, D:0}, sp.Rational(959,500)),
]:
    f=sp.factor(V.subs(subs))
    print('\n',name)
    print('factor=',f)
    num,den=sp.fraction(f)
    print('num factor=',sp.factor(num))
    # D derivative on boundary
    dbound=sp.factor(sp.diff(V,D).subs({k:v for k,v in subs.items() if k!=D}))
    print('dVdD=',dbound)
    # roots of remaining nontrivial factor(s)
    q=sp.factor(f/(s-1)) if sp.simplify(f.subs(s,1))==0 else f
    print('after (s-1)=',q)
    print('upper=',upper,'q endpoints=',sp.N(q.subs(s,1),30),sp.N(q.subs(s,upper),30))
    # numeric criticals / roots
    try:
      print('roots=',sp.nroots(sp.Poly(sp.together(q).as_numer_denom()[0],s)))
    except Exception as e: print('roots err',e)
