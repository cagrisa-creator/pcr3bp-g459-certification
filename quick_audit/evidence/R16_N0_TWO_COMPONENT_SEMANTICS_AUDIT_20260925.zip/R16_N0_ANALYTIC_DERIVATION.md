# R16 N0 — Independent two-component chart / clock / reduced-cocycle derivation

## Scope

This note re-derives the semantic layer used to compare the current elliptic-hyperbolic Hamiltonian \(\widehat H\) with the two focus-centered Levi-Civita (LC) Hamiltonians. It is intentionally independent of the route-selection conclusions in R5-FZ/GA/GC. The accompanying symbolic script is an audit aid only; the proof below is the theorem-facing object.

The current magnetic-mechanical Hamiltonian is
\[
\widehat H(x,y)=\tfrac12|y+F(x)|^2+V(x,\Delta),\qquad
F=(\tfrac18\sin 2v,\tfrac18\sinh 2u),
\]
with \(s=\cosh u\), \(t=\cos v\).

The standard focus-A LC source uses \(M=264377992475701/441699674239000\) and, writing \(R=z_1^2+z_2^2\), has magnetic velocity shift
\[
b(z)=(-(2R+M)z_2,(2R-M)z_1).
\]
The complementary mass is \(1-M\).

## 1. Primary exchange is canonical

The elliptic position map is
\[
q_1=\tfrac12\cosh u\cos v,\qquad q_2=\tfrac12\sinh u\sin v.
\]
Under
\[
E:(u,v,y,M)\mapsto(-u,\pi-v,-y,1-M)
\]
one has \(q\mapsto-q\). Since \(d(-u,\pi-v)=(-du,-dv)\),
\[
(-y_1)d(-u)+(-y_2)d(\pi-v)=y_1du+y_2dv.
\]
Thus the state transformation is the cotangent lift of the configuration involution and is exact symplectic. The PCR3BP potential is invariant after simultaneously exchanging the two masses. Direct substitution in the project elliptic potential gives
\[
V(s,-t;1-M)=V(s,t;M).
\]
This is the correct structural reason for the complementary chart; it is not an assumed signed permutation of a frozen LC beta atlas.

## 2. The two focus charts and conformal metrics

Put \(a=u/2\), \(b=v/2\). For focus A,
\[
z_1=2^{-1/2}\cosh a\cos b,\qquad
z_2=2^{-1/2}\sinh a\sin b.
\]
If \(x=\sinh^2a\) and \(y=\sin^2b\), then
\[
s=1+2x,\qquad t=1-2y.
\]
Hence
\[
R_A=z_1^2+z_2^2=\frac{1+x-y}{2}=\frac{s+t}{4}.
\]
For \(A_A=Dz/D(u,v)\), direct multiplication gives
\[
A_AA_A^T=\frac{x+y}{8}I=\frac{s-t}{16}I.
\]

Applying the primary exchange before the same standard focus regularization gives focus B:
\[
Z_1=2^{-1/2}\cosh a\sin b,\qquad
Z_2=-2^{-1/2}\sinh a\cos b.
\]
Then
\[
R_B=\frac{x+y}{2}=\frac{s-t}{4},\qquad
A_BA_B^T=\frac{1+x-y}{8}I=\frac{s+t}{16}I.
\]
These are exact identities.

## 3. Exact focus-A cotangent gauge

Let
\[
\Psi(z)=2(1-2M)z_1z_2,
\qquad g=\nabla_z\Psi.
\]
The canonical momentum relation is
\[
y=A_A^T(p+g),\qquad p=A_A^{-T}y-g.
\]
Exactness of the gauge is simply the chain rule:
\[
A_A^Tg=d(\Psi\circ z)/d(u,v).
\]

The nontrivial magnetic identity is
\[
\frac4{s-t}A_AF+\frac14g=b.
\]
It can be checked without transcendental simplification. With \(x=\sinh^2a\), \(y=\sin^2b\), \(s=1+2x\), \(t=1-2y\), after factoring the common half-angle carriers the two components reduce respectively to
\[
(1-y)t-(1+x)s+\frac12(s-t)(s+t+1)=0,
\]
\[
yt+xs-\frac12(s-t)(s+t-1)=0.
\]
Both are identically zero after substituting \(s=1+2x\), \(t=1-2y\). Notice that the mass cancels from \(b-g/4\), giving an immediate sign/adversarial check.

Since \(A_AA_A^T=(s-t)I/16\), the square matrix \(A_A\) is conformal and
\[
A_A^{-T}=\frac{16}{s-t}A_A.
\]
Define the LC velocity variable
\[
u:=p/4+b.
\]
The preceding relations give
\[
u=\frac4{s-t}A_A(y+F),
\]
and consequently
\[
|\nu|^2=\frac{|y+F|^2}{s-t}.
\]

## 4. Reconstructing the frozen LC Hamiltonian

From the first two components of the frozen R5-BB vector field,
\[
\dot z_1=p_1/4-(2R+M)z_2,
\qquad
\dot z_2=p_2/4+(2R-M)z_1,
\]
so the Hamiltonian must have the form
\[
K=\frac{|p|^2}{8}+b(z)\cdot p+U(z).
\]
The frozen energy parameterization uses
\[
|\nu|^2=F_{LC}(R,q,M,c_{BG}),
\]
where
\[
F_{LC}=4R^3+M^2R-4MR^2q-2c_{BG}R+(1-M)
+\frac{2MR}{\sqrt{4R^2-4Rq+1}}.
\]
Therefore
\[
U=2|b|^2-2F_{LC},
\]
and
\[
K=2(|\nu|^2-F_{LC}).
\]
Differentiating this reconstructed \(K\) reproduces all four components of the frozen `rhs_jac_scalar` exactly; this is checked algebraically in the audit script.

Under the focus-A position identities
\[
R=\frac{s+t}{4},\qquad
q=\frac{1+st}{s+t},\qquad
\sqrt{4R^2-4Rq+1}=\frac{s-t}{2},
\]
direct substitution in the current elliptic potential yields the exact identity
\[
F_{LC}=-\frac{2V}{s-t}.
\]
Combining this with \(|\nu|^2=|y+F|^2/(s-t)\),
\[
K_A\circ\Phi_A
=2\left(\frac{|y+F|^2}{s-t}+\frac{2V}{s-t}\right)
=\frac4{s-t}\widehat H.
\]
Thus the focus-A multiplier is
\[
m_A=\frac4{s-t}.
\]

Because the primary exchange is exact symplectic and changes \(t\mapsto-t\), the identical derivation for the exchanged system gives
\[
K_B\circ\Phi_B=\frac4{s+t}\widehat H,
\qquad m_B=\frac4{s+t}.
\]
No equality of Hamiltonian clocks is used.

## 5. Exact time relations

For a symplectomorphism \(\Phi\) satisfying on a neighborhood of the zero set
\[
K\circ\Phi=mH,
\]
one has on \(H=0\)
\[
d(K\circ\Phi)=m\,dH.
\]
Symplectic covariance of Hamiltonian vector fields then gives
\[
D\Phi\,X_H=\frac1mX_K\circ\Phi.
\]
If \(t\) is \(H\)-time and \(\tau\) is \(K\)-time along corresponding orbits, then
\[
\frac{d\tau}{dt}=\frac1m>0.
\]
Therefore
\[
d\tau_A=\frac{s-t}{4}\,dt_{\widehat H},
\qquad
d\tau_B=\frac{s+t}{4}\,dt_{\widehat H}.
\]

This directly rejects the superseded equal-time interpretation.

## 6. Reduced linearized cocycle

The flow identity is
\[
\Phi\circ\phi_H^t(x)=\phi_K^{\tau(t,x)}(\Phi x).
\]
Differentiating with respect to the initial point in direction \(v\) gives
\[
D\Phi\,D\phi_H^t v
=D\phi_K^{\tau}D\Phi v
+X_K\,D_x\tau(v).
\]
The last term is a multiple of the characteristic vector \(X_K\). It vanishes in the symplectic quotient
\[
T\Sigma_K/\langle X_K\rangle.
\]
Because \(D\Phi\) is symplectic and sends the characteristic line of \(H\) to the characteristic line of \(K\) with positive scale, it induces a symplectic isomorphism of the reduced bundles. Thus the reduced linearized cocycles are symplectically conjugate after the positive time change \(t\mapsto\tau\).

Transport a disk/trivialization of the reduced symplectic bundle by this induced map. In the transported trivialization the two matrix paths differ only by positive reparametrization. Hence their Conley–Zehnder / Robbin–Salamon indices agree. No claim that the raw contact planes or the Hamiltonian clocks are literally identical is required.

## 7. Exact component barriers and positivity of the clocks

For G459, the focus-A separating boundary is
\[
s-t=\frac{541}{500}.
\]
At \(\Delta=0\),
\[
V=-\frac{209000064997701}{441699674239000000000000}
(s-1)(229500000s^2-142978500s-989818921).
\]
Let
\[
q_A(s)=229500000s^2-142978500s-989818921.
\]
On \([1,1041/500]\),
\[
q_A'(s)\ge q_A'(1)=316021500>0,
\]
while
\[
q_A(1041/500)=-292681000<0.
\]
Therefore \(q_A<0\) on the entire interval. Hence \(V\ge0\) on the barrier, with equality only at \(s=1\). Moreover
\[
\partial_\Delta V=\frac{541(1000s-541)}{1000000}>0.
\]
Thus for \(\Delta>0\) the barrier is strict and the corresponding bounded component satisfies
\[
\frac{s-t}{4}\ge\frac{541}{2000}>0.
\]

For focus B, the separating boundary is
\[
s+t=\frac{459}{500}.
\]
At \(\Delta=0\),
\[
V=-\frac{224305912285299}{441699674239000000000000}
(s-1)(270500000s^2-101978500s-1010181079).
\]
Let
\[
q_B(s)=270500000s^2-101978500s-1010181079.
\]
On \([1,959/500]\),
\[
q_B'(s)\ge q_B'(1)=439021500>0,
\]
and
\[
q_B(959/500)=-210681000<0.
\]
Therefore \(q_B<0\) throughout the interval. Also
\[
\partial_\Delta V=\frac{459(1000s-459)}{1000000}>0.
\]
Hence the complementary bounded component satisfies
\[
\frac{s+t}{4}\ge\frac{459}{2000}>0.
\]

These exact inequalities prove that both time changes are positive and component-correct.

## 8. Adversarial regressions / statements explicitly rejected

The derivation above rejects the following superseded shortcuts:

1. \(\tau_{LC}=t_{\widehat H}\) globally — false; the clocks differ by the nonconstant positive factors above.
2. One single-focus LC chart covers both bounded components — false as a global bookkeeping statement.
3. \((s-t)/4\ge541/2000\) on the complete two-component obligation — false; that lower bound is component-A-specific.
4. A trivial signed permutation of the frozen R5-ED beta atlas proves the complementary component — not established and not used here.

## 9. R16 trust / independence adjudication

- The equations in Sections 1–7 are explicit, short, exact algebraic derivations suitable for direct referee inspection.
- The new R16 symbolic script rechecks 35 exact gates but is **audit support only**, because R16's trust base does not allow LLM-generated code to be a theorem authority.
- The pre-existing FZ exact bridge and GC two-component scripts are independent project evidence and agree with this derivation.
- The frozen R5-BB source is independently reconstructed as a Hamiltonian system and its four vector-field components are reproduced exactly.

Recommended status for Claim-Evidence Matrix N0:

**MATHEMATICAL_FORMULA_AUDIT_PASS / PROJECT_INDEPENDENCE_I2_SUPPORTED / I3_STYLE_REDERIVATION_PRESENT_BUT_HUMAN_SOURCE_REVIEW_REQUIRED_BEFORE_LABELING_I3.**

The next R16 theorem-critical computational gate is N1 (the frozen 32,661-parent beta>=1/100 certificate); N0 itself needs no broad numerical campaign.
