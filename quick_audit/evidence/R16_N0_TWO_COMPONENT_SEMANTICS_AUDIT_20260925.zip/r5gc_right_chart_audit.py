import sympy as sp

def ez(e): return sp.simplify(sp.expand(e.rewrite(sp.exp)))

s,t,h,mu=sp.symbols('s t h mu', real=True)
Vb = -h*s**2/sp.Integer(4) - s/sp.Integer(2) - (s**2-1)*s**2/sp.Integer(32) + h*t**2/sp.Integer(4) - (1-t**2)*t**2/sp.Integer(32)
B=sp.Rational(1,2)-mu+s*t
lam=1-2*mu
V=sp.expand(Vb+lam*(t/sp.Integer(2)-B*(s**2-t**2)/sp.Integer(16)))
pass1=sp.simplify(sp.expand(V.subs({t:-t,mu:1-mu}, simultaneous=True)-V))==0
print('POTENTIAL_EXCHANGE_PASS',pass1)
y1,y2,F1,F2=sp.symbols('y1 y2 F1 F2')
kin=((y1+F1)**2+(y2+F2)**2)/2
kinex=(((-y1)+(-F1))**2+((-y2)+(-F2))**2)/2
pass2=sp.expand(kinex-kin)==0
print('KINETIC_EXCHANGE_PASS',pass2)

u,v=sp.symbols('u v', real=True)
rt=sp.sqrt(2)
z1L=sp.cosh(u/2)*sp.cos(v/2)/rt
z2L=sp.sinh(u/2)*sp.sin(v/2)/rt
RL=ez(z1L**2+z2L**2)
pass3=sp.simplify(RL-(sp.cosh(u)+sp.cos(v))/4)==0
print('LEFT_RADIUS_PASS',pass3,'RL=',RL)
AL=sp.Matrix([[sp.diff(z1L,u),sp.diff(z1L,v)],[sp.diff(z2L,u),sp.diff(z2L,v)]])
ML=(AL*AL.T).applyfunc(ez)
pass4=all(sp.simplify(ML[i,j]-((sp.cosh(u)-sp.cos(v))/16 if i==j else 0))==0 for i in range(2) for j in range(2))
print('LEFT_METRIC_PASS',pass4,'diag=',ML[0,0])

# Complementary chart = recovered left chart after exact primary exchange E:(u,v)->(-u,pi-v).
z1R=sp.cosh(u/2)*sp.sin(v/2)/rt
z2R=-sp.sinh(u/2)*sp.cos(v/2)/rt
RR=ez(z1R**2+z2R**2)
pass5=sp.simplify(RR-(sp.cosh(u)-sp.cos(v))/4)==0
print('RIGHT_RADIUS_PASS',pass5,'RR=',RR)
AR=sp.Matrix([[sp.diff(z1R,u),sp.diff(z1R,v)],[sp.diff(z2R,u),sp.diff(z2R,v)]])
MR=(AR*AR.T).applyfunc(ez)
pass6=all(sp.simplify(MR[i,j]-((sp.cosh(u)+sp.cos(v))/16 if i==j else 0))==0 for i in range(2) for j in range(2))
print('RIGHT_METRIC_PASS',pass6,'diag=',MR[0,0])
up=-u; vp=sp.pi-v
z1E=sp.trigsimp(sp.cosh(up/2)*sp.cos(vp/2)/rt)
z2E=sp.trigsimp(sp.sinh(up/2)*sp.sin(vp/2)/rt)
pass7=sp.simplify(z1E-z1R)==0 and sp.simplify(z2E-z2R)==0
print('EXCHANGE_CHART_MATCH_PASS',pass7)

S,T=sp.symbols('S T', positive=True, real=True)
print('LEFT_HAMILTONIAN_MULTIPLIER',4/(S-T))
print('LEFT_TIME_FACTOR',(S-T)/4)
print('RIGHT_HAMILTONIAN_MULTIPLIER',4/(S+T))
print('RIGHT_TIME_FACTOR',(S+T)/4)
print('RIGHT_PARAMETER','M_right=1-M_left')

allp=all([pass1,pass2,pass3,pass4,pass5,pass6,pass7])
print('ALL_SYMBOLIC_GATES_PASS',allp)
if not allp: raise SystemExit(1)
