R16 D1 independent MPFR-192 global de Casteljau replay

Purpose
Close the historical independent-verification burden of 4,207 expected-PASS R5-H terminal leaves at Delta=3/50000 without changing the frozen mathematical certificate.

Frozen input certificate
A_R5_H_DELTA6E5_CERTIFICATE_CLOSED_AUDIT_PENDING_20260920.zip
SHA-256: 568113fbaccaf3b640b5a858963edb4c6ef91f7b2772619e80637be39ab44889

Recovered/reconstructed objects
- r16_r5h_4207_expected_pass.tsv: exact 4,207 direct-expression MPFR inconclusive rows whose expected status is PASS.
- tree_plan_reconstructed.tsv: global dyadic tree reconstructed from final_terminal_leaves.tsv.
  It matches the frozen plan audit exactly: roots [0,19443], 30,726 nodes, 15,364 leaves, maxdepth 24, 13,612 PASS, 1,752 OUTSIDE.
- global_decasteljau_mpfr.cpp and shear_poly_coeff_exact.hpp are the frozen checker source/coefficient header from the R5-H package.

Build used in this environment
  g++ -O2 -std=c++17 global_decasteljau_mpfr.cpp /lib/x86_64-linux-gnu/libmpfr.so.6 /lib/x86_64-linux-gnu/libgmp.so -o r16_global_decasteljau_mpfr

Replay command
  ./r16_global_decasteljau_mpfr tree_plan_reconstructed.tsv global_checker.tsv > global_checker_summary.json

Final result
- precision: 192 bits
- leaves checked: 15,364
- OK: 15,364
- FAIL: 0
- expected PASS: 13,612
- expected OUTSIDE: 1,752
- minimum PASS lower bound: 1.212999365920566124851808e-09
- minimum OUTSIDE lower bound: 3.84161802517878086996833e-06
- historical 4,207 expected-PASS residual: 4,207/4,207 OK
- minimum lower bound within those 4,207: 1.212999365920566124851808e-09

Independence classification
I2. This is an independent MPFR-192 de Casteljau replay/checker of the frozen finite certificate. It is stronger than compiler diversity, but not labeled I3 because the exact polynomial coefficient header is shared with the frozen certificate source.

Important
No theorem search, adaptive redesign, parameter change, or recomputation of the mathematical campaign was performed.
