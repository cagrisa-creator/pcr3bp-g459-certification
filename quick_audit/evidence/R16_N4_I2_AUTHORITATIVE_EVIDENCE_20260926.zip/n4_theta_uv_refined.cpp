#pragma STDC FENV_ACCESS ON
#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/transc.hpp>
#include <boost/numeric/interval/rounded_transc.hpp>
#include <boost/numeric/interval/checking.hpp>
#include <array>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <tuple>
#include <vector>
using namespace std; namespace bn=boost::numeric;
using Rounding=bn::interval_lib::save_state<bn::interval_lib::rounded_transc_std<long double>>;
using Checking=bn::interval_lib::checking_base<long double>;
using Policies=bn::interval_lib::policies<Rounding,Checking>;
using I=bn::interval<long double,Policies>;
static long double lo(const I&x){return x.lower();} static long double hi(const I&x){return x.upper();}
static long double mid(const I&x){return (lo(x)+hi(x))/2;} static long double rad(const I&x){return (hi(x)-lo(x))/2;} static long double wd(const I&x){return hi(x)-lo(x);} 
static long double dn(long double x){return nextafterl(x,-numeric_limits<long double>::infinity());} static long double up(long double x){return nextafterl(x,numeric_limits<long double>::infinity());}
static I widen(long double a,long double b){return I(dn(a),up(b));} static I hullI(const I&a,const I&b){return I(min(lo(a),lo(b)),max(hi(a),hi(b)));}
static bool inside(const I&a,const I&b){return lo(b)<lo(a)&&hi(a)<hi(b);} static bool overlaps(const I&a,const I&b){return !(hi(a)<lo(b)||hi(b)<lo(a));}
static I inflate(const I&x,long double fac){long double m=mid(x),r=rad(x); long double rr=up(fac*r+1e-30L); return I(dn(m-rr),up(m+rr));}
static I sq(const I&x){if(lo(x)>=0)return x*x; if(hi(x)<=0){I y=-x;return y*y;} long double u=max(-lo(x),hi(x)); return I(0,up(u*u));}
static I PI(){long double p=acosl(-1.L); return I(dn(p),up(p));}
template<class T> static T mu_small(const T&g){return g*g*g*(g*g-T(3)*g+T(3))/(T(1)-T(2)*g+g*g+T(2)*g*g*g-g*g*g*g);}
using V4=array<I,4>; using V3=array<I,3>;
static V4 rhs(const V4&y,const I&mu,const I&c){I z1=y[0],z2=y[1],p1=y[2],p2=y[3]; I x0=mu*z2,x1=z1*z1,x2=z2*z2,x3=x1+x2,x4=I(2)*x3,x5=mu*z1,x6=I(8)*c; I x7=p1*z2,x8=I(4)*z1,x9=-I(4)*x1+I(4)*x2+I(4)*(x3*x3)+I(1); I x10=I(1)/sqrt(x9),x11=I(8)*x10,x12=x10*x10*x10,x15=I(2)*x1+I(2)*x2,x17=x12*(x15-I(1)),x18=I(16)*x3,x19=p2*z2,x21=x0*(x15+I(1)),x22=x12*x18; return {p1/I(4)-x0-x4*z2,p2/I(4)+x4*z1-x5,mu*p2-I(2)*p2*(I(3)*x1+x2)+x11*x5-x17*x18*x5+x6*z1+x7*x8,mu*p1+I(2)*p1*(x1+I(3)*x2)+x0*x11-x19*x8-x21*x22+x6*z2};}
struct G{I A,phi,R,thdot;};
static G deriv(const I&th,const V3&y,const I&D,const I&ms,const I&M,const I&cl1){I A=y[0],ph=y[1],R=y[2]; if(!(lo(A)>0&&lo(R)>0)) throw runtime_error("NONPOS_AR"); I r=sqrt(R),ct=cos(th),st=sin(th),cp=cos(ph),sp=sin(ph); I z1=r*ct,z2=r*st,u1=A*cp,u2=A*sp; I p1=I(4)*(u1+(I(2)*R+M)*z2),p2=I(4)*(u2-(I(2)*R-M)*z1); V4 x={z1,z2,p1,p2}; auto f=rhs(x,ms,-(cl1+D)); I Rdot=I(2)*(z1*f[0]+z2*f[1]); I du1=f[2]/I(4)-I(2)*Rdot*z2-(I(2)*R+M)*f[1]; I du2=f[3]/I(4)+I(2)*Rdot*z1+(I(2)*R-M)*f[0]; I Adot=(u1*du1+u2*du2)/A; I phidot=(u1*du2-u2*du1)/(A*A); I thdot=(A/r)*sin(ph-th)+(I(1)-I(2)*ms)*cos(I(2)*th); if(!(lo(thdot)>0)) throw runtime_error("THDOT_NONPOS"); return {Adot/thdot,phidot/thdot,Rdot/thdot,thdot};}
static bool step(const I&th0,const I&h,V3&X,const I&D,const I&ms,const I&M,const I&cl1,I&thdotHull){I th=hullI(th0,th0+h),tau(0,hi(h)); G g0=deriv(th,X,D,ms,M,cl1); V3 B; B[0]=inflate(hullI(X[0],X[0]+tau*g0.A),1.30L); B[1]=inflate(hullI(X[1],X[1]+tau*g0.phi),1.30L); B[2]=inflate(hullI(X[2],X[2]+tau*g0.R),1.30L); bool ok=false; G g=g0; for(int it=0;it<24;it++){g=deriv(th,B,D,ms,M,cl1); V3 N={X[0]+tau*g.A,X[1]+tau*g.phi,X[2]+tau*g.R}; if(inside(N[0],B[0])&&inside(N[1],B[1])&&inside(N[2],B[2])){ok=true;break;} for(int k=0;k<3;k++)B[k]=inflate(hullI(B[k],N[k]),1.25L); if(lo(B[0])<=0||lo(B[2])<=0||wd(B[1])>1.0L)return false;} if(!ok)return false; g=deriv(th,B,D,ms,M,cl1); X={X[0]+h*g.A,X[1]+h*g.phi,X[2]+h*g.R}; thdotHull=g.thdot; return true;}
using U3=array<I,3>;
struct GU{I u1,u2,R,thdot;};
static GU derivUV(const I&th,const U3&y,const I&D,const I&ms,const I&M,const I&cl1){
 I u1=y[0],u2=y[1],R=y[2]; if(!(lo(R)>0)) throw runtime_error("NONPOS_R"); I r=sqrt(R),ct=cos(th),st=sin(th); I z1=r*ct,z2=r*st; I p1=I(4)*(u1+(I(2)*R+M)*z2),p2=I(4)*(u2-(I(2)*R-M)*z1); V4 x={z1,z2,p1,p2}; auto f=rhs(x,ms,-(cl1+D)); I Rdot=I(2)*(z1*f[0]+z2*f[1]); I du1=f[2]/I(4)-I(2)*Rdot*z2-(I(2)*R+M)*f[1]; I du2=f[3]/I(4)+I(2)*Rdot*z1+(I(2)*R-M)*f[0]; I thdot=(u2*ct-u1*st)/r+(I(1)-I(2)*ms)*cos(I(2)*th); if(!(lo(thdot)>0)) throw runtime_error("THDOT_NONPOS"); return {du1/thdot,du2/thdot,Rdot/thdot,thdot};
}
static bool stepUV(const I&th0,const I&h,U3&X,const I&D,const I&ms,const I&M,const I&cl1,I&thdotHull){I th=hullI(th0,th0+h),tau(0,hi(h));GU g0=derivUV(th,X,D,ms,M,cl1);U3 B;B[0]=inflate(hullI(X[0],X[0]+tau*g0.u1),1.25L);B[1]=inflate(hullI(X[1],X[1]+tau*g0.u2),1.25L);B[2]=inflate(hullI(X[2],X[2]+tau*g0.R),1.25L);bool ok=false;GU g=g0;for(int it=0;it<28;it++){g=derivUV(th,B,D,ms,M,cl1);U3 N={X[0]+tau*g.u1,X[1]+tau*g.u2,X[2]+tau*g.R};if(inside(N[0],B[0])&&inside(N[1],B[1])&&inside(N[2],B[2])){ok=true;break;}for(int k=0;k<3;k++)B[k]=inflate(hullI(B[k],N[k]),1.15L);if(lo(B[2])<=0||wd(B[0])>0.02L||wd(B[1])>0.02L)return false;}if(!ok)return false;g=derivUV(th,B,D,ms,M,cl1);X={X[0]+h*g.u1,X[1]+h*g.u2,X[2]+h*g.R};thdotHull=g.thdot;return true;}

static I Fenergy(const I&R,const I&qcos,const I&M,const I&cBG){I DD=I(4)*R*R-I(4)*R*qcos+I(1);return I(4)*R*R*R+M*M*R-I(4)*M*R*R*qcos-I(2)*cBG*R+(I(1)-M)+I(2)*M*R/sqrt(DD);}
static bool intersectNonempty(const I&a,const I&b,I&out){long double L=max(lo(a),lo(b)),H=min(hi(a),hi(b));if(L>H)return false;out=I(L,H);return true;}
static bool sectorPossibleRefined(const U3&X,int j,const I&P){
 if(lo(X[0])>0){I ph=atan(X[1]/X[0]);I blo=I(2)*P*I(j)/I(32),bhi=I(2)*P*I(j+1)/I(32);for(int k=-2;k<=2;k++){I sh=I(2)*P*I(k);I q=hullI(blo+sh,bhi+sh);if(overlaps(ph,q))return true;}return false;}
 I a=I(2)*P*I(j)/I(32),b=I(2)*P*I(j+1)/I(32);I ca=cos(a),sa=sin(a),cb=cos(b),sb=sin(b);I c1=ca*X[1]-sa*X[0];I c2=cb*X[1]-sb*X[0];return hi(c1)>=0 && lo(c2)<=0;
}
struct Rec{long long root;string path;int sector;long long n,tn;long double Alo,Ahi,plo,phi,Rlo,Rhi;long long dlo,dhi,dden;};
struct Leaf{long long root;string path;long double tlo,thi,Alo,Ahi,dlo,dhi;long long n;};
static vector<string> split(const string&s){vector<string>v;stringstream ss(s);string x;while(getline(ss,x,'\t'))v.push_back(x);return v;}
static I ampUV(const U3&X){return sqrt(sq(X[0])+sq(X[1]));}
static bool sectorPossibleUV(const U3&X,int j,const I&P){I a=I(2)*P*I(j)/I(32),b=I(2)*P*I(j+1)/I(32);I ca=cos(a),sa=sin(a),cb=cos(b),sb=sin(b);I c1=ca*X[1]-sa*X[0];I c2=cb*X[1]-sb*X[0];return hi(c1)>=0 && lo(c2)<=0;}
int main(int argc,char**argv){if(argc!=5){cerr<<"usage inputs frontier edges status\n";return 2;}vector<Rec>rec;{ifstream f(argv[1]);string l;getline(f,l);while(getline(f,l)){if(l.empty())continue;auto v=split(l);rec.push_back({stoll(v[0]),v[1],stoi(v[2]),stoll(v[3]),stoll(v[4]),stold(v[5]),stold(v[6]),stold(v[7]),stold(v[8]),stold(v[9]),stold(v[10]),stoll(v[11]),stoll(v[12]),stoll(v[13])});}}
 vector<Leaf>leaves;{ifstream f(argv[2]);string l;getline(f,l);while(getline(f,l)){if(l.empty())continue;auto v=split(l);long double t=stold(v[2]);long long n=llround(t*262144.0L);leaves.push_back({stoll(v[0]),v[1],t,stold(v[3]),stold(v[4]),stold(v[5]),stold(v[6]),stold(v[7]),n});}}
 I gamma=I(459)/I(1000),ms=mu_small(gamma),M=I(1)-ms,x=I(1)-ms-gamma,cl1=x*x/I(2)+(I(1)-ms)/(I(1)-gamma)+ms/gamma,P=PI(),hsec=I(2)*P/I(262144);int SUB=2;I h=hsec/I(SUB);ofstream E(argv[3]),S(argv[4]);E<<"source_root\tsource_path\tsource_phi_sector\tphi_half\tsection_n\ttarget_root\ttarget_path\ttarget_phi_sector\n";S<<"source_root\tsource_path\tsource_phi_sector\tphi_half\tstatus\tsteps\tedges\tmin_thdot\tmax_u1_width\tmax_u2_width\tmax_R_width\treason\n";int pass=0,total=0;
 for(auto&r:rec)for(int half=0;half<2;half++){total++;long double pm=(r.plo+r.phi)/2;I A=widen(r.Alo,r.Ahi),ph=half==0?widen(r.plo,pm):widen(pm,r.phi);U3 X={A*cos(ph),A*sin(ph),widen(r.Rlo,r.Rhi)};I D=I((long double)r.dlo,(long double)r.dhi)/I((long double)r.dden);bool ok=true;string reason="PASS";int ec=0,steps=0;long double minth=1e99,max1=wd(X[0]),max2=wd(X[1]),maxR=wd(X[2]);
  for(long long n=r.n;n<285;n++){I AA0=ampUV(X),thetaFace=I(2)*P*I((long double)n)/I(262144),qen=Fenergy(X[2],cos(I(2)*thetaFace),M,cl1+D);I AA=AA0;if(lo(qen)>=0){I AE=sqrt(qen),tmp;if(intersectNonempty(AA0,AE,tmp))AA=tmp;else{ok=false;reason="ENERGY_EMPTY";break;}}for(auto&L:leaves){if(L.n!=n)continue;if(L.root==r.root&&L.path==r.path)continue;I LA=widen(L.Alo,L.Ahi),LD=widen(L.dlo,L.dhi);if(!overlaps(AA,LA)||!overlaps(D,LD))continue;for(int j=0;j<32;j++)if(sectorPossibleRefined(X,j,P)){E<<r.root<<'\t'<<r.path<<'\t'<<r.sector<<'\t'<<half<<'\t'<<n<<'\t'<<L.root<<'\t'<<L.path<<'\t'<<j<<'\n';ec++;}}
   I td;try{for(int sub=0;sub<SUB;sub++){I th=I(2)*P*I((long double)n)/I(262144)+I(sub)*h;if(!stepUV(th,h,X,D,ms,M,cl1,td)){ok=false;reason="UV_PICARD_FAIL";break;}minth=min(minth,lo(td));max1=max(max1,wd(X[0]));max2=max(max2,wd(X[1]));maxR=max(maxR,wd(X[2]));}if(!ok)break;}catch(exception&e){ok=false;reason=e.what();break;}steps++;}
  if(ok&&r.n+steps>=285){pass++;S<<r.root<<'\t'<<r.path<<'\t'<<r.sector<<'\t'<<half<<"\tPASS_TO_GLOBAL_FACE\t"<<steps<<'\t'<<ec<<'\t'<<minth<<'\t'<<max1<<'\t'<<max2<<'\t'<<maxR<<"\tPASS\n";}else S<<r.root<<'\t'<<r.path<<'\t'<<r.sector<<'\t'<<half<<"\tFAIL\t"<<steps<<'\t'<<ec<<'\t'<<minth<<'\t'<<max1<<'\t'<<max2<<'\t'<<maxR<<'\t'<<reason<<'\n';}
 cerr<<"PASS="<<pass<<"/"<<total<<"\n";return pass==total?0:1;}
