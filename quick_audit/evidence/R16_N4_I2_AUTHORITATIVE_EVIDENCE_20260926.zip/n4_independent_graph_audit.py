import csv, collections, functools, json, hashlib, sys
from pathlib import Path
B=Path(__file__).resolve().parent

def rows(name):
    with open(B/name,newline='') as f: return list(csv.DictReader(f,delimiter='\t'))
def sha(name):
    h=hashlib.sha256();
    with open(B/name,'rb') as f:
        for c in iter(lambda:f.read(1<<20),b''): h.update(c)
    return h.hexdigest()
status=rows('status_uv_refined.tsv'); status_c=rows('status_uv_refined_clang.tsv')
assert len(status)==30 and len(status_c)==30
assert all(r['status']=='PASS_TO_GLOBAL_FACE' and r['reason']=='PASS' for r in status)
assert (B/'status_uv_refined.tsv').read_bytes()==(B/'status_uv_refined_clang.tsv').read_bytes()
assert (B/'edges_uv_refined.tsv').read_bytes()==(B/'edges_uv_refined_clang.tsv').read_bytes()
keys=[(r['source_root'],r['source_path'],r['source_phi_sector'],r['phi_half']) for r in status]
assert len(set(keys))==30
hardrows=rows('fallback15_exact.tsv')
hardkey={r['path']+f"#p{int(r['phi_sector']):02d}":r for r in hardrows}
assert len(hardkey)==15
adj=collections.defaultdict(list)
for r in rows('full_forward_box_edges.tsv'): adj[r['source_node']].append(r['target_node'])
casc={r['path']+f"#p{int(r['phi_sector']):02d}":r['final_status'] for r in rows('r5fj_globalface_cascade_node_ledger.tsv')}
assert sum(v=='HARD15' for v in casc.values())==15
@functools.lru_cache(None)
def terms(n):
    if not adj.get(n): return frozenset([n])
    s=set()
    for v in adj[n]: s.update(terms(v))
    return frozenset(s)
raw=rows('edges_uv_refined.tsv')
collapsed=collections.defaultdict(set); rawtargets=collections.defaultdict(set); safe=collections.defaultdict(set); hardreach=collections.defaultdict(set)
unknown_terminal=set()
for e in raw:
    src=e['source_path']+f"#p{int(e['source_phi_sector']):02d}"
    tgt=e['target_path']+f"#p{int(e['target_phi_sector']):02d}"
    assert src in hardkey
    rawtargets[src].add(tgt)
    ts=terms(tgt)
    unknown_terminal.update(t for t in ts if t not in casc)
    h={t for t in ts if casc.get(t)=='HARD15'}
    if h: hardreach[src].add(tgt); collapsed[src].update(h)
    else: safe[src].add(tgt)
for s in hardkey:
    collapsed.setdefault(s,set()); rawtargets.setdefault(s,set()); safe.setdefault(s,set()); hardreach.setdefault(s,set())
assert not unknown_terminal
nodes=set(hardkey); indeg={n:0 for n in nodes}
for s,ts in collapsed.items():
    for t in ts:
        assert t in nodes
        indeg[t]+=1
q=collections.deque(sorted(n for n,d in indeg.items() if d==0)); topo=[]
while q:
    n=q.popleft();topo.append(n)
    for t in sorted(collapsed[n]):
        indeg[t]-=1
        if indeg[t]==0:q.append(t)
acyclic=len(topo)==len(nodes)
viol=[]; self_edges=[]
for s,ts in collapsed.items():
    su=int(hardkey[s]['thi_num'])
    for t in ts:
        tu=int(hardkey[t]['thi_num'])
        if s==t:self_edges.append((s,t))
        if not tu>su:viol.append((s,su,t,tu))
longest={n:0 for n in nodes}
if acyclic:
    for s in reversed(topo):
        if collapsed[s]: longest[s]=1+max(longest[t] for t in collapsed[s])
U={(s,t) for s,ts in collapsed.items() for t in ts}
H={(r['source_node'],r['target_node']) for r in rows('hard15_collapsed_return_edges.tsv')}
hist_adj=collections.defaultdict(set)
for s,t in H: hist_adj[s].add(t)
for s in nodes: hist_adj.setdefault(s,set())
ind_sinks={s for s in nodes if not collapsed[s]}; hist_sinks={s for s in nodes if not hist_adj[s]}
summary={
 'status':'PASS_N4_I2_NUMERICAL_AND_GRAPH',
 'half_phase_obligations':len(status),
 'half_phase_pass':sum(r['status']=='PASS_TO_GLOBAL_FACE' for r in status),
 'gcc_clang_status_byte_identical':True,
 'gcc_clang_edges_byte_identical':True,
 'raw_edge_records':len(raw),
 'raw_unique_target_nodes':sum(len(v) for v in rawtargets.values()),
 'safe_target_nodes':sum(len(v) for v in safe.values()),
 'hard_reaching_target_nodes':sum(len(v) for v in hardreach.values()),
 'collapsed_hard_edges':len(U),
 'acyclic':acyclic,
 'topological_nodes':len(topo),
 'self_edges':len(self_edges),
 'theta_monotonic_violations':len(viol),
 'max_longest_hard_edge_path':max(longest.values()) if acyclic else None,
 'sources_with_no_hard_successor':len(ind_sinks),
 'historical_sources_with_no_hard_successor':len(hist_sinks),
 'independent_sinks_subset_historical_sinks':ind_sinks<=hist_sinks,
 'collapsed_extra_vs_historical':len(U-H),
 'collapsed_missing_vs_historical':len(H-U),
 'extra_edges':sorted([list(x) for x in U-H]),
 'missing_edges':sorted([list(x) for x in H-U]),
 'independent_sinks':sorted(ind_sinks),
 'historical_sinks':sorted(hist_sinks),
 'hashes':{n:sha(n) for n in ['n4_theta_uv_refined.cpp','fallback15_exact.tsv','frontier254_exact_bounds.tsv','full_forward_box_edges.tsv','r5fj_globalface_cascade_node_ledger.tsv','status_uv_refined.tsv','edges_uv_refined.tsv']}
}
assert summary['half_phase_pass']==30
assert acyclic and len(self_edges)==0 and len(viol)==0
assert summary['max_longest_hard_edge_path']<=5
assert ind_sinks<=hist_sinks
with open(B/'n4_independent_collapsed_edges.tsv','w',newline='') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['source_node','source_theta_hi_num','target_node','target_theta_hi_num'])
    for s,t in sorted(U):w.writerow([s,hardkey[s]['thi_num'],t,hardkey[t]['thi_num']])
with open(B/'n4_independent_graph_audit.json','w') as f: json.dump(summary,f,indent=2,sort_keys=True)
print(json.dumps(summary,indent=2,sort_keys=True))
