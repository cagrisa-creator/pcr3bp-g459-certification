#!/usr/bin/env bash
set -euo pipefail
CXXFLAGS='-std=c++17 -O2'
g++ $CXXFLAGS n4_theta_uv_refined.cpp -o n4_gcc
./n4_gcc fallback15_exact.tsv frontier254_exact_bounds.tsv edges_uv_refined.tsv status_uv_refined.tsv
clang++ $CXXFLAGS n4_theta_uv_refined.cpp -o n4_clang
./n4_clang fallback15_exact.tsv frontier254_exact_bounds.tsv edges_uv_refined_clang.tsv status_uv_refined_clang.tsv
cmp status_uv_refined.tsv status_uv_refined_clang.tsv
cmp edges_uv_refined.tsv edges_uv_refined_clang.tsv
python3 n4_independent_graph_audit.py > n4_independent_graph_audit.out
