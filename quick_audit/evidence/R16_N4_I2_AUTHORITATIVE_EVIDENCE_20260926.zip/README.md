# R16 N4 independent I2 evidence

This package independently replays the 30 theorem-critical half-phase section-face obligations in the N4 hard-terminal branch using a new reduced coordinate representation `(u1,u2,R)` with theta as independent variable.

The numerical engine is not the historical 5D QR classifier. It propagates interval boxes directly in momentum Cartesian coordinates, avoiding polar-phase wrapping. `Delta` is carried as its full interval parameter. At exact section faces, target classification is conservative; energy and angular identities are used only to tighten classification, never to discard an uncertified case.

Acceptance conditions:
- all 30 fixed half-phase obligations reach the global upper residual face;
- GCC and Clang status/edge ledgers are byte-identical;
- composition with the frozen R5-FD local DAG and R5-FJ terminal classifications yields a finite hard graph with no self-edge, strict theta increase, DAG, and longest hard-edge path <=5;
- every sink of the independent conservative graph is among the five sinks already audited in the frozen N5 chain.

The independent collapsed graph need not equal the historical graph. It has one conservative hard edge not present historically and omits one historical edge, while preserving 34 total hard edges, acyclicity, theta monotonicity, and longest path 5.
