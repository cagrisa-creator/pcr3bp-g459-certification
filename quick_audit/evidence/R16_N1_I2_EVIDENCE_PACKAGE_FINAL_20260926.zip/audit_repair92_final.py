import json, glob, hashlib, os
from fractions import Fraction
from pathlib import Path
B=Path('/mnt/data/n1_audit')
cover=json.load(open(B/'R16_MISSING46_ALTERNATE_COVER.json'))
# Load base batch rows
rows={}
for fn in sorted(B.glob('R16_MISSING46_REPAIR_BATCH_*.json')):
    d=json.load(open(fn))
    for r in d['rows']:
        c=int(r['cell'])
        if c in rows: raise RuntimeError(f'duplicate base cell {c}: {fn}')
        rows[c]={'base_file':fn.name,'row':r}
assert set(rows)==set(range(92)), (len(rows), sorted(set(range(92))-set(rows)), sorted(set(rows)-set(range(92))))
resume_map={
 32:'R16_MISSING46_REPAIR_CELL_32_RESUME_D8.json',
 48:'R16_MISSING46_REPAIR_CELL_48_RESUME_D8.json',
 49:'R16_MISSING46_REPAIR_CELL_49_RESUME_D8.json',
 50:'R16_MISSING46_REPAIR_CELL_50_RESUME_D8_PAR.json',
 56:'R16_MISSING46_REPAIR_CELL_56_RESUME_D8_PAR.json',
 57:'R16_MISSING46_REPAIR_CELL_57_RESUME_D8_PAR.json',
}
cell91_d8=[
 'R16_MISSING46_REPAIR_CELL_91_CHUNK_0_8_D8.json',
 'R16_MISSING46_REPAIR_CELL_91_CHUNK_8_16_D8.json',
 'R16_MISSING46_REPAIR_CELL_91_CHUNK_16_24_D8.json',
 'R16_MISSING46_REPAIR_CELL_91_CHUNK_24_32_D8.json']
cell91_d10=sorted([p.name for p in B.glob('cell91_d10_chunk_*.json')])
assert len(cell91_d10)==8, cell91_d10
final=[]; cells=[]
def nodekey(z):
 n=z['node']; return tuple(n.get(k) for k in ['ti','tn','ai','an','pi','pn','dlo','dhi','dden','rid','repair_depth','repair_path'])
for c in range(92):
    r=rows[c]['row']
    passed=list(r.get('passed',[]))
    base_un=len(r.get('unresolved_rows',[]))
    sources=[rows[c]['base_file']]
    unresolved_after=base_un
    if c in resume_map:
        d=json.load(open(B/resume_map[c])); sources.append(resume_map[c])
        assert d['remaining_unresolved']==0, (c,d['remaining_unresolved'])
        assert d['from_unresolved']==base_un, (c,d['from_unresolved'],base_un)
        passed += d['new_passed']; unresolved_after=0
    elif c==91:
        # base had 32 unresolved; d8 chunks partition exactly those 32 input entries
        assert base_un==32, base_un
        d8_pass=[]; d8_un=[]
        spans=[]
        for fn in cell91_d8:
            d=json.load(open(B/fn)); sources.append(fn); spans.append(tuple(d['chunk']))
            d8_pass += d['new_passed']; d8_un += d['unresolved_rows']
        assert sorted(spans)==[(0,8),(8,16),(16,24),(24,32)], spans
        assert len(d8_un)==136, len(d8_un)
        # verify aggregate unresolved file is exactly same ordered keys as concatenated chunks
        agg=json.load(open(B/'R16_CELL91_D8_UNRESOLVED.json'))
        ak=[nodekey(z) for z in agg]; dk=[nodekey(z) for z in d8_un]; assert len(ak)==len(set(ak))==136; assert len(dk)==len(set(dk))==136; assert set(ak)==set(dk)
        passed += d8_pass
        # d10 chunks partition exact 136 aggregate entries
        d10_pass=[]; d10_un=[]; input_count=0
        spans10=[]
        for fn in cell91_d10:
            d=json.load(open(B/fn)); sources.append(fn)
            input_count += d['input_unresolved']; d10_pass += d['new_passed']; d10_un += d['unresolved_rows']
            # infer slice from filename
            ss=fn.replace('cell91_d10_chunk_','').replace('.json','').split('_')
            spans10.append((int(ss[0]),int(ss[1])))
            assert d['remaining_unresolved']==0, (fn,d['remaining_unresolved'])
        assert input_count==136, input_count
        assert sorted(spans10)==[(0,17),(17,34),(34,51),(51,68),(68,85),(85,102),(102,119),(119,136)],spans10
        assert len(d10_un)==0
        passed += d10_pass; unresolved_after=0
    else:
        assert base_un==0, (c,base_un)
    # cell final checks
    paths=[]; weights=Fraction(0); keys=set(); badcert=[]
    for z in passed:
        n=z['node']; cert=z['cert']
        if not cert.get('pass'): badcert.append(n.get('repair_path'))
        rp=n['repair_path']; prefix=f'B{c}'
        assert rp.startswith(prefix), (c,rp)
        suffix=rp[len(prefix):]
        dep=int(n['repair_depth'])
        assert len(suffix)==2*dep, (c,rp,dep,len(suffix))
        # each op dim+bit
        for i in range(0,len(suffix),2): assert suffix[i] in 'TAD' and suffix[i+1] in '01', (c,rp,suffix[i:i+2])
        if rp in paths: raise RuntimeError(f'duplicate path {c} {rp}')
        paths.append(rp); weights += Fraction(1,2**dep)
        k=nodekey(z)
        if k in keys: raise RuntimeError(f'duplicate geom {c} {rp}')
        keys.add(k)
        final.append({'cell':c,'node':n,'cert':cert})
    # prefix-free among terminal paths
    sp=sorted(paths)
    for i,p in enumerate(sp):
        for q in sp[i+1:]:
            if q.startswith(p): raise RuntimeError(f'prefix violation cell {c}: {p} <= {q}')
    if badcert: raise RuntimeError(f'nonpass certs cell {c}: {badcert[:5]}')
    if weights!=1: raise RuntimeError(f'weight cell {c} = {weights}')
    cells.append({'cell':c,'final_pass_leaves':len(passed),'weight':str(weights),'unresolved':unresolved_after,'sources':sources})
assert all(x['unresolved']==0 and x['weight']=='1' for x in cells)
# cover metadata exact volume
assert Fraction(cover['known_volume'])+Fraction(cover['alternate_volume'])==Fraction(1)
assert cover['alternate_cover_count']==92 and len(cover['cells'])==92
# root cells unique geom
rootkeys=[]
for i,e in enumerate(cover['cells']):
 assert e['cover_i']==i
 n=e['node']; rootkeys.append(tuple(n[k] for k in ['ti','tn','ai','an','pi','pn','dlo','dhi','dden']))
assert len(rootkeys)==len(set(rootkeys))==92
# final ledger unique paths globally
allpaths=[(z['cell'],z['node']['repair_path']) for z in final]
assert len(allpaths)==len(set(allpaths))
# hashes
def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
 return h.hexdigest()
ledger=B/'R16_MISSING46_REPAIR_FINAL_LEDGER.json'
json.dump(final,open(ledger,'w'),indent=2)
manifest_files=['R16_MISSING46_ALTERNATE_COVER.json']
manifest_files += sorted(set(x for c in cells for x in c['sources']))
manifest_files += ['R16_CELL91_D8_UNRESOLVED.json','r16_restricted_phi_checker_exact.py','pilot_restricted_adaptive_errsplit_exact.py','fiber_elim_bn','build/fiber_coeff_extract2_beta001']
manifest=[]
for f in manifest_files:
 p=B/f
 if p.exists() and p.is_file(): manifest.append({'file':f,'bytes':p.stat().st_size,'sha256':sha(p)})
summary={
 'status':'PASS_REPAIR92_EXACT_COVER_AND_CERTIFICATE_AUDIT',
 'repair_cells':92,
 'closed_cells':sum(x['unresolved']==0 for x in cells),
 'final_pass_leaves':len(final),
 'unresolved':sum(x['unresolved'] for x in cells),
 'per_cell_weight_identity':all(x['weight']=='1' for x in cells),
 'prefix_free':True,
 'duplicate_final_paths':0,
 'alternate_cover_count':cover['alternate_cover_count'],
 'known_root_count':cover['known_root_count'],
 'missing_original_rid_count':cover['missing_original_rid_count'],
 'known_volume':cover['known_volume'],
 'alternate_volume':cover['alternate_volume'],
 'total_volume':str(Fraction(cover['known_volume'])+Fraction(cover['alternate_volume'])),
 'final_ledger_sha256':sha(ledger),
 'files_manifest':manifest,
 'cells':cells,
}
aud=B/'R16_MISSING46_REPAIR_FINAL_AUDIT.json'
json.dump(summary,open(aud,'w'),indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ['cells','files_manifest']},indent=2))
print('audit_sha256',sha(aud))
