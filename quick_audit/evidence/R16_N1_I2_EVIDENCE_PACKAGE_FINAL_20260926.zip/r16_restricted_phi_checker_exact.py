#!/usr/bin/env python3
import os,sys,math,itertools
from fractions import Fraction as F
os.environ.setdefault('EXE','/mnt/data/n1_audit/build/fiber_coeff_extract2_beta001')
sys.path.insert(0,'/mnt/data/n1_audit')
import r16_halfangle_checker as H

# Exact fixed-point enclosure for dyadic roots of unity.
# Every interval endpoint is an integer multiple of 2^-BITS.
BITS=220
S=1<<BITS

def floordiv(a,b): return a//b
def ceildiv(a,b): return -((-a)//b)
def iadd(a,b): return a[0]+b[0],a[1]+b[1]
def ineg(a): return -a[1],-a[0]
def isub(a,b): return iadd(a,ineg(b))
def imul(a,b):
    p=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]]
    return floordiv(min(p),S),ceildiv(max(p),S)
def ihalf(a): return floordiv(a[0],2),ceildiv(a[1],2)
def sqrtI(a):
    assert a[0]>=0
    L=a[0]*S; U=a[1]*S
    lo=math.isqrt(L)
    hu=math.isqrt(U); hi=hu if hu*hu==U else hu+1
    return lo,hi

ONE=(S,S);ZERO=(0,0)
_root_base={4:(ZERO,ONE)}
def root_base(den):
    assert den>=4 and den&(den-1)==0
    if den in _root_base:return _root_base[den]
    cp,_=root_base(den//2)
    c=sqrtI(ihalf(iadd(ONE,cp)))
    s=sqrtI(ihalf(isub(ONE,cp)))
    _root_base[den]=(c,s);return c,s

def cmul(z,w):
    a,b=z;c,d=w
    return isub(imul(a,c),imul(b,d)),iadd(imul(a,d),imul(b,c))
def cpow(z,n):
    r=(ONE,ZERO);b=z
    while n:
        if n&1:r=cmul(r,b)
        n//=2
        if n:b=cmul(b,b)
    return r
_root_cache={}
def root_value(m,den):
    assert den>0 and den&(den-1)==0
    m%=den;key=(m,den)
    if key in _root_cache:return _root_cache[key]
    if den==1:z=(ONE,ZERO)
    elif den==2:z=(ONE,ZERO) if m==0 else ((-S,-S),ZERO)
    else:
        q=den//4
        if m in (0,q,2*q,3*q):
            z=[(ONE,ZERO),(ZERO,ONE),((-S,-S),ZERO),(ZERO,(-S,-S))][m//q]
        else:
            mm,dd=m,den
            while dd>4 and mm%2==0:mm//=2;dd//=2
            z=cpow(root_base(dd),mm)
    _root_cache[key]=z;return z

def ff(x): return F(x,S)
def trig_range(kind,k,m0,m1,den):
    # Range of sin/cos(2*pi*k*u) for u in [m0/den,m1/den].
    if k==0:return (F(1),F(1)) if kind=='C' else (F(0),F(0))
    A=k*m0;B=k*m1
    z0=root_value(A,den);z1=root_value(B,den)
    vals=[z0[0] if kind=='C' else z0[1],z1[0] if kind=='C' else z1[1]]
    lo=min(ff(v[0]) for v in vals);hi=max(ff(v[1]) for v in vals)
    # Include every exact quarter-turn critical point in the unwrapped harmonic interval.
    j0=ceildiv(4*A,den);j1=floordiv(4*B,den)
    tableC=[F(1),F(0),F(-1),F(0)];tableS=[F(0),F(1),F(0),F(-1)]
    for j in range(j0,j1+1):
        v=(tableC if kind=='C' else tableS)[j%4];lo=min(lo,v);hi=max(hi,v)
    return lo,hi

def fiadd(a,b):return a[0]+b[0],a[1]+b[1]
def fscale(a,c):return (a[0]*c,a[1]*c) if c>=0 else (a[1]*c,a[0]*c)
def poly_arc_interval(a,b,R,m,den):
    q=(F(a[0])-F(R),F(a[0])-F(R))
    for k in range(1,len(a)):
        q=fiadd(q,fscale(trig_range('C',k,m,m+1,den),F(a[k])))
        q=fiadd(q,fscale(trig_range('S',k,m,m+1,den),F(b[k])))
    return q

def positive_arc(a,b,R,pidx,pden,maxdepth=8):
    assert pden>0 and pden&(pden-1)==0
    st=[(pidx,pden,0)];boxes=0;maxd=0;minlb=None
    while st:
        m,den,d=st.pop();boxes+=1;maxd=max(maxd,d);I=poly_arc_interval(a,b,R,m,den)
        minlb=I[0] if minlb is None or I[0]<minlb else minlb
        if I[0]>0:continue
        if d>=maxdepth:return False,{'boxes':boxes,'max_depth':maxd,'min_lower':str(minlb),'last_interval':[str(I[0]),str(I[1])],'reason':'depth'}
        st.append((2*m+1,2*den,d+1));st.append((2*m,2*den,d+1))
    return True,{'boxes':boxes,'max_depth':maxd,'min_lower':str(minlb)}

def cert_node(node,name,maxdepth=8):
    data,deg,C,Scoef,R=H.controls_for_node(node,name);checked=boxes=maxd=0;minlb=None
    for beta in itertools.product(range(3),repeat=3):
        a=[F(C[k][beta]) for k in range(deg+1)]
        b=[F(0)]+[F(Scoef[k][beta]) for k in range(1,deg+1)]
        ok,info=positive_arc(a,b,R,node.get('pi',0),node.get('pn',1),maxdepth)
        checked+=1;boxes+=info['boxes'];maxd=max(maxd,info['max_depth']);v=F(info['min_lower']);minlb=v if minlb is None or v<minlb else minlb
        if not ok:return {'pass':False,'stage':name,'beta':beta,'deg':deg,'R':str(R),'checked':checked,'boxes':boxes,'max_depth':maxd,'min_lower':str(minlb),'detail':info}
    return {'pass':True,'stage':'','deg':deg,'R':str(R),'checked':checked,'boxes':boxes,'max_depth':maxd,'min_lower':str(minlb)}
def cert_full(node,maxdepth=8):
    k=cert_node(node,'K00',maxdepth)
    if not k['pass']:return {'pass':False,'stage':'K00','K00':k,'DET':None}
    d=cert_node(node,'DET',maxdepth)
    return {'pass':bool(d['pass']),'stage':'' if d['pass'] else 'DET','K00':k,'DET':d}

def selftest():
    exact={
      (4,0):(F(1),F(0)),(4,1):(F(0),F(1)),(4,2):(F(-1),F(0)),(4,3):(F(0),F(-1)),
      (8,1):(None,None)
    }
    for (den,m),(ce,se) in exact.items():
        c,s=root_value(m,den);assert c[0]<=c[1] and s[0]<=s[1]
        if ce is not None:assert ff(c[0])<=ce<=ff(c[1]) and ff(s[0])<=se<=ff(s[1])
    assert trig_range('S',1,0,1,4)==(F(0),F(1))
    assert trig_range('C',1,0,1,2)==(F(-1),F(1))
    # Unit-circle point sanity: c^2+s^2 interval contains 1 for selected dyadic roots.
    for den,m in [(8,1),(16,3),(64,37),(128,75),(1024,511)]:
        c,s=root_value(m,den);q=iadd(imul(c,c),imul(s,s));assert q[0]<=S<=q[1]
    return True
if __name__=='__main__':print('SELFTEST',selftest())
