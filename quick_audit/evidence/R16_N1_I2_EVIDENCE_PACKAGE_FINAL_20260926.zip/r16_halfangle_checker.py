#!/usr/bin/env python3
import os, sys, math, itertools
from fractions import Fraction
from decimal import Decimal

# Project coefficient/Taylor model provider (frozen production code).
CX=os.environ.get('CX_DIR','/mnt/data/n1_audit/cx/A_R5_CX_HETEROGENEOUS_FULL_CLOSURE_11424_12000_20260922')
sys.path.insert(0,CX)
import tb2_candidate as tb

D=Decimal

def F(x):
    if isinstance(x,Fraction): return x
    if isinstance(x,Decimal): return Fraction(x)
    return Fraction(str(x))

def poly_add(a,b):
    n=max(len(a),len(b)); c=[Fraction(0)]*n
    for i in range(n): c[i]=(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0)
    while len(c)>1 and c[-1]==0:c.pop()
    return c

def poly_mul(a,b):
    c=[Fraction(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b):
                if y:c[i+j]+=x*y
    while len(c)>1 and c[-1]==0:c.pop()
    return c

def poly_scale(a,s): return [x*s for x in a]

def poly_pow(a,n):
    r=[Fraction(1)]; b=a[:]
    while n:
        if n&1:r=poly_mul(r,b)
        n//=2
        if n:b=poly_mul(b,b)
    return r

_basis={}
def trig_basis(d):
    # cos(k phi), sin(k phi), phi=2 atan(t), denominator (1+t^2)^d.
    if d in _basis:return _basis[d]
    W=[Fraction(1),Fraction(0),Fraction(1)]
    wp=[poly_pow(W,j) for j in range(d+1)]
    C=[]; S=[[Fraction(0)]]
    for k in range(d+1):
        ck=[Fraction(0)]*(2*k+1)
        for m in range(k+1): ck[2*m]=Fraction(((-1)**m)*math.comb(2*k,2*m))
        C.append(poly_mul(ck,wp[d-k]))
        if k:
            sk=[Fraction(0)]*(2*k+1)
            for m in range(k): sk[2*m+1]=Fraction(((-1)**m)*math.comb(2*k,2*m+1))
            S.append(poly_mul(sk,wp[d-k]))
    _basis[d]=(C,S,wp[d]);return _basis[d]

def trig_to_t_poly(a,b,R):
    d=len(a)-1; C,S,Wd=trig_basis(d)
    P=poly_scale(Wd,F(a[0])-F(R))
    for k in range(1,d+1):
        P=poly_add(P,poly_scale(C[k],F(a[k])))
        P=poly_add(P,poly_scale(S[k],F(b[k])))
    n=2*d
    if len(P)<n+1:P += [Fraction(0)]*(n+1-len(P))
    return P[:n+1]

def halfaxis_power(P,sign):
    # t = sign*y/(1-y), Q(y)=(1-y)^n P(t), n=deg target.
    n=len(P)-1
    Q=[Fraction(0)]*(n+1)
    for j,p in enumerate(P):
        if not p:continue
        pp=p*((-1)**j if sign<0 else 1)
        # y^j (1-y)^(n-j)
        for r in range(n-j+1):
            Q[j+r]+=pp*Fraction(((-1)**r)*math.comb(n-j,r))
    return Q

def power_to_bernstein(q):
    n=len(q)-1; b=[Fraction(0)]*(n+1)
    for k in range(n+1):
        s=Fraction(0)
        for j in range(k+1):
            if q[j]:s += q[j]*Fraction(math.comb(k,j),math.comb(n,j))
        b[k]=s
    return b

def split_bernstein_half(b):
    # Exact de Casteljau at x=1/2.
    levels=[b[:]]
    while len(levels[-1])>1:
        p=levels[-1]
        levels.append([(p[i]+p[i+1])/2 for i in range(len(p)-1)])
    left=[levels[i][0] for i in range(len(b))]
    right=[levels[len(b)-1-i][i] for i in range(len(b))]
    return left,right

def bernstein_positive(b,maxdepth=24):
    # Fail closed: every terminal Bernstein coefficient must be strictly positive.
    stack=[(b,0)]; boxes=0; mincoef=None; maxseen=0
    while stack:
        c,dep=stack.pop(); boxes+=1; maxseen=max(maxseen,dep)
        mc=min(c); mincoef=mc if mincoef is None or mc<mincoef else mincoef
        if mc>0:continue
        # Convex hull also proves nonpositivity only if max<=0, but this is a checker: just fail/inconclusive.
        if dep>=maxdepth:
            return False,{'depth':maxseen,'boxes':boxes,'reason':'depth','min':str(mc),'max':str(max(c))}
        l,r=split_bernstein_half(c);stack.append((r,dep+1));stack.append((l,dep+1))
    return True,{'max_depth':maxseen,'boxes':boxes,'min_coeff_seen':str(mincoef)}

def positive_trig_bernstein(a,b,R,maxdepth=24):
    P=trig_to_t_poly(a,b,R)
    out={}
    for side,sgn in [('+',1),('-',-1)]:
        Q=halfaxis_power(P,sgn); B=power_to_bernstein(Q); ok,info=bernstein_positive(B,maxdepth=maxdepth);out[side]=info
        if not ok:return False,{'side':side,'info':info}
    return True,out

def controls_for_node(node,name):
    data=tb.extract(node); deg=data['degK00'] if name=='K00' else data['degDet']
    C=[tb.bernstein_mid(data,name,('C',k)) for k in range(deg+1)]
    S=[None]+[tb.bernstein_mid(data,name,('S',k)) for k in range(1,deg+1)]
    R=F(tb.uncertainty_remainder_all(data,name,deg))
    return data,deg,C,S,R

def cert_node(node,name,maxdepth=24):
    data,deg,C,S,R=controls_for_node(node,name); rec=[]; maxdep=0; boxes=0
    for beta in itertools.product(range(3),repeat=3):
        a=[F(C[k][beta]) for k in range(deg+1)]
        b=[Fraction(0)]+[F(S[k][beta]) for k in range(1,deg+1)]
        ok,info=positive_trig_bernstein(a,b,R,maxdepth=maxdepth)
        rec.append((beta,ok,info))
        if not ok:return {'pass':False,'stage':name,'beta':beta,'detail':info,'deg':deg,'R':str(R),'checked':len(rec)}
        for side in ('+','-'):
            maxdep=max(maxdep,info[side]['max_depth']); boxes+=info[side]['boxes']
    return {'pass':True,'stage':'','deg':deg,'R':str(R),'checked':len(rec),'max_depth':maxdep,'boxes':boxes}

def cert_full(node,maxdepth=24):
    k=cert_node(node,'K00',maxdepth)
    if not k['pass']:return {'pass':False,'stage':'K00','K00':k,'DET':None}
    d=cert_node(node,'DET',maxdepth)
    return {'pass':bool(d['pass']),'stage':'' if d['pass'] else 'DET','K00':k,'DET':d}

# Internal algebraic self-tests.
def selftest():
    # power -> Bernstein identity at rational points
    for n in range(1,12):
        q=[Fraction((j+1)*((-1)**j),j+2) for j in range(n+1)]
        b=power_to_bernstein(q)
        for x in [Fraction(0),Fraction(1,7),Fraction(1,2),Fraction(6,7),Fraction(1)]:
            pv=sum(q[j]*x**j for j in range(n+1))
            bv=sum(b[k]*Fraction(math.comb(n,k))*x**k*(1-x)**(n-k) for k in range(n+1))
            assert pv==bv,(n,x,pv,bv)
        l,r=split_bernstein_half(b)
        # left/right identities at sample local coordinates
        for u in [Fraction(0),Fraction(1,3),Fraction(1)]:
            def bez(c,z):return sum(c[k]*Fraction(math.comb(n,k))*z**k*(1-z)**(n-k) for k in range(n+1))
            assert bez(l,u)==bez(b,u/2)
            assert bez(r,u)==bez(b,(1+u)/2)
    # Trig basis point identities for d<=13 at rational t; compare via exact complex binomial identities.
    for d in range(1,14):
        C,S,Wd=trig_basis(d)
        for t in [Fraction(0),Fraction(1,3),Fraction(-2,5),Fraction(2)]:
            W=1+t*t
            for k in range(d+1):
                cv=sum(C[k][j]*t**j for j in range(len(C[k])))
                # Re((1+i t)^(2k))*W^(d-k)
                re=sum(Fraction(((-1)**m)*math.comb(2*k,2*m))*t**(2*m) for m in range(k+1))*W**(d-k)
                assert cv==re
                if k:
                    sv=sum(S[k][j]*t**j for j in range(len(S[k])))
                    im=sum(Fraction(((-1)**m)*math.comb(2*k,2*m+1))*t**(2*m+1) for m in range(k))*W**(d-k)
                    assert sv==im
    return True

if __name__=='__main__':
    print('SELFTEST',selftest())
