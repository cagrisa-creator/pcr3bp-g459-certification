#!/usr/bin/env python3
import os,sys,itertools
from fractions import Fraction as F
os.environ.setdefault('EXE','/mnt/data/n1_audit/build/fiber_coeff_extract2_beta001')
sys.path.insert(0,'/mnt/data/n1_audit')
import r16_restricted_phi_checker_exact as C
import r16_halfangle_checker as H

def controls_from_data(data,name):
    deg=data['degK00'] if name=='K00' else data['degDet']
    Co=[H.tb.bernstein_mid(data,name,('C',k)) for k in range(deg+1)]
    Si=[None]+[H.tb.bernstein_mid(data,name,('S',k)) for k in range(1,deg+1)]
    R=H.F(H.tb.uncertainty_remainder_all(data,name,deg))
    return deg,Co,Si,R

def cert_node_from_data(data,node,name,maxdepth=8):
    deg,Co,Si,R=controls_from_data(data,name);checked=boxes=maxd=0;minlb=None
    for beta in itertools.product(range(3),repeat=3):
        a=[F(Co[k][beta]) for k in range(deg+1)]
        b=[F(0)]+[F(Si[k][beta]) for k in range(1,deg+1)]
        ok,info=C.positive_arc(a,b,R,node.get('pi',0),node.get('pn',1),maxdepth)
        checked+=1;boxes+=info['boxes'];maxd=max(maxd,info['max_depth']);v=F(info['min_lower']);minlb=v if minlb is None or v<minlb else minlb
        if not ok:return {'pass':False,'stage':name,'beta':beta,'deg':deg,'R':str(R),'checked':checked,'boxes':boxes,'max_depth':maxd,'min_lower':str(minlb),'detail':info}
    return {'pass':True,'stage':'','deg':deg,'R':str(R),'checked':checked,'boxes':boxes,'max_depth':maxd,'min_lower':str(minlb)}

def cert_full(node,maxdepth=8):
    data=H.tb.extract(node)
    k=cert_node_from_data(data,node,'K00',maxdepth)
    if not k['pass']:return {'pass':False,'stage':'K00','K00':k,'DET':None}
    d=cert_node_from_data(data,node,'DET',maxdepth)
    return {'pass':bool(d['pass']),'stage':'' if d['pass'] else 'DET','K00':k,'DET':d}
